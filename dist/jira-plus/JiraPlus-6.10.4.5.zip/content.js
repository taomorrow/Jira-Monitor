// Jira+ extension based on frozen Jira Monitor 6.10.4. Generated; do not edit.
(async()=>{
// The legacy API is local to this bundled content script; no page-world bridge or eval.
let cache=await chrome.storage.local.get(null);
const menuCommands=[];
let storageQueue=Promise.resolve();
const GM_getValue=(key,fallback)=>Object.hasOwn(cache,key)?cache[key]:fallback;
const GM_setValue=(key,value)=>{cache[key]=value;storageQueue=storageQueue.then(()=>chrome.storage.local.set({[key]:value})).catch(error=>console.error('Jira+ 保存失败',error));};
const GM_deleteValue=key=>{delete cache[key];storageQueue=storageQueue.then(()=>chrome.storage.local.remove(key)).catch(error=>console.error('Jira+ 删除失败',error));};
const GM_registerMenuCommand=(label,callback)=>menuCommands.push({label,callback});
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local')for(const [key,change]of Object.entries(changes)){if(Object.hasOwn(change,'newValue'))cache[key]=change.newValue;else delete cache[key];}});
chrome.runtime.onMessage.addListener(message=>{if(message?.type==='jiraplus:open'){document.getElementById('jira-plus-hub')?.shadowRoot?.getElementById('launcher')?.click();}});
const GM_openInTab=async(url,options={})=>{await storageQueue;const result=await chrome.runtime.sendMessage({type:'jiraplus:tab',url:String(url),active:options.active!==false});if(!result?.ok)throw Error(result?.error||'打开标签失败');return result;};
let jiraPlusPending=null,jiraPlusMenu=null;
const GM_xmlhttpRequest=options=>{
 if(typeof jiraPlusPending!=='undefined'&&jiraPlusPending&&options.method==='POST'){try{const payload=JSON.parse(options.data);if(payload.reportType){jiraPlusPending.push({url:options.url,payload,menu:jiraPlusMenu});queueMicrotask(()=>options.onload?.({status:202,responseText:'Buffered for combined Job delivery'}));return {abort(){}};}}catch(error){queueMicrotask(()=>options.onerror?.({error:error.message}));return {abort(){}};}}
 const id=crypto.randomUUID();let settled=false;
 const finish=(callback,value)=>{if(settled)return;settled=true;callback?.(value);};
 chrome.runtime.sendMessage({type:'jiraplus:http',id,url:options.url,method:options.method||'GET',headers:options.headers||{},data:options.data,timeout:options.timeout||30000}).then(result=>{if(result?.ok)finish(options.onload,result.response);else finish(result?.timeout?options.ontimeout:options.onerror,{error:result?.error||'请求失败'});}).catch(error=>finish(options.onerror,{error:error.message}));
 return {abort(){if(settled)return;chrome.runtime.sendMessage({type:'jiraplus:abort',id}).catch(()=>{});finish(options.onabort,{});}};

};

(function(){
'use strict';
if(window.top!==window.self||document.getElementById('jira-plus-hub'))return;
const host=document.createElement('div');host.id='jira-plus-hub';document.documentElement.append(host);
const root=host.attachShadow({mode:'open'});
const style=document.createElement('style');style.textContent=`
:host{font:13px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif;color:#24334d}*{box-sizing:border-box}button,input,textarea,select{font:inherit}button{cursor:pointer;border:0}button:focus-visible{outline:3px solid #93b9ff;outline-offset:2px}[hidden]{display:none!important}
#launcher{position:fixed;right:24px;bottom:20px;width:46px;height:46px;padding:4px;border:0;background:transparent;display:grid;place-items:center;touch-action:none;user-select:none;cursor:grab;z-index:2147483646;filter:drop-shadow(0 2px 5px #485b9760);transition:filter .18s,transform .18s}
#launcher:hover{filter:drop-shadow(0 2px 9px #6674cba0);transform:scale(1.08)}
#launcher:focus-visible{outline:2px solid #536df0;outline-offset:3px;border-radius:14px}
#launcher svg{width:100%;height:100%;pointer-events:none}
#shell{position:fixed;display:flex;flex-direction:column;background:#f6f8fc;border:1px solid #dbe3f0;border-radius:16px;z-index:2147483646;overflow:hidden;box-shadow:0 20px 70px #1e355b38;min-width:0}
#titlebar{height:54px;flex-shrink:0;display:flex;align-items:center;gap:10px;padding:0 18px;background:white;border-bottom:1px solid #e8edf5;cursor:move;touch-action:none;user-select:none}#brand-icon{background:#245de8;color:white;border-radius:9px;padding:3px 8px;font-weight:800}#version{font-size:11px;color:#8290a6}#window-close,#detail-close{margin-left:auto;color:#dc3545;background:#fff1f2;border-radius:8px;width:30px;height:30px;line-height:30px;padding:0;font-size:15px}#window-close:hover,#detail-close:hover{background:#ffe1e5}
#workspace{display:flex;flex:1;min-height:0}nav{width:166px;flex-shrink:0;padding:18px 10px;background:#fff;border-right:1px solid #e8edf5}nav small{display:block;color:#95a0b2;font-size:10px;letter-spacing:1.6px;margin:2px 12px 12px}nav button{display:block;width:100%;text-align:left;padding:11px 12px;margin:4px 0;background:transparent;color:#64738b;border-radius:9px;font-weight:500;white-space:nowrap}nav button:hover{background:#f4f7fc}nav button[aria-selected=true]{background:#eaf0ff;color:#245de8;font-weight:700;box-shadow:inset 3px 0 #245de8}
main{position:relative;isolation:isolate;flex:1;min-width:0;min-height:0;overflow:hidden}main>section{height:100%;overflow:auto;padding:18px}#timeout-view{padding:0}#resize-grip{z-index:5;position:absolute;bottom:0;right:0;width:22px;height:22px;cursor:nwse-resize;touch-action:none;background:repeating-linear-gradient(135deg,transparent 0 3px,#acbbd3 3px 4px,transparent 4px 6px);clip-path:polygon(100% 0,100% 100%,0 100%);opacity:.65}
#detail-popup{position:fixed;bottom:76px;right:24px;width:min(420px,calc(100vw - 32px));z-index:2147483647;background:white;border:1px solid #dae3f1;border-radius:14px;box-shadow:0 12px 42px #243c6430;overflow:hidden}#detail-header{display:flex;align-items:center;padding:12px 16px;border-bottom:1px solid #edf0f6;font-weight:600}#detail-header span{font-size:11px;color:#8694aa;margin-left:8px}#detail-content{max-height:min(480px,65vh);overflow:auto}
#settings-view h2{font-size:21px;margin:0 0 6px}#settings-view p{color:#718098}#settings-view button{border:1px solid #dbe3f0;border-radius:7px;padding:7px 9px;white-space:nowrap;margin:5px 5px 5px 0;background:white;color:#425778}#settings-view [data-project-save]{background:#245de8;border-color:#245de8;color:white}#settings-view input:not([type=checkbox]),#settings-view textarea{border:1px solid #dce4f0;border-radius:6px;padding:8px;max-width:100%;background:#fbfcff}#settings-view td{padding:10px 6px;vertical-align:top;border-bottom:1px solid #edf1f7}#settings-view th{padding:10px 6px;text-align:left;font-size:11px;color:#718098;background:#f0f4fb}#settings-view table{table-layout:fixed}#settings-view th:first-child{width:130px}#settings-view th:nth-child(4){width:64px}#settings-view th:nth-child(5){width:70px}#settings-view th:last-child{width:76px}#settings-view [data-auto-setting]{display:flex;align-items:center;gap:8px;padding:14px;background:#edf3ff;border-radius:10px;margin:16px 0;color:#245de8}
`;root.append(style);
function el(tag,text,parent=root){const n=document.createElement(tag);if(text)n.textContent=text;parent.append(n);return n;}
const launcher=el('button');launcher.id='launcher';launcher.title='Jira+ · 点击打开，拖动移动';launcher.setAttribute('aria-label','打开 Jira+');launcher.innerHTML='<svg viewBox="0 0 100 100" aria-hidden="true"><defs><radialGradient id="jm-star"><stop offset="0" stop-color="#4389ff"/><stop offset=".65" stop-color="#245de8"/><stop offset="1" stop-color="#1646c4"/></radialGradient></defs><path d="M50 5C57 5 55 32 65 38S95 42 95 50S71 55 63 64S57 95 50 95S45 72 37 64S5 57 5 50S29 44 37 36S43 5 50 5Z" fill="url(#jm-star)" stroke="#4d8cff" stroke-width="1.8"/></svg>';
let launcherDragged=false;const savedLauncher=GM_getValue('jira-plus-launcher-v1',null);
function placeLauncher(point){const width=launcher.offsetWidth||46,height=launcher.offsetHeight||46;const left=Math.max(8,Math.min(point.left,innerWidth-width-8)),top=Math.max(8,Math.min(point.top,innerHeight-height-8));Object.assign(launcher.style,{left:left+'px',top:top+'px',right:'auto',bottom:'auto'});return {left,top};}
if(savedLauncher)placeLauncher(savedLauncher);
launcher.addEventListener('pointerdown',event=>{if(event.button!==0)return;const box=launcher.getBoundingClientRect(),startX=event.clientX,startY=event.clientY;launcherDragged=false;let point={left:box.left,top:box.top};launcher.setPointerCapture?.(event.pointerId);const move=e=>{if(Math.hypot(e.clientX-startX,e.clientY-startY)>4)launcherDragged=true;if(launcherDragged)point=placeLauncher({left:box.left+e.clientX-startX,top:box.top+e.clientY-startY});};const end=()=>{launcher.removeEventListener('pointermove',move);launcher.removeEventListener('pointerup',end);launcher.removeEventListener('pointercancel',end);if(launcherDragged)GM_setValue('jira-plus-launcher-v1',point);};launcher.addEventListener('pointermove',move);launcher.addEventListener('pointerup',end);launcher.addEventListener('pointercancel',end);});
addEventListener('resize',()=>{if(launcher.style.left)placeLauncher({left:parseFloat(launcher.style.left),top:parseFloat(launcher.style.top)});});
const shell=el('div');shell.id='shell';shell.hidden=true;shell.setAttribute('role','dialog');shell.setAttribute('aria-label','Jira+');
const header=el('header',null,shell);header.id='titlebar';el('span','J',header).id='brand-icon';el('strong','Jira+',header);el('span','v6.10.4.5',header).id='version';
const close=el('button','❌',header);close.id='window-close';close.setAttribute('aria-label','关闭 Jira+');
const workspace=el('div',null,shell);workspace.id='workspace';const nav=el('nav',null,workspace);nav.setAttribute('aria-label','功能菜单');el('small','WORKSPACE',nav);
const timeoutTab=el('button','◷  COE',nav),sprintTab=el('button','▥  Sprint',nav),epicTab=el('button','◈  Epic',nav),config=el('button','⚙  Configuration',nav);timeoutTab.id='nav-timeout';sprintTab.id='nav-sprint';epicTab.id='nav-epic';config.id='nav-settings';
const content=el('main',null,workspace),timeout=el('section',null,content),sprint=el('section',null,content),settings=el('section',null,content),epic=el('section',null,content);timeout.id='timeout-view';sprint.id='sprint-view';settings.id='settings-view';epic.id='epic-view';epic.hidden=sprint.hidden=settings.hidden=true;
const grip=el('div',null,shell);grip.id='resize-grip';grip.setAttribute('aria-label','拖动调整窗口大小');
const detail=el('div');detail.id='detail-popup';detail.hidden=true;const detailHeader=el('div',null,detail);detailHeader.id='detail-header';el('strong','◷  详情分析',detailHeader);el('span','独立浮窗',detailHeader);const detailClose=el('button','❌',detailHeader);detailClose.id='detail-close';detailClose.setAttribute('aria-label','关闭详情分析');const detailContent=el('div',null,detail);detailContent.id='detail-content';
let geometry=GM_getValue('jira-plus-window-v1',{}),activeView='timeout',dismissedDetail='';
function fit(g){const maxW=Math.max(1,innerWidth-24),maxH=Math.max(1,innerHeight-24);const width=Math.max(Math.min(620,maxW),Math.min(Number(g.width)||960,maxW)),height=Math.max(Math.min(360,maxH),Math.min(Number(g.height)||620,maxH));return {width,height,left:Math.max(12,Math.min(Number.isFinite(g.left)?g.left:(innerWidth-width)/2,innerWidth-width-12)),top:Math.max(12,Math.min(Number.isFinite(g.top)?g.top:(innerHeight-height)/2,innerHeight-height-12))};}
function layout(){geometry=fit(geometry);Object.assign(shell.style,{width:geometry.width+'px',height:geometry.height+'px',left:geometry.left+'px',top:geometry.top+'px'});}layout();
function drag(node,resizing){node.addEventListener('pointerdown',e=>{if(e.button!==0||e.target.closest('button'))return;e.preventDefault();const start={...geometry},x=e.clientX,y=e.clientY;node.setPointerCapture?.(e.pointerId);const move=event=>{geometry=resizing?{...start,width:start.width+event.clientX-x,height:start.height+event.clientY-y}:{...start,left:start.left+event.clientX-x,top:start.top+event.clientY-y};layout();};const end=()=>{node.removeEventListener('pointermove',move);node.removeEventListener('pointerup',end);node.removeEventListener('pointercancel',end);GM_setValue('jira-plus-window-v1',geometry);};node.addEventListener('pointermove',move);node.addEventListener('pointerup',end);node.addEventListener('pointercancel',end);});}drag(header,false);drag(grip,true);addEventListener('resize',layout);
const hub={closedSprint:value=>/closed/i.test(String(value)),timeout,sprint,epic,settings,detail:detailContent,autoDetail:GM_getValue('jira-plus-auto-detail',false)===true,
 show(which='timeout'){if(which==='timeout'&&/^\/browse\//i.test(location.pathname)){shell.hidden=true;return;}activeView=which;shell.hidden=false;timeout.hidden=which!=='timeout';sprint.hidden=which!=='sprint';settings.hidden=which!=='settings';epic.hidden=which!=='epic';[[timeoutTab,'timeout'],[sprintTab,'sprint'],[epicTab,'epic'],[config,'settings']].forEach(([b,key])=>b.setAttribute('aria-selected',String(which===key)));layout();},
 hide(){shell.hidden=true;launcher.focus();},syncRoute(){if(/^\/browse\//i.test(location.pathname)&&activeView==='timeout')shell.hidden=true;},syncDetail(){detail.hidden=!hub.autoDetail||!/^\/browse\//i.test(location.pathname)||dismissedDetail===location.pathname;},
 openDetail(){dismissedDetail='';hub.syncDetail();},setAuto(value){hub.autoDetail=value;GM_setValue('jira-plus-auto-detail',value);if(value){dismissedDetail='';hub.startDetail?.();}else hub.stopDetail?.();hub.syncDetail();},
 refreshSettings(){hub.configure?.();}};
launcher.onclick=()=>{if(launcherDragged){launcherDragged=false;return;}hub.show();};timeoutTab.onclick=()=>hub.show();sprintTab.onclick=()=>hub.show('sprint');epicTab.onclick=()=>hub.show('epic');config.onclick=()=>hub.configure?.();close.onclick=()=>hub.hide();detailClose.onclick=()=>{dismissedDetail=location.pathname;hub.syncDetail();};
root.addEventListener('keydown',e=>{if(e.key==='Escape'&&!root.querySelector('dialog[open]'))hub.hide();});
if(typeof GM_registerMenuCommand==='function')GM_registerMenuCommand('Jira+：打开统一面板',()=>hub.show());
  function validateTeamsUrl(value){
    let u;try{u=new URL(String(value).trim().replace(/\\&/g,'&').replace(/&amp;/g,'&'));}catch{throw new Error('请输入有效的 Teams Workflows HTTPS Webhook 地址。');}
    const allowed=['logic.azure.com','api.powerplatform.com','api.powerautomate.com'];
    if(u.protocol!=='https:'||u.username||u.password||u.hash||u.port||!allowed.some(h=>u.hostname.endsWith('.'+h))||!u.pathname.includes('/workflows/'))throw new Error('仅支持微软 Teams Workflows 的 HTTPS 地址（logic.azure.com / api.powerplatform.com / api.powerautomate.com），不支持旧版 Connector。');
    return u.href;
  }
hub.validateWebhook=validateTeamsUrl;
// Inline styles and real tables keep the report readable in Outlook and Teams email actions.
hub.escapeHtml=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
hub.emailCard=({title,subtitle,sections,meta,url})=>{
 const esc=hub.escapeHtml;
 const cards=sections.map(section=>`<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:0 0 20px;border:1px solid #e1e7f0;border-radius:10px;background:#ffffff"><tr><td style="padding:18px 20px 10px;font-size:16px;font-weight:700;color:#24334d">${esc(section.title)}</td></tr><tr><td style="padding:0 20px 18px"><table width="100%" cellspacing="0" cellpadding="0" style="border-collapse:collapse;font-size:13px;line-height:1.6"><thead><tr>${section.headers.map((h,i)=>`<th align="${i?'center':'left'}" style="padding:10px 8px;background:#f1f5fc;color:#718098;font-size:12px;border-bottom:1px solid #e3eaf4">${esc(h)}</th>`).join('')}</tr></thead><tbody>${section.rows.map((row,index)=>`<tr>${row.map((v,i)=>`<td align="${i?'center':'left'}" style="padding:11px 8px;border-bottom:1px solid #edf1f7;${section.total&&index===section.rows.length-1?'font-weight:700;background:#edf3ff;':''}color:${section.deltaColumn===i&&Number(v)>0?'#d13438':'#24334d'}">${esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table></td></tr></table>`).join('');
 return `<div style="background:#f2f5fb;padding:24px 12px;font-family:Arial,'Microsoft YaHei',sans-serif;color:#24334d"><table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:720px;margin:0 auto"><tr><td style="background:#245de8;padding:22px 24px;border-radius:12px 12px 0 0;color:white"><div style="font-size:11px;letter-spacing:2px;color:#dbe6ff">JIRA MONITOR</div><h1 style="font-size:23px;line-height:1.4;margin:8px 0">${esc(title)}</h1><div style="font-size:13px;line-height:1.7;color:#e1eaff">${esc(subtitle)}</div></td></tr><tr><td style="padding:22px;background:#ffffff;border:1px solid #e1e7f0;border-top:0;border-radius:0 0 12px 12px">${cards}<a href="${esc(url)}" style="display:inline-block;background:#245de8;color:#ffffff;text-decoration:none;font-size:13px;font-weight:bold;padding:11px 18px;border-radius:7px">打开 Jira 查看详情 →</a><div style="font-size:11px;line-height:1.8;color:#8793a8;margin-top:18px;word-break:break-all">${esc(meta)}</div></td></tr><tr><td style="padding:14px;text-align:center;color:#97a2b5;font-size:10px">Jira+ · 项目运营报告</td></tr></table></div>`;
};
// Standalone COE snapshot. Deliberately exclude settings, webhook URLs and account identifiers.
function buildCOEReport(model){
 const data=JSON.stringify(model).replace(/[<>&\u2028\u2029]/g,c=>'\\u'+c.charCodeAt(0).toString(16).padStart(4,'0'));
 return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Jira+ · COE 交互报告</title><style>*{box-sizing:border-box}body{margin:0;background:#f3f6fc;color:#24334d;font:14px/1.6 system-ui,sans-serif}main{max-width:1200px;margin:auto;padding:24px}section{background:white;border:1px solid #dfe7f2;border-radius:12px;padding:20px;margin:16px 0}h1{margin:0;color:#245de8}button,input{font:inherit;border:1px solid #dbe4f2;background:white;border-radius:7px;padding:8px 12px;margin:5px;cursor:pointer;color:#245de8}.selected{background:#eaf0ff;border-color:#245de8}table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:10px;border-bottom:1px solid #e9eef6}th{background:#f3f6fc;color:#718098}a{color:#245de8}.warning{color:#a66a00}.overdue{color:#c12738}input{color:#24334d;min-width:280px}small{color:#718098}.scroll{overflow:auto}</style></head><body><main><h1>Jira+ · COE</h1><p id="meta"></p><section><h2>规则统计</h2><div id="counts"></div><small>点击数量筛选对应工单；这是生成时的快照，不会自动更新。</small></section><section><h2 id="title">全部工单</h2><input id="search" placeholder="搜索 Jira、摘要或负责人" aria-label="搜索工单"><span id="count"></span><div class="scroll"><table><thead><tr><th>Jira</th><th>摘要</th><th>通知负责人</th><th>当前状态</th><th>规则结果</th></tr></thead><tbody id="rows"></tbody></table></div></section></main><script id="report-data" type="application/json">${data}</script><script>(${coeReportRuntime.toString()})();</script></body></html>`;
}
function coeReportRuntime(){
 const model=JSON.parse(document.getElementById('report-data').textContent),$=id=>document.getElementById(id);let selected='';
 const el=(tag,text,parent)=>{const n=document.createElement(tag);n.textContent=text;parent.append(n);return n;};
 $('meta').textContent=model.project+' · '+model.generatedAt;
 function draw(){const term=$('search').value.trim().toLowerCase(),items=model.items.filter(i=>(!selected||i.rules.some(r=>r.name+'|'+r.level===selected))&&[i.key,i.summary,i.assignee].join(' ').toLowerCase().includes(term));$('rows').replaceChildren();$('count').textContent=items.length+' 条';
 for(const i of items){const row=el('tr','',$('rows')),cell=el('td','',row),link=el('a',i.key,cell);try{const u=new URL(i.jiraUrl);if(['http:','https:'].includes(u.protocol)){link.href=u.href;link.target='_blank';link.rel='noopener noreferrer';}}catch{}el('td',i.summary,row);el('td',i.assignee,row);el('td',i.status,row);const results=el('td','',row);for(const r of i.rules)el('div',r.name+' · '+r.sla+' · '+r.days+' 天',results).className=r.level;}
 }
 function choose(value,title){selected=value;$('title').textContent=title;for(const b of $('counts').querySelectorAll('button'))b.classList.toggle('selected',b.dataset.filter===value);draw();}
 const all=el('button','全部 '+model.items.length+' 条',$('counts'));all.dataset.filter='';all.onclick=()=>choose('','全部工单');
 const rules=[...new Set(model.items.flatMap(i=>i.rules.map(r=>r.name)))];for(const name of rules)for(const [level,label] of [['warning','即将超期'],['overdue','已超期'],['normal','符合预期']]){const count=model.items.filter(i=>i.rules.some(r=>r.name===name&&r.level===level)).length;if(!count)continue;const b=el('button',name+' '+label+' '+count+' 条',$('counts'));b.dataset.filter=name+'|'+level;b.onclick=()=>choose(b.dataset.filter,name+' · '+label);}
 $('search').oninput=draw;choose('','全部工单');
}
if(typeof module==='object'&&module.exports)module.exports={buildCOEReport};
hub.attachEmailReport=(email,file)=>{
 if(!email?.enabled)return email;
 const bytes=new TextEncoder().encode(file.html);let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
 email.attachments=[{name:file.name,contentType:'text/html',contentBytes:btoa(binary)}];
 email.bodyHtml=(email.bodyHtml||'').replace(/<p data-jira-plus-report[\s\S]*?<\/p>/g,'');
 email.bodyHtml+='<p data-jira-plus-report style="font:12px Arial;color:#718098">交互报告附件：'+hub.escapeHtml(file.name)+'。下载后用浏览器打开，点击数量查看对应 Jira 明细。</p>';
 return email;
};
hub.downloadFile=file=>{const url=URL.createObjectURL(new Blob([file.html],{type:file.type||'text/html;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download=file.name;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);};
hub.coeReportFile=(reports,project)=>{
 const model={project,generatedAt:new Date().toISOString(),items:reports.map(({item,report})=>({key:item.key,summary:item.summary||'',assignee:report.assignee||'未分配',status:item.currentStatus||'',jiraUrl:report.jiraUrl,rules:report.rules.map(r=>({name:r.name,sla:r.sla,days:r.days,level:r.level}))}))};
 return {name:'Jira-Monitor-COE-'+project+'-'+new Date().toISOString().replace(/[:.]/g,'-')+'.html',html:buildCOEReport(model)};
};
hub.previewEmail=email=>{
 document.getElementById('jira-plus-email-preview')?.remove();const host=document.createElement('div');host.id='jira-plus-email-preview';document.documentElement.append(host);const root=host.attachShadow({mode:'open'}),style=document.createElement('style');style.textContent=':host{font:13px system-ui;color:#24334d}.backdrop{position:fixed;inset:0;background:#14284666;z-index:2147483647;display:flex;align-items:center;justify-content:center}.window{width:min(900px,95vw);height:85vh;background:white;border-radius:12px;padding:18px;display:flex;flex-direction:column;gap:10px;box-sizing:border-box}iframe{flex:1;border:1px solid #e3eaf4;width:100%;min-height:0}button{align-self:end;color:#d13438;background:#fff1f2;border:0;border-radius:6px;padding:6px;cursor:pointer}p{margin:0;overflow-wrap:anywhere}';root.append(style);
 const add=(tag,text,parent)=>{const n=document.createElement(tag);n.textContent=text;parent.append(n);return n;},backdrop=add('div','',root);backdrop.className='backdrop';const panel=add('section','',backdrop);panel.className='window';panel.setAttribute('role','dialog');panel.setAttribute('aria-label','邮件预览');const close=add('button','❌',panel);close.setAttribute('aria-label','关闭邮件预览');close.onclick=()=>host.remove();root.addEventListener('keydown',e=>{if(e.key==='Escape')host.remove();});
 add('p',email?.enabled?'收件人：'+email.to:'邮件未启用：请检查项目通知开关和收件人。',panel);add('p',email?.subject||'',panel);add('p','交互报告附件：'+(email?.attachments?.map(x=>x.name).join('、')||'无')+'；实际投递由 Power Automate 邮件步骤执行。',panel);
 const frame=document.createElement('iframe');frame.setAttribute('sandbox','');frame.title='邮件正文';frame.srcdoc=email?.bodyHtml||'<p>未配置邮件正文</p>';panel.append(frame);close.focus();
};
hub.previewMailReports=entries=>{
 document.getElementById('jira-plus-mail-reports')?.remove();const host=document.createElement('div');host.id='jira-plus-mail-reports';document.documentElement.append(host);const root=host.attachShadow({mode:'open'}),style=document.createElement('style');style.textContent=':host{font:14px system-ui;color:#24334d}.overlay{position:fixed;inset:0;background:#14284666;z-index:2147483647;display:grid;place-items:center}.panel{background:white;padding:22px;border-radius:12px;width:min(680px,90vw);max-height:80vh;overflow:auto}button{cursor:pointer;background:#edf3ff;color:#245de8;border:1px solid #dbe4ef;border-radius:6px;padding:8px;margin:4px}section{border-bottom:1px solid #e3eaf4;padding:12px}p{font-size:12px;overflow-wrap:anywhere}';root.append(style);const overlay=document.createElement('div');overlay.className='overlay';root.append(overlay);const panel=document.createElement('div');panel.className='panel';overlay.append(panel);const add=(tag,text,parent=panel)=>{const n=document.createElement(tag);n.textContent=text;parent.append(n);return n;};const close=add('button','❌');close.setAttribute('aria-label','关闭邮件报告');close.onclick=()=>host.remove();add('h2','邮件与交互报告预览');add('p','此窗口只预览和下载，不发送消息。邮件需由 Power Automate 的发送邮件步骤投递。');for(const entry of entries){const section=add('section','');add('b',entry.key,section);add('p',entry.email?.enabled?'收件人：'+entry.email.to:'邮件未启用：请检查通知开关和收件人。',section);add('button','预览邮件正文',section).onclick=()=>hub.previewEmail(entry.email);add('button','下载交互报告',section).onclick=()=>hub.downloadFile(entry.file);}close.focus();
};
// Shared independent drilldown window for Sprint and Epic. Render only trusted DOM text.
hub.showIssueDetails=(title,items,period)=>{
  document.getElementById('jira-plus-issue-details')?.remove();
  const host=document.createElement('div');host.id='jira-plus-issue-details';document.documentElement.append(host);
  const root=host.attachShadow({mode:'open'}),style=document.createElement('style');
  style.textContent=`:host{all:initial;font:13px/1.6 -apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;color:#24334d}*{box-sizing:border-box}.backdrop{position:fixed;inset:0;z-index:2147483647;background:#14284655;display:flex;align-items:center;justify-content:center;padding:20px}.window{background:#fff;border:1px solid #dbe3ef;border-radius:14px;box-shadow:0 20px 80px #14284655;width:1000px;max-width:96vw;height:580px;max-height:90vh;resize:both;overflow:auto;display:flex;flex-direction:column}header{display:flex;gap:15px;align-items:center;padding:15px 20px;border-bottom:1px solid #e7edf6;position:sticky;top:0;background:#fff}h2{font-size:16px;margin:0;flex:1}button{cursor:pointer;border:0;border-radius:7px;background:#fff1f2;color:#d13438;padding:4px 7px}main{padding:12px 20px;overflow:auto;flex:1}input{font:inherit;padding:8px;border:1px solid #dbe3ef;border-radius:7px;width:100%;margin-bottom:12px}table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:10px;border-bottom:1px solid #e7edf6}th{background:#f3f6fb;color:#63738d}a{color:#245de8}small{color:#718098}`;
  root.append(style);const add=(tag,text,parent)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;parent.append(n);return n;};
  const backdrop=add('div',null,root);backdrop.className='backdrop';const panel=add('section',null,backdrop);panel.className='window';panel.setAttribute('role','dialog');panel.setAttribute('aria-modal','true');panel.setAttribute('aria-label',title);
  const header=add('header',null,panel);add('h2',title,header);const close=add('button','❌',header);close.setAttribute('aria-label','关闭工单明细');const focus=document.activeElement;
  const dismiss=()=>{host.remove();focus?.focus();};close.onclick=dismiss;backdrop.onclick=e=>{if(e.target===backdrop)dismiss();};root.addEventListener('keydown',e=>{if(e.key==='Escape'){e.stopPropagation();dismiss();}});
  const body=add('main',null,panel),search=add('input',null,body);search.placeholder='搜索 Jira 编号、摘要、Assignee 或状态';search.setAttribute('aria-label','筛选工单明细');const count=add('small',null,body),table=add('table',null,body),head=add('thead',null,table),tr=add('tr',null,head);['Jira','摘要','Assignee',period.before+' → '+period.after].forEach(x=>add('th',x,tr));const rows=add('tbody',null,table);
  const render=()=>{rows.replaceChildren();const query=search.value.trim().toLowerCase(),filtered=items.filter(x=>[x.issue.key,x.issue.fields.summary,x.issue.fields.assignee?.displayName,x.before?.name,x.after?.name].join(' ').toLowerCase().includes(query));count.textContent=filtered.length+' / '+items.length+' 条';for(const x of filtered){const row=add('tr',null,rows),cell=add('td',null,row),a=add('a',x.issue.key,cell);a.href=location.origin+'/browse/'+encodeURIComponent(x.issue.key);a.target='_blank';a.rel='noopener noreferrer';add('td',x.issue.fields.summary||'',row);add('td',x.issue.fields.assignee?.displayName||'未分配',row);add('td',(x.before?.name||'尚未创建')+' → '+(x.after?.name||'尚未创建'),row);}};search.oninput=render;render();close.focus();
};
// Load the native installer only after the user chooses Export; never during Jira startup.
let macTemplatePromise;
function loadMacAppTemplate(){
 if(macTemplatePromise)return macTemplatePromise;
 macTemplatePromise=new Promise((resolve,reject)=>{
  GM_xmlhttpRequest({method:'GET',url:'https://raw.githubusercontent.com/taomorrow/Jira-Monitor/main/src/mac-app-template.base64',anonymous:true,timeout:30000,
   onload:async response=>{try{
    if(response.status!==200)throw Error('安装器下载失败（HTTP '+response.status+'），请检查 GitHub 连接后重试。');
    const encoded=String(response.responseText||'').trim();if(!encoded||encoded.length>1000000)throw Error('安装器数据无效。');
    const hash=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(encoded));
    const actual=[...new Uint8Array(hash)].map(x=>x.toString(16).padStart(2,'0')).join('');
    if(actual!=='bd0a33587d5ebd6aa76fbb56282b8dbd608e1daeea93a4fa52d4f85a9d7346b6')throw Error('安装器校验失败，请更新 Jira+ 后重新导出。未生成安装文件。');
    const template=JSON.parse(atob(encoded));resolve(template);
   }catch(error){reject(error);}},
   onerror:()=>reject(Error('无法下载 Mac 安装器，请检查 GitHub 连接后重试。')),
   ontimeout:()=>reject(Error('Mac 安装器下载超时，请重试。'))});
 }).catch(error=>{macTemplatePromise=null;throw error;});
 return macTemplatePromise;
}
// A stored ZIP preserves Unix executable permissions, unlike a downloaded .command file.
async function macAppArchive(installer){
 const encoder=new TextEncoder(),folder='Jira+ Installer.app/Contents/';
 const template=await loadMacAppTemplate();
 // Keep signed app contents immutable; schedule payload stays beside the app.
 const files=template.map(([path,data,mode])=>[folder+path,Uint8Array.from(atob(data),c=>c.charCodeAt(0)),mode]);
 files.push(['Jira-Monitor-Schedule.sh',encoder.encode(installer),0o100644]);
 const crc32=bytes=>{let crc=0xffffffff;for(const b of bytes){crc^=b;for(let bit=0;bit<8;bit++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}return (crc^0xffffffff)>>>0;};
 const chunks=[],directory=[];let offset=0;
 for(const [path,content,mode] of files){
  const name=encoder.encode(path),data=typeof content==='string'?encoder.encode(content):content,crc=crc32(data),header=new Uint8Array(30+name.length),h=new DataView(header.buffer);
  h.setUint32(0,0x04034b50,true);h.setUint16(4,20,true);h.setUint16(6,0x800,true);h.setUint16(12,0x21,true);h.setUint32(14,crc,true);h.setUint32(18,data.length,true);h.setUint32(22,data.length,true);h.setUint16(26,name.length,true);header.set(name,30);
  const central=new Uint8Array(46+name.length),c=new DataView(central.buffer);c.setUint32(0,0x02014b50,true);c.setUint16(4,0x0314,true);c.setUint16(6,20,true);c.setUint16(8,0x800,true);c.setUint16(14,0x21,true);c.setUint32(16,crc,true);c.setUint32(20,data.length,true);c.setUint32(24,data.length,true);c.setUint16(28,name.length,true);c.setUint32(38,(mode<<16)>>>0,true);c.setUint32(42,offset,true);central.set(name,46);
  chunks.push(header,data);directory.push(central);offset+=header.length+data.length;
 }
 const size=directory.reduce((n,c)=>n+c.length,0),end=new Uint8Array(22),e=new DataView(end.buffer);e.setUint32(0,0x06054b50,true);e.setUint16(8,files.length,true);e.setUint16(10,files.length,true);e.setUint32(12,size,true);e.setUint32(16,offset,true);
 const archive=new Uint8Array(offset+size+end.length);let index=0;for(const chunk of [...chunks,...directory,end]){archive.set(chunk,index);index+=chunk.length;}return archive;
}
// Scheduled jobs contain references and preferences only; never credentials.
const JOB_STORE='jira-plus-jobs-v1',JOB_LOG='jira-plus-job-runs-v1';
hub.jobRunners={};
// One offline HTML attachment; each existing report runs in an isolated tab frame.
function jiraPlusReportAttachment(items,project){
 const labels={coe:'COE',sprint:'Sprint',epic:'Epic'},esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const reports=items.map(item=>{const email=item.payload.email||{},files=email.attachments||[];if(files.length)return {menu:item.menu,label:labels[item.menu],files:files.map(f=>({name:f.name,data:f.contentBytes}))};if(item.menu!=='coe')throw Error(labels[item.menu]+' 交互报告未生成，未发送；请重新扫描');const html='<!doctype html><meta charset="utf-8"><title>COE 扫描摘要</title><body style="font:14px Arial;color:#24334d">'+(email.bodyHtml||'<p>本次扫描无符合条件的预警工单。</p>')+'</body>';return {menu:item.menu,label:'COE',files:[{name:'COE 扫描摘要',data:jiraPlusEncode(html)}]};});
 const data=JSON.stringify(reports).replace(/[<>&\u2028\u2029]/g,c=>'\\u'+c.charCodeAt(0).toString(16).padStart(4,'0'));
 const html='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Jira+ · '+esc(project)+' · 合并交互报告</title><style>*{box-sizing:border-box}body{margin:0;background:#f3f6fc;color:#24334d;font:14px/1.6 Arial,sans-serif}header{padding:18px 24px;background:white;border-bottom:1px solid #dce5f3}h1{font-size:22px;margin:0 0 5px}p{margin:0;color:#718098}nav{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}button{font:inherit;border:1px solid #dce5f3;border-radius:8px;padding:8px 18px;background:#fff;color:#344b70;cursor:pointer}button[aria-selected="true"]{background:#245de8;color:white;border-color:#245de8}iframe{display:block;width:100%;height:calc(100vh - 180px);min-height:500px;border:0;background:#f3f6fc}#file-tabs{padding:8px 24px;margin:0}#file-tabs:empty{display:none}</style><header><h1>Jira+ · '+esc(project)+' · 合并交互报告</h1><p>扫描快照 · 切换 COE / Sprint / Epic，点击统计数字查看 Jira 明细及负责人。</p><nav id="menus" role="tablist" aria-label="分析菜单"></nav></header><nav id="file-tabs"></nav><iframe id="report" title="交互报告" sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox"></iframe><script type="application/json" id="report-data">'+data+'</script><script>('+jiraPlusReportRuntime.toString()+')();</script></html>';
 return {name:'JiraPlus-'+project+'-Combined-Report.html',contentType:'text/html',contentBytes:jiraPlusEncode(html)};
}
function jiraPlusEncode(html){const bytes=new TextEncoder().encode(html);let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(binary);}
function jiraPlusReportRuntime(){const reports=JSON.parse(document.getElementById('report-data').textContent),menus=document.getElementById('menus'),files=document.getElementById('file-tabs'),frame=document.getElementById('report');const show=file=>{const bytes=Uint8Array.from(atob(file.data),c=>c.charCodeAt(0));frame.srcdoc=new TextDecoder().decode(bytes);};const select=(report,index)=>{for(const [i,b] of [...menus.children].entries())b.setAttribute('aria-selected',String(i===index));files.replaceChildren();for(const file of report.files)if(report.files.length>1){const button=document.createElement('button');button.textContent=file.name;button.onclick=()=>show(file);files.append(button);}frame.title=report.label+' 交互报告';show(report.files[0]);};for(const [index,report] of reports.entries()){const button=document.createElement('button');button.textContent=report.label;button.setAttribute('role','tab');button.setAttribute('aria-selected','false');button.onclick=()=>select(report,index);menus.append(button);}if(reports.length)select(reports[0],0);}

// Bundle only explicitly selected Job notifications; manual menu sends stay unchanged.
function jiraPlusWebhook(value){return new URL(String(value).trim().replace(/\\&/g,'&').replace(/&amp;/g,'&')).href;}
function jiraPlusRecipients(values){return [...new Set(values.map(x=>String(x).trim().toLowerCase()).filter(Boolean))].sort().join(';');}
function jiraPlusTeamsSelection(items,project,emailEnabled){
 const labels={coe:'COE',sprint:'Sprint',epic:'Epic'},all=items.map(x=>x.menu);
 for(const menus of [all,all.filter(m=>m!=='epic'),all.filter(m=>m==='coe')]){
  if(!menus.length)continue;const selected=items.filter(x=>menus.includes(x.menu));if(selected.some(x=>x.payload.teams?.enabled===false||!x.payload.attachments?.length))continue;
  const cards=selected.flatMap(x=>x.payload.attachments),body=selected.flatMap(item=>item.payload.attachments.flatMap(c=>[{type:'TextBlock',text:labels[item.menu],weight:'Bolder',size:'Medium',separator:true,wrap:true},...(c.content?.body||[]),...(c.content?.actions?.length?[{type:'ActionSet',actions:c.content.actions}]:[])])),omitted=all.filter(m=>!menus.includes(m));
  if(omitted.length)body.push({type:'TextBlock',text:'因 Teams 大小限制，本卡片仅包含 '+menus.map(m=>labels[m]).join(' + ')+'。'+(emailEnabled?'全部所选结果见邮件及交互附件。':'未启用邮件，其他所选菜单未发送。'),wrap:true,isSubtle:true});
  const attachment={contentType:'application/vnd.microsoft.card.adaptive',content:{$schema:'http://adaptivecards.io/schemas/adaptive-card.json',type:'AdaptiveCard',version:'1.2',msteams:{width:'Full',entities:cards.flatMap(c=>c.content?.msteams?.entities||[])},body:[{type:'TextBlock',text:project+' · '+menus.map(m=>labels[m]).join(' / '),weight:'Bolder',size:'Large',wrap:true},...body]}};
  if(new TextEncoder().encode(JSON.stringify([attachment])).length<=26*1024)return {attachment,menus,omitted};
 }
 return {attachment:null,menus:[],omitted:all};
}
function jiraPlusMergeDeliveries(entries,job){
 const grouped=new Map(),order=['coe','sprint','epic'];
 for(const entry of [...entries].sort((a,b)=>order.indexOf(a.menu)-order.indexOf(b.menu))){const p=entry.payload,key=String(p.projectKey||'');if(!key)throw Error('合并通知缺少项目 Key，未发送');const url=jiraPlusWebhook(entry.url);if(!grouped.has(key))grouped.set(key,[]);const group=grouped.get(key);if(group.length&&group[0].url!==url)throw Error(key+' 扫描期间通知地址已变化，未发送');group.push({...entry,url});}
 return [...grouped.values()].map(items=>{const first=items[0],names=items.map(x=>({coe:'COE',sprint:'Sprint',epic:'Epic'})[x.menu]),title=first.payload.projectKey+' · '+names.join(' / '),emails=items.map(x=>x.payload.email).filter(e=>e?.enabled),recipients=[...new Set(emails.flatMap(e=>e.recipients||String(e.to||'').split(';')).filter(Boolean))];
 if(job.email&&!recipients.length)throw Error(title+' 未配置邮件收件人');
 const selection=jiraPlusTeamsSelection(items,first.payload.projectKey,job.email),teams=job.teams&&!!selection.attachment;if(job.teams&&!teams&&!job.email)throw Error('COE 或所选菜单仍超过 Teams 大小限制，请启用邮件后重试');
 const email=job.email?{enabled:true,recipients,to:recipients.join(';'),subject:'[Jira+] '+title,bodyText:emails.map((e,i)=>names[i]+'\n'+(e.bodyText||'')).join('\n\n'),bodyHtml:emails.map(e=>'<div style="margin-bottom:24px">'+(e.bodyHtml||'')+'</div>').join(''),attachments:job.attach?[jiraPlusReportAttachment(items,first.payload.projectKey)]:[]}:{enabled:false};
 if(email.enabled){email.bodyHtml=email.bodyHtml.replace(/<p data-jira-plus-report[\s\S]*?<\/p>/g,'').replace(/<p[^>]*>附交互报告：[\s\S]*?<\/p>/g,'');if(email.attachments.length)email.bodyHtml+='<p style="font:13px Arial;color:#718098">已附合并交互报告：'+email.attachments[0].name+'。下载后用浏览器打开，可切换 COE / Sprint / Epic 并点击数字查看明细。</p>';}
 return {url:first.url,payload:{type:'message',reportType:'job-summary',projectKey:first.payload.projectKey,text:title+'\n'+items.map(x=>x.payload.text||x.payload.summary||'扫描完成').join('\n\n'),summary:title,menus:items.map(x=>x.menu),teams:{enabled:teams,menus:teams?selection.menus:[],omittedMenus:job.teams?selection.omitted:[]},deliveryMode:teams?'teams-and-email':'email-only',attachments:teams?[selection.attachment]:[],email},emailOnly:job.teams&&!teams};
 });
}
function jiraPlusValidateDeliveries(deliveries,job,target){for(const d of deliveries){const current=target(d.payload.projectKey+'-1');if(!current)throw Error(d.payload.projectKey+' 通知未启用，未发送');if(jiraPlusWebhook(current.webhook)!==d.url)throw Error(d.payload.projectKey+' Webhook 配置已变化，未发送');if(job.email&&jiraPlusRecipients(current.recipients||[])!==jiraPlusRecipients(d.payload.email.recipients))throw Error(d.payload.projectKey+' 邮件收件人配置已变化，未发送');}}
async function jiraPlusFlush(job){const entries=jiraPlusPending||[];jiraPlusPending=null;const deliveries=jiraPlusMergeDeliveries(entries,job);jiraPlusValidateDeliveries(deliveries,job,key=>hub.target(key));for(const d of deliveries){await new Promise((resolve,reject)=>GM_xmlhttpRequest({method:'POST',url:d.url,headers:{'Content-Type':'application/json'},data:JSON.stringify(d.payload),timeout:30000,onload:r=>r.status>=200&&r.status<300?resolve():reject(Error('合并通知失败 HTTP '+r.status+'；未自动重试')),onerror:()=>reject(Error('合并通知网络失败，结果未知；未自动重试')),ontimeout:()=>reject(Error('合并通知超时，结果未知；未自动重试'))}));}const reductions=deliveries.filter(d=>d.payload.teams.enabled&&d.payload.teams.omittedMenus.length).map(d=>d.payload.projectKey+' Teams 已按大小限制缩减为 '+d.payload.teams.menus.map(m=>({coe:'COE',sprint:'Sprint',epic:'EPIC'})[m]).join(' + ')+(job.email?'；邮件和交互附件保留全部所选结果':'；未启用邮件，其他菜单未发送'));const menus=[...new Set(entries.map(e=>e.menu))].map(m=>({coe:'COE',sprint:'Sprint',epic:'EPIC'})[m]).join(' / ');return reductions.length?reductions.join('；')+(deliveries.some(d=>d.emailOnly)?'；部分项目仅发送邮件':''):deliveries.some(d=>d.emailOnly)?'所选数量超过 Teams 大小限制，所选数据只通过邮件发送（'+menus+'）':deliveries.length?'已按项目合并提交 '+menus+'；最终投递请查看工作流':'扫描完成，没有可推送的数据';}

const jobDefaultUrl='https://jira.xpaas.lenovo.com/issues/?filter=180929';
function jobList(){return GM_getValue(JOB_STORE,[]);}
function validJob(value){
 const j={...value};if(!/^[a-z0-9-]{1,80}$/.test(j.id))throw Error('Job 编号无效');
 const u=new URL(j.url);if(u.origin!==location.origin||u.pathname!=='/issues/'||u.username||u.password||(!u.searchParams.get('filter')&&!u.searchParams.get('jql')))throw Error('请填写当前 Jira 的 /issues/ 查询链接（filter 或 jql）。');u.hash='';j.url=u.href;
 j.name=String(j.name||'未命名 Job').slice(0,80);j.times=[...new Set(String(Array.isArray(j.times)?j.times.join(','):j.times).split(/[,，\s]+/).filter(Boolean))].sort();
 if(!j.times.length||j.times.some(t=>!/^([01]\d|2[0-3]):[0-5]\d$/.test(t)))throw Error('时间请填写 09:00,21:00，可填写多个时间。');
 j.menus=[...new Set(j.menus||[])];if(!j.menus.length||j.menus.some(x=>!['coe','sprint','epic'].includes(x)))throw Error('请至少选择一个执行菜单。');
 j.combine=j.combine===true;j.pushMenus=[...new Set(j.pushMenus||j.menus)];if(j.combine&&(!j.pushMenus.length||j.pushMenus.some(x=>!['coe','sprint','epic'].includes(x))))throw Error('请至少选择一个合并推送菜单。');if(j.combine)j.menus=[...new Set([...j.menus,...j.pushMenus])];
 j.period=j.period==='week'?'week':'day';j.days=j.days==='weekdays'?'weekdays':'daily';j.projects=String(j.projects||'').trim().toUpperCase();if(j.projects&&!/^[A-Z][A-Z0-9_]*(\/[A-Z][A-Z0-9_]*)*$/.test(j.projects))throw Error('推送项目用 / 分隔，例如 CSP/OSPIT；留空使用全部已启用项目。');
 for(const key of ['enabled','teams','email','attach'])j[key]=j[key]===true;return j;
}
function jobSlot(j,now=new Date()){
 if(j.days==='weekdays'&&(now.getDay()===0||now.getDay()===6))return null;
 const minutes=now.getHours()*60+now.getMinutes();const time=[...j.times].reverse().find(t=>{const [h,m]=t.split(':').map(Number);return minutes-h*60-m>=0&&minutes-h*60-m<=10;});
 return time?`${now.getFullYear()}-${now.getMonth()+1}-${now.getDate()} ${time}`:null;
}
function jobLog(id,patch){const logs=GM_getValue(JOB_LOG,{});logs[id]={...logs[id],...patch,updatedAt:new Date().toISOString()};GM_setValue(JOB_LOG,logs);return logs[id];}
hub.deliveryPayload=payload=>{
 const job=hub.jobDelivery;if(!job)return payload;
 if(!job.email)payload.email={enabled:false};
 if(!job.teams){payload.attachments=[];payload.teams={enabled:false};payload.deliveryMode='email-only';}
 else if(!payload.teams)payload.teams={enabled:true};
 return payload;
};
hub.jobProjectAllowed=key=>!hub.jobDelivery?.projects||hub.jobDelivery.projects.split('/').includes(key);
async function executeJob(id,manual=false){
 const job=validJob(jobList().find(j=>j.id===id)||{});if(!job.enabled)throw Error('此 Job 尚未启用，请在配置中心勾选启用并保存。');
 const target=new URL(job.url),here=new URL(location.href);here.hash='';if(here.href!==target.href)throw Error('当前页面与 Job 查询不一致，请从调度页或 Job 的“立即运行”打开。');
 const slot=manual?'手动 '+new Date().toISOString():jobSlot(job);if(!slot)throw Error('未到此 Job 的执行时间，或已超过 10 分钟启动窗口。');
 const execute=async()=>{
  const current=jobList().find(x=>x.id===id);if(!current?.enabled)return;
  if(JSON.stringify(validJob(current))!==JSON.stringify(job))throw Error('等待期间 Job 配置已变化，请重新打开。');
  const old=GM_getValue(JOB_LOG,{})[id];if(!manual&&old?.slot===slot&&old.status!=='queued')return;
  if(hub.jobDelivery)throw Error('已有 Job 正在执行，请稍后再试。');
  jobLog(id,{slot,status:'running',message:'正在执行 '+job.menus.join(' → ')});hub.jobDelivery=job;
  if(job.combine)jiraPlusPending=[];
  try{for(const menu of ['coe','sprint','epic'].filter(m=>job.menus.includes(m))){jiraPlusMenu=menu;if(!hub.jobRunners[menu])throw Error(menu+' 模块尚未就绪');hub.show(menu==='coe'?'timeout':menu);await hub.jobRunners[menu](job.combine&&!job.pushMenus.includes(menu)?{...job,teams:false,email:false}:job);}
   const combinedMessage=job.combine?await jiraPlusFlush(job):null;
   jobLog(id,{status:'completed',message:combinedMessage||'已完成；通知提交不代表最终送达，请查看工作流。'});
  }catch(error){jobLog(id,{status:'failed',message:String(error.message).slice(0,700)+'；未自动重试。'});throw error;}finally{hub.jobDelivery=null;jiraPlusPending=null;jiraPlusMenu=null;}
 };
 if(!navigator.locks?.request)throw Error('浏览器不支持 Job 防重复锁，请使用新版 Chrome。');
 // A single origin-wide lock serializes different jobs and duplicate tabs.
 return navigator.locks.request('jira-plus-scheduled-jobs',execute);
}
hub.executeJob=executeJob;
const jobXml=value=>String(value).replace(/[<>&"']/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&apos;'}[c]));
function macInstaller(jobs,browser){
 const enabled=jobs.filter(j=>j.enabled).map(validJob);if(!enabled.length)throw Error('请先保存并启用至少一个 Job。');
 const blocks=enabled.map(j=>{
  const url=new URL(j.url);url.hash=new URLSearchParams({'jm-job':j.id}).toString();
  const calendar=j.times.flatMap(t=>{const [h,m]=t.split(':').map(Number);return (j.days==='weekdays'?[1,2,3,4,5]:[null]).map(day=>'<dict><key>Hour</key><integer>'+h+'</integer><key>Minute</key><integer>'+m+'</integer>'+(day===null?'':'<key>Weekday</key><integer>'+day+'</integer>')+'</dict>');}).join('');
  const label='com.taomorrow.jira-plus.job.'+j.id;
  const xml='<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd"><plist version="1.0"><dict><key>Label</key><string>'+label+'</string><key>ProgramArguments</key><array><string>/usr/bin/open</string><string>-a</string><string>'+jobXml(browser)+'</string><string>'+jobXml(url.href)+'</string></array><key>StartCalendarInterval</key><array>'+calendar+'</array></dict></plist>';
  const bytes=new TextEncoder().encode(xml);let binary='';for(const b of bytes)binary+=String.fromCharCode(b);
  return "printf '%s' '"+btoa(binary)+"' | /usr/bin/base64 -D > \"$agent_dir/"+label+".plist\"\n/usr/bin/plutil -lint \"$agent_dir/"+label+".plist\"\n/bin/launchctl bootstrap \"gui/$uid\" \"$agent_dir/"+label+".plist\"";
 });
 return '#!/bin/bash\nset -e\nagent_dir="$HOME/Library/LaunchAgents"\nuid=$(/usr/bin/id -u)\n/bin/mkdir -p "$agent_dir"\n# Replace only Jira+ jobs exported by this feature.\nfor old in "$agent_dir"/com.taomorrow.jira-plus.job.*.plist; do\n [ -f "$old" ] || continue\n /bin/launchctl bootout "gui/$uid" "$old" 2>/dev/null || true\n /bin/rm "$old"\ndone\n'+blocks.join('\n')+'\necho "Jira+ 定时任务已安装。使用 Mac 当前系统时区；请保持电脑唤醒、Jira 登录有效。"\n';
}
hub.macInstaller=macInstaller;
hub.renderJobs=()=>{
 hub.settings.querySelector('#job-settings-dialog')?.remove();
 const open=el('button','定时 Job 设置',hub.settings);open.id='open-job-settings';
 const dialog=el('dialog',null,hub.settings);dialog.id='job-settings-dialog';dialog.style.cssText='width:min(860px,92vw);max-height:86vh;overflow:auto;border:1px solid #dbe3f0;border-radius:16px;padding:22px;color:#172b4d;box-shadow:0 20px 80px #091e4240';
 const close=el('button','❌',dialog);close.id='job-settings-close';close.setAttribute('aria-label','关闭 Job 设置');close.style.cssText='position:sticky;top:0;float:right;color:red;background:#fff1f2;z-index:1';close.onclick=()=>dialog.close();
 open.onclick=()=>dialog.showModal();
 const panel=el('section',null,dialog);panel.id='scheduled-jobs';el('h2','定时 Job',panel);el('p','在此配置 Job、时间和通知，保存后由固定 Jira 标签页调度。修改配置后自动生效，不需要导出安装器。',panel);
 hub.renderBrowserScheduler(panel);
 const entries=[],list=el('div',null,panel),status=el('p',null,panel);status.setAttribute('role','status');
 const addJob=value=>{
  const card=el('fieldset',null,list);card.style.cssText='border:1px solid #dbe3f0;border-radius:10px;margin:12px 0;padding:14px;display:grid;gap:8px';
  const j={id:crypto.randomUUID(),name:'Jira 每日分析',url:jobDefaultUrl,times:['09:00','21:00'],menus:['coe'],period:'day',days:'daily',enabled:false,teams:false,email:false,attach:true,projects:'',combine:true,...value};const controls={};
  const field=(key,title,type='text')=>{const label=el('label',title+' ',card),input=el('input',null,label);input.type=type;if(type==='checkbox')input.checked=j[key];else input.value=Array.isArray(j[key])?j[key].join(','):j[key];input.dataset.jobField=key;controls[key]=input;return input;};
  field('enabled','启用 Job','checkbox');field('name','名称');field('url','Jira 查询页面').style.width='100%';field('times','每日时间（多个用逗号分隔）');
  const select=(key,title,options)=>{const label=el('label',title+' ',card),input=el('select',null,label);for(const [v,name] of options){const o=el('option',name,input);o.value=v;}input.value=j[key];controls[key]=input;};
  select('days','执行日期',[['daily','每天'],['weekdays','周一至周五']]);select('period','对比维度',[['day','昨天 / 今天'],['week','上周 / 本周']]);
  const menus=el('div','执行菜单：',card),checks=[];for(const [key,name] of [['coe','COE'],['sprint','Sprint'],['epic','Epic']]){const label=el('label',name+' ',menus),check=el('input',null,label);check.type='checkbox';check.value=key;check.checked=j.menus.includes(key);checks.push(check);}
  el('small','分析当前查询全部分页；Sprint 默认排除 CLOSED 和未分配项；Epic 分组及状态全部勾选。',card);field('projects','推送项目（如 CSP/OSPIT；留空为全部已启用项目）');field('teams','完成后发送 Teams','checkbox');field('email','完成后发送邮件','checkbox');field('attach','邮件附交互报告','checkbox');field('combine','一键合并推送（所选结果合并为一封邮件 / 一张 Teams 卡片）','checkbox');const push=el('div','推送菜单（可单选或多选）：',card),pushChecks=[];for(const [key,name] of [['coe','COE'],['sprint','Sprint'],['epic','EPIC']]){const label=el('label',name+' ',push),check=el('input',null,label);check.type='checkbox';check.dataset.jobPush=key;check.value=key;check.checked=(j.pushMenus||j.menus).includes(key);pushChecks.push(check);}el('small','按 COE → Sprint → EPIC 合并；Teams 超限先保留 COE + Sprint，再仅 COE；邮件及交互报告保留全部所选结果。不同项目分别投递。',card);
  const log=GM_getValue(JOB_LOG,{})[j.id];el('small',log?`${new Date(log.updatedAt).toLocaleString('zh-CN',{hour12:false})} · ${{running:'运行中',completed:'已完成',failed:'失败',queued:'等待运行'}[log.status]||log.status} · ${log.message}`:'尚未执行',card);
  const entry={card,removed:false,read:()=>validJob({...j,...Object.fromEntries(Object.entries(controls).map(([key,n])=>[key,n.type==='checkbox'?n.checked:n.value])),menus:checks.filter(x=>x.checked).map(x=>x.value),pushMenus:pushChecks.filter(x=>x.checked).map(x=>x.value)})};entries.push(entry);
  el('button','删除 Job',card).onclick=()=>{entry.removed=true;card.remove();};el('button','立即运行（先保存并启用）',card).onclick=()=>{try{const saved=jobList().find(x=>x.id===j.id);if(!saved?.enabled)throw Error('请先保存并启用此 Job。');const u=new URL(saved.url);u.hash=new URLSearchParams({'jm-job':saved.id,'jm-manual':'1'});window.open(u.href,'_blank','noopener');}catch(e){status.textContent=e.message;}};
 };
 const stored=jobList();(stored.length?stored:[{}]).forEach(addJob);
 el('button','新增 Job',panel).onclick=()=>addJob({});
 el('button','保存 Job 配置',panel).onclick=()=>{try{const jobs=entries.filter(e=>!e.removed).map(e=>e.read());GM_setValue(JOB_STORE,jobs);status.textContent='Job 已保存，固定标签页在下一次检查时读取新配置。请点击“设此标签页为调度页”，并保留该标签。';}catch(e){status.textContent=e.message;}};
 const advanced=el('details',null,panel);el('summary','高级：旧 Mac 系统调度（固定标签方式不需要）',advanced);
 const browser=el('select',null,advanced);for(const name of ['Google Chrome','Microsoft Edge']){const o=el('option',name,browser);o.value=name;}
 const exportMac=el('button','导出 Mac 定时启动器',advanced);exportMac.onclick=async()=>{exportMac.disabled=true;status.textContent='正在下载并校验 Mac 安装器…';try{const installer=macInstaller(jobList(),browser.value);hub.downloadFile({name:'Jira-Monitor-Mac-Installer.zip',type:'application/zip',html:await macAppArchive(installer)});status.textContent='已导出。双击 ZIP 解压，保持 .app 与 Jira-Monitor-Schedule.sh 在同一文件夹，再双击 .app 点击“安装”。首次若被 macOS 拦截，可在系统设置 → 隐私与安全性中查看“仍要打开”。修改时间后重新导出安装。';}catch(e){status.textContent=e.message;}finally{exportMac.disabled=false;}};
 el('p','停用全部 Mac 启动任务：先在配置中心取消启用并保存（脚本立即停止执行）。删除系统任务的方法见仓库 JOBS.md。页面重复打开时同一时间点只执行一次；失败不自动重试，可查看 Job 日志后手动运行。',advanced);
};
hub.startScheduled=()=>{
 const params=new URLSearchParams(location.hash.slice(1)),id=params.get('jm-job');if(!id)return;
 executeJob(id,params.get('jm-manual')==='1').catch(error=>{hub.configure?.();const p=el('p','Job 未完成：'+error.message,hub.settings);p.setAttribute('role','alert');});
};
// Opt-in dispatcher: only a retained Jira tab checks the local clock; analysis runs in separate tabs.
const BROWSER_SCHEDULE='jira-plus-browser-schedule-v1',BROWSER_DISPATCH='jira-plus-browser-dispatch-v1',SCHEDULER_TAB='jira-plus-scheduler-tab-v1';
let browserScheduleTimer=null,browserScheduleBusy=false,browserScheduleLast='',browserScheduleError='';
const initialPageTitle=document.title;
const schedulerTab=()=>sessionStorage.getItem(SCHEDULER_TAB)==='1'&&!new URLSearchParams(location.hash.slice(1)).has('jm-job');
function browserScheduleStatus(){
 const n=hub.settings.querySelector('#browser-scheduler-status');if(!n)return;
 const enabled=GM_getValue(BROWSER_SCHEDULE,false)===true;
 n.textContent=!enabled?'浏览器调度已停止。':!schedulerTab()?'浏览器调度已启用；此标签不是调度页。请保留已设为调度页的 Jira 标签。':'此标签正在调度，请右键标签选择“固定”。'+(browserScheduleLast?' 最近检查：'+browserScheduleLast+'。':'')+(browserScheduleError?' '+browserScheduleError:'');
}
async function browserSchedulerTick(){
 if(!schedulerTab()||GM_getValue(BROWSER_SCHEDULE,false)!==true){if(browserScheduleTimer!==null)clearInterval(browserScheduleTimer);browserScheduleTimer=null;if(schedulerTab())document.title=initialPageTitle;browserScheduleStatus();return;}
 if(browserScheduleBusy)return;
 browserScheduleBusy=true;browserScheduleError='';
 try{
  if(!navigator.locks?.request)throw Error('浏览器不支持防重复锁，请使用新版 Chrome。');
  await navigator.locks.request('jira-plus-browser-dispatch',{ifAvailable:true},async lock=>{
   if(!lock||!schedulerTab()||GM_getValue(BROWSER_SCHEDULE,false)!==true)return;
   const records=GM_getValue(BROWSER_DISPATCH,{}),now=new Date();
   for(const raw of jobList()){
    if(!raw.enabled)continue;
    let job;try{job=validJob(raw);}catch(error){browserScheduleError='有 Job 配置无效：'+error.message;continue;}
    const slot=jobSlot(job,now);if(!slot)continue;
    const last=GM_getValue(JOB_LOG,{})[job.id];
    if(records[job.id]?.slot===slot||last?.slot===slot)continue;
    // Claim before opening; a second fixed tab cannot open the same slot again.
    records[job.id]={slot,openedAt:now.toISOString()};GM_setValue(BROWSER_DISPATCH,records);
    jobLog(job.id,{slot,status:'queued',message:'调度页已打开任务标签，等待运行；若一直等待，请检查扩展启用及 Jira 登录。'});
    try{
     if(typeof GM_openInTab!=='function')throw Error('无法打开任务标签，请检查扩展状态。');
     const url=new URL(job.url);url.hash=new URLSearchParams({'jm-job':job.id}).toString();
     const opened=GM_openInTab(url.href,{active:false,insert:true,setParent:false});
     if(opened&&typeof opened.then==='function')await opened;
    }catch(error){jobLog(job.id,{status:'failed',message:'无法打开任务页：'+error.message+'；未自动重试。'});browserScheduleError=error.message;}
   }
  });
  browserScheduleLast=new Date().toLocaleTimeString('zh-CN',{hour12:false});
 }catch(error){browserScheduleError=error.message;}
 finally{browserScheduleBusy=false;browserScheduleStatus();}
}
hub.startBrowserScheduler=()=>{
 if(browserScheduleTimer!==null)clearInterval(browserScheduleTimer);browserScheduleTimer=null;
 if(!schedulerTab()||GM_getValue(BROWSER_SCHEDULE,false)!==true){browserScheduleStatus();return;}
 document.title='◷ Jira+ 调度中';
 // A low-frequency clock check does not fetch Jira data or run scans in the retained tab.
 browserScheduleTimer=setInterval(()=>browserSchedulerTick(),30000);
 void browserSchedulerTick();browserScheduleStatus();
};
hub.renderBrowserScheduler=panel=>{
 const card=el('fieldset',null,panel);card.id='browser-scheduler';card.style.cssText='border:1px solid #dbe3f0;border-radius:10px;padding:12px;margin:12px 0;background:#edf3ff';
 el('strong','固定标签页调度（推荐）',card);el('p','保留此 Jira 标签页即可，到点会自动新建后台任务标签。无需 Mac 安装器。使用本机时区；电脑需保持唤醒、Jira 登录有效。',card);
 el('p',null,card).id='browser-scheduler-status';
 const start=el('button','设此标签页为调度页',card);start.id='browser-scheduler-start';start.onclick=()=>{
  if(new URLSearchParams(location.hash.slice(1)).has('jm-job')){browserScheduleError='任务执行页不能同时作为调度页，请另开一个普通 Jira 页面。';const p=card.querySelector('#browser-scheduler-status');p.textContent=browserScheduleError;return;}
  sessionStorage.setItem(SCHEDULER_TAB,'1');GM_setValue(BROWSER_SCHEDULE,true);hub.startBrowserScheduler();
 };
 const stop=el('button','停止浏览器调度',card);stop.id='browser-scheduler-stop';stop.onclick=()=>{GM_setValue(BROWSER_SCHEDULE,false);sessionStorage.removeItem(SCHEDULER_TAB);if(browserScheduleTimer!==null)clearInterval(browserScheduleTimer);browserScheduleTimer=null;document.title=initialPageTitle;browserScheduleStatus();};
 el('small','每 30 秒检查一次；多个调度页自动防重复。关闭或冻结全部调度页将停止检查，恢复时仅补触发最近 10 分钟内的时间点。已开始的任务不会因停止调度而中止。请停用旧 Mac 定时项。',card);
 browserScheduleStatus();
};
addEventListener('pagehide',()=>{if(browserScheduleTimer!==null)clearInterval(browserScheduleTimer);browserScheduleTimer=null;});
addEventListener('pageshow',()=>hub.startBrowserScheduler());
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')void browserSchedulerTick();});
function initTimeout(detailOnly){
  'use strict';
  // ================= 只需修改这里的规则配置 =================
  const CONFIG = {
    fridayAdjustment: {enabled:true, firstMinute:630, secondMinute:1020, firstSubtractDays:1, subtractDays:2}, // 本地周五10:30起减1天，17:00起减2天
    // 即将超期 自动通知；收件人由此 Webhook 的个人聊天工作流决定。
    autoNotifyApproaching: false, // false：只手动发送
    notificationCooldownHours: 24, // 同一工单24小时内最多提交一次（仅自动发送；手动发送不限次数）
    mentionAssignee: true, // Jira 返回邮箱或下方映射存在时，构造真正的 @提及
    teamsMentionUsers: {}, // 'jira账号': {id:'Teams登录邮箱或Entra用户ID', name:'姓名'}
    teamsWebhookUrl: '',

    // minDays：即将超期起点（含）；maxDays：已超期起点（含）。
    // 天数<下限符合预期，下限≤天数<上限即将超期，天数≥上限已超期；1天=24小时。
    // 批量自动提醒针对即将超期/已超期；手动发送不受冷却限制。
    rules: [
      {name:'DEV', description:'In Progress-Ready For Test', minDays:4, maxDays:5, currentStatuses:['In Progress'],
       startStatus:'In Progress', forbiddenAfterStart:['Completed','Complete','SIT','Ready For UAT','UAT','Ready For Deploy','Deployed','Done','Cancelled']},
      {name:'DCT', description:'In Progress-( / Ready For Test / Testing)-Complete', minDays:13, maxDays:14, currentStatuses:['In Progress','Ready For Test','Testing'],
       startStatus:'In Progress', forbiddenAfterStart:['Completed','Complete','SIT','Ready For UAT','UAT','Ready For Deploy','Deployed','Done','Cancelled']},
    ],
    detailTimeoutSeconds: 90,
    scanScope: 'all', // all：全部筛选结果；page：当前分页
    panelHeightPx: 520,
    panelBottomPx: 68, // 为页面右下角的翻页按钮留出空间
  };
  // ================= 规则配置结束 =================
  const DEFAULT_RULES=JSON.parse(JSON.stringify(CONFIG.rules));
  if (window.top !== window.self) return;
  const isDashboard=()=>/^\/secure\/Dashboard\.jspa$/i.test(location.pathname);

  const badge=document.createElement('div');
  badge.textContent='Jira+ v6.10.4 已注入，正在初始化…';
  badge.style.cssText='position:fixed!important;top:8px!important;right:12px!important;z-index:2147483647!important;background:#0052cc!important;color:white!important;padding:8px!important;font:13px Arial!important;max-width:80vw!important;white-space:pre-wrap!important';
  (document.body||document.documentElement).append(badge);
  function report(error) {
    const text='Jira+ v6.10.4 启动失败：'+(error?.message||error);
    badge.textContent=text;badge.style.background='#ae2a19';
    (document.body||document.documentElement).append(badge);
    const box=document.createElement('div');box.textContent=text+'。请检查代码开头 CONFIG 配置。';
    box.style.cssText='position:fixed!important;right:16px!important;top:60px!important;z-index:2147483647!important;background:white!important;color:#ae2a19!important;border:2px solid #ae2a19!important;padding:18px!important;max-width:450px!important;font:14px Arial!important';
    document.documentElement.append(box);console.error('[Jira+]',error);
  }
  try {

  // Public release: notification credentials stay in this user's userscript storage.
  if(window.top!==window.self)return;
  const WEBHOOK_SETTING='jira-plus-webhook';
  const AUTO_SETTING='jira-plus-auto-notify';
  try{
    // 优先读取油猴持久化配置；正常升级不写入或清空已有地址。
    const savedWebhook=GM_getValue(WEBHOOK_SETTING,null);
    if(savedWebhook!==null)CONFIG.teamsWebhookUrl=savedWebhook;
    else if(supportedWebhook(CONFIG.teamsWebhookUrl))GM_setValue(WEBHOOK_SETTING,CONFIG.teamsWebhookUrl); // 保存旧版手改 CONFIG 的地址，供以后升级使用。
    CONFIG.autoNotifyApproaching=GM_getValue(AUTO_SETTING,CONFIG.autoNotifyApproaching)===true;
  }catch{}
  function supportedWebhook(value){
    try{hub.validateWebhook(value);return true;}catch{return false;}
  }
  const EMAIL_SETTING='jira-plus-email-v1';
  function parseEmailRecipients(value){
    const entries=String(value||'').split(/[\s,;，；]+/).filter(Boolean),seen=new Set(),result=[];
    for(const email of entries){
      if(!/^[A-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9](?:[A-Z0-9-]*[A-Z0-9])?(?:\.[A-Z0-9](?:[A-Z0-9-]*[A-Z0-9])?)+$/i.test(email))throw Error('邮箱格式无效：'+email);
      const key=email.toLowerCase();if(!seen.has(key)){seen.add(key);result.push(email);}
    }
    return result;
  }
  function emailConfig(){
    const value=GM_getValue(EMAIL_SETTING,{enabled:false,recipients:[]});
    return {enabled:value?.enabled===true,recipients:parseEmailRecipients(Array.isArray(value?.recipients)?value.recipients.join(';'):'')};
  }
  function emailPayload(current,rules,text,jiraUrl,target){
    const settings={enabled:!!target?.recipients?.length,recipients:target?.recipients||[]};
    if(!settings.enabled)return {enabled:false};
    if(!settings.recipients.length)throw Error('邮件已启用但收件人为空，请打开邮件设置');
    const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    return {enabled:true,recipients:settings.recipients,to:settings.recipients.join(';'),subject:'[Jira+] '+String(current.key).replace(/[\r\n]/g,'')+' · '+rules.map(r=>r.name+' '+r.sla).join(' / '),bodyText:text,bodyHtml:hub.emailCard({title:current.key+' · 超时预警',subtitle:current.summary+' · 负责人：'+(current.assignee||'未分配'),sections:[{title:'规则分析',headers:['规则','结果','时长（天）'],rows:rules.map(r=>[r.name,r.sla,r.days.toFixed(2)])}],meta:'扫描时间：'+beijingTime(current.checkedAt),url:jiraUrl})};
  }
  const PROJECT_SETTING='jira-plus-projects-v1';
  const projectKeyOf=key=>String(key||'').trim().match(/^([A-Z][A-Z0-9_]*)-\d+$/i)?.[1]?.toUpperCase()||'';
  function projectKeys(value){
    const parts=String(value||'').split('/').map(x=>x.trim().toUpperCase());
    if(parts.some(x=>!/^[A-Z][A-Z0-9_]*$/.test(x)))throw Error('项目 Key 无效：'+value+'；多个项目请用 / 分隔，如 CSP/OSPIT');
    if(new Set(parts).size!==parts.length)throw Error('项目 Key 重复：'+value);
    return parts;
  }
  function rawProjectConfigs(){if(typeof GM_getValue!=='function')return [];const data=GM_getValue(PROJECT_SETTING,[]);if(!Array.isArray(data))throw Error('项目配置格式无效，请打开配置中心');return data;}
  function projectConfigs(){return rawProjectConfigs().flatMap(row=>projectKeys(row.projectKey).map(projectKey=>({...row,projectKey,projectGroup:row.projectKey})));}
  function projectTarget(key){const projectKey=projectKeyOf(key);const rows=projectConfigs().filter(r=>r.projectKey===projectKey);if(rows.length>1)throw Error(projectKey+' 项目配置重复');return rows[0]&&rows[0].enabled!==false?{...rows[0],projectKey}:null;}
  function configureCenter(){
    hub.show('settings');hub.settings.replaceChildren();const overlay={remove:()=>hub.show('timeout')},box=hub.settings;
    const add=(tag,text,attr,parent=box)=>{const x=document.createElement(tag);if(text)x.textContent=text;if(attr)x.setAttribute(attr,'');parent.append(x);return x;};
    add('h2','Configuration');hub.renderJobs();
    const autoLabel=add('label',null,'data-auto-setting'),auto=add('input',null,'data-auto-detail',autoLabel);auto.type='checkbox';auto.checked=hub.autoDetail;add('span','详情自动分析 · 在 Jira 详情页右下角独立弹出',null,autoLabel);auto.onchange=()=>hub.setAuto(auto.checked);

    add('p','项目 Key 取工单编号横杠前的值，如 CSP-3909 → CSP。多个项目可用 / 分隔（如 CSP/OSPIT），共用此行 Webhook、收件人和通知开关。未配置或未启用的项目只统计、不发送；邮件通过该项目 Webhook 对应工作流发送。');
    const table=add('table',null,'data-project-table');table.style.cssText='width:100%;border-collapse:collapse';
    const head=add('tr',null,null,table);for(const label of ['项目 Key','Teams Webhook','Email 收件人（多个用分号）','启用通知','批量自动通知','操作'])add('th',label,null,head);
    const rows=[];
    function row(value={}){
      const tr=add('tr',null,'data-project-row',table),key=add('input',null,'data-project-key',add('td',null,null,tr));key.value=value.projectKey||'';key.style.width='100%';key.placeholder='CSP/OSPIT';
      const webhook=add('textarea',null,'data-project-hook',add('td',null,null,tr));webhook.value=value.webhook||'';webhook.rows=3;webhook.style.width='95%';
      const emails=add('textarea',null,'data-project-emails',add('td',null,null,tr));emails.value=(value.recipients||[]).join(';');emails.rows=3;emails.style.width='95%';
      const enabled=add('input',null,'data-project-enabled',add('td',null,null,tr));enabled.type='checkbox';enabled.checked=value.enabled!==false;enabled.setAttribute('aria-label','启用项目通知');
      const auto=add('input',null,'data-project-auto',add('td',null,null,tr));auto.type='checkbox';auto.checked=value.autoNotify===true;
      const remove=add('button','删除',null,add('td',null,null,tr)),entry={tr,key,webhook,emails,enabled,auto,deleted:false};rows.push(entry);remove.onclick=()=>{entry.deleted=true;tr.hidden=true;};return entry;
    }
    const stored=rawProjectConfigs();if(stored.length)stored.forEach(row);else{row({projectKey:'CSP'});row({projectKey:'OSPIT'});}
    add('button','新增项目','data-project-add').onclick=()=>row();
    const legacyKey=add('input',null,'data-legacy-key');legacyKey.placeholder='要导入旧设置的项目 Key';
    const status=add('p',null,'data-project-status');
    add('button','复制旧设置到项目','data-project-import').onclick=()=>{try{
      const key=projectKeys(legacyKey.value).join('/');
      const target=rows.find(r=>!r.deleted&&r.key.value.trim()&&projectKeys(r.key.value).some(k=>projectKeys(key).includes(k)))||row({projectKey:key});
      const oldMail=emailConfig();target.webhook.value=CONFIG.teamsWebhookUrl||'';target.emails.value=(oldMail.enabled?oldMail.recipients:[]).join(';');target.auto.checked=CONFIG.autoNotifyApproaching;
      status.textContent='旧设置已复制到 '+key+'，请检查后保存';
    }catch(error){status.textContent=safeError(error);}};
    add('button','保存项目配置','data-project-save').onclick=()=>{try{
      const result=[],seen=new Set();
      for(const r of rows.filter(r=>!r.deleted)){
        const key=r.key.value.trim().toUpperCase(),webhook=r.webhook.value.trim(),recipients=parseEmailRecipients(r.emails.value);
        if(!key&&!webhook&&!recipients.length&&!r.auto.checked)continue;
        const keys=projectKeys(key);for(const member of keys){if(seen.has(member))throw Error('项目 Key 重复：'+member);seen.add(member);}
        if(webhook&&!supportedWebhook(webhook))throw Error(key+' Webhook 地址不支持');
        if((r.auto.checked||recipients.length)&&!webhook)throw Error(key+' 自动通知/邮件需要配置 Webhook');
        result.push({projectKey:keys.join('/'),webhook,recipients,autoNotify:r.auto.checked,enabled:r.enabled.checked});
      }
      GM_setValue(PROJECT_SETTING,result);if(JSON.stringify(GM_getValue(PROJECT_SETTING,null))!==JSON.stringify(result))throw Error('存储回读失败');
      dispatchEvent(new Event('jira-plus-project-config'));render();status.style.color='#00875a';status.textContent='已保存并验证 '+result.length+' 组配置，覆盖 '+result.flatMap(r=>projectKeys(r.projectKey)).length+' 个项目，本页立即生效';
    }catch(error){status.style.color='#ae2a19';status.textContent='保存失败：'+safeError(error);}};
    add('button','连接诊断（HEAD，不推送）','data-project-diagnose').onclick=()=>{
      const key=legacyKey.value.trim().toUpperCase(),target=projectConfigs().find(r=>r.projectKey===key||r.projectGroup===key);
      if(!target?.webhook){status.textContent='请在左侧输入框填写已保存的项目 Key，诊断其 Webhook';return;}
      status.textContent='正在进行 HEAD 连接诊断，未发送消息…';
      GM_xmlhttpRequest({method:'HEAD',url:target.webhook,anonymous:true,redirect:'error',timeout:15000,
        onload:r=>{status.textContent='HEAD HTTP '+r.status+'；仅验证网络可达性，不代表卡片或邮件投递成功。未发送消息。';},
        onerror:()=>{status.textContent='HEAD 网络失败，请检查 VPN 和油猴域名权限。未发送消息。';},
        ontimeout:()=>{status.textContent='HEAD 诊断超时。未发送消息。';}});
    };
    add('hr');add('button','统计规则设置','data-center-rules').onclick=configureRules;
    add('button','启动诊断').onclick=()=>alert(badge.textContent+'\n页面：'+location.href);
  }
  if(!detailOnly&&typeof GM_registerMenuCommand==='function')GM_registerMenuCommand('Jira+：配置中心',configureCenter);
  const RULE_SETTING='jira-plus-rules-v1';
  const parseStatuses=value=>[...new Set(String(value||'').split(/[\n,;，；]+/).map(x=>x.trim()).filter(Boolean))];
  function configureRules(){
    const overlay=document.createElement('div');overlay.style.cssText='position:fixed;inset:0;z-index:2147483647;background:#0005;display:flex;align-items:center;justify-content:center';
    const shadow=overlay.attachShadow({mode:'open'}),box=document.createElement('div');box.style.cssText='background:white;color:#172b4d;padding:20px;border-radius:8px;width:760px;max-width:92vw;max-height:85vh;overflow:auto;font:14px Arial';shadow.append(box);
    const add=(tag,text,attr,parent=box)=>{const x=document.createElement(tag);if(text)x.textContent=text;if(attr)x.setAttribute(attr,'');parent.append(x);return x;};
    box.style.position='relative';
    const closeRule=add('button','❌','data-rule-close');closeRule.setAttribute('aria-label','关闭统计规则');closeRule.style.cssText='position:sticky;top:0;float:right;margin:0 0 10px 12px;color:#dc3545;background:#fff1f2;border:0;border-radius:8px;width:30px;height:30px;cursor:pointer;z-index:1';closeRule.onclick=()=>overlay.remove();
    add('b','统计规则设置');add('p','全项目共用；阈值单位为自然天，支持0.01天（14.4分钟）。下限≤天数＜上限：即将超期；天数≥上限：已超期。按本地周五时间：10:30前不提前，10:30起提前1天，17:00起提前2天。保存用于新扫描，已有结果及运行/暂停中的任务保留原规则。');
    const rows=[];
    function build(rule){
      const group=add('fieldset',null,'data-rule-row');group.style.marginBottom='12px';add('legend',rule.name,null,group);const fields={};
      for(const [key,label,multi] of [['name','规则名称'],['description','流程说明'],['minDays','预警下限（含）'],['maxDays','超期上限（含）'],['currentStatuses','当前状态范围（每行一个或用逗号/分号分隔）',true],['startStatus','起始状态（取首次进入的时间）'],['forbiddenAfterStart','起点后排除状态（可留空；每行一个或用逗号/分号分隔）',true]]){
        add('label',label,null,group).style.cssText='display:block;margin-top:8px';const input=add(multi?'textarea':'input',null,'data-rule-'+key,group);input.style.cssText='width:100%;box-sizing:border-box';
        if(key==='minDays'||key==='maxDays'){input.type='number';input.min='0';input.step='0.01';}
        if(multi)input.rows=3;
        input.value=Array.isArray(rule[key])?rule[key].join('\n'):String(rule[key]??'');fields[key]=input;
      }rows.push(fields);
    }
    CONFIG.rules.forEach(build);
    const status=add('p',null,'data-rule-status');
    add('button','保存规则','data-rule-save').onclick=()=>{try{
      const rules=rows.map(fields=>{
        if(!fields.minDays.value.trim()||!fields.maxDays.value.trim())throw Error('阈值不能为空');
        return {name:fields.name.value.trim(),description:fields.description.value.trim(),minDays:Number(fields.minDays.value),maxDays:Number(fields.maxDays.value),currentStatuses:parseStatuses(fields.currentStatuses.value),startStatus:fields.startStatus.value.trim(),forbiddenAfterStart:parseStatuses(fields.forbiddenAfterStart.value)};
      });validateRules(rules);
      GM_setValue(RULE_SETTING,rules);if(JSON.stringify(GM_getValue(RULE_SETTING,null))!==JSON.stringify(rules))throw Error('存储回读失败');
      CONFIG.rules=rules;dispatchEvent(new Event('jira-plus-project-config'));render();status.style.color='#00875a';status.textContent='规则已保存并验证。请开始新扫描或重新分析；已有结果不自动重算。';
    }catch(error){status.style.color='#ae2a19';status.textContent='保存失败：'+safeError(error);}};
    add('button','填入默认规则（保存后生效）','data-rule-default').onclick=()=>{
      if(rows.length!==DEFAULT_RULES.length){status.textContent='当前规则数量与默认配置不一致，请检查';return;}
      rows.forEach((fields,i)=>{for(const key of Object.keys(fields)){const value=DEFAULT_RULES[i][key];fields[key].value=Array.isArray(value)?value.join('\n'):String(value);}});status.textContent='已填入默认值，点击保存规则后生效';
    };
    (document.body||document.documentElement).append(overlay);
  }
  const norm=s=>String(s||'').replace(/[_\s-]+/g,' ').trim().toUpperCase();
  function validateRules(rules){
    const names=new Set();
    if(!Array.isArray(rules)||!rules.length)throw new Error('至少配置一条规则');
    for(const r of rules){
      if(!r.name||names.has(r.name))throw new Error('规则名称必须唯一');names.add(r.name);
      if(!Number.isFinite(r.minDays)||!Number.isFinite(r.maxDays)||r.minDays<0||r.maxDays<=r.minDays)throw new Error(r.name+'：KPI 下限/上限无效，要求 0 ≤ 下限 < 上限');
      if(!Array.isArray(r.currentStatuses)||!r.currentStatuses.length||!r.startStatus||!Array.isArray(r.forbiddenAfterStart))throw new Error(r.name+'：状态配置无效');
    }
  }
  const dayText=n=>n===null?'':(n/86400).toFixed(2);
  function effectiveRule(rule,scanTime){
    const ms=typeof scanTime==='number'?scanTime:Date.parse(scanTime);
    const local=new Date(ms),friday=Number.isFinite(ms)&&local.getDay()===5;
    const adjustment=CONFIG.fridayAdjustment,minute=local.getHours()*60+local.getMinutes();
    const shift=adjustment?.enabled&&friday?(minute>=adjustment.secondMinute?adjustment.subtractDays:minute>=adjustment.firstMinute?adjustment.firstSubtractDays:0):0;
    return {...rule,minDays:Math.max(0,rule.minDays-shift),maxDays:Math.max(0,rule.maxDays-shift),fridayShiftDays:shift};
  }
  function resultRule(result,rule){
    if(Number.isFinite(result?.effectiveMinDays)&&Number.isFinite(result?.effectiveMaxDays))return {...rule,minDays:result.effectiveMinDays,maxDays:result.effectiveMaxDays};
    return result?.checkedAt?effectiveRule(rule,result.checkedAt):rule;
  }
  const ruleText=base=>`${base.name}｜即将超期：${base.minDays}≤天数＜${base.maxDays}；已超期：≥${base.maxDays}天；`;
  function panelDuration(result,rule){
    rule=resultRule(result,rule);
    if(!result||!Number.isFinite(result.seconds))return {level:'unknown',text:result?.status||'未读取到'};
    const days=result.seconds/86400,duration=dayText(result.seconds)+'天';
    if(days>=rule.maxDays){const excess=(days-rule.maxDays).toFixed(2);return {level:'overdue',text:duration+'（已超期 '+excess+' 天）'};}
    if(days>=rule.minDays&&days<rule.maxDays)return {level:'warning',text:duration+'（即将超期）'};
    return {level:'normal',text:duration+'（符合预期）'};
  }
  // 北京时间只用于表示同一时刻；计算使用绝对时间戳，不给 Duration 额外加8小时。
  function beijingTime(value){
    if(value===null||value===undefined||value==='')return '';
    const ms=typeof value==='number'?value:Date.parse(value);
    if(!Number.isFinite(ms))return '';
    return new Date(ms+8*3600000).toISOString().replace('T',' ').replace('Z',' +08:00');
  }
  function evaluateHistory(events,currentStatus,rules,now){
    // 按绝对时间升序，从完整历史选择首次起点；返工不重置计时。
    const sorted=[...events].sort((a,b)=>a.at-b.at||a.order-b.order);
    return rules.map(originalRule=>{
      const rule=effectiveRule(originalRule,now);
      const base={name:rule.name,seconds:null,currentStatus,checkedAt:new Date(now).toISOString(),effectiveMinDays:rule.minDays,effectiveMaxDays:rule.maxDays,fridayShiftDays:rule.fridayShiftDays};
      if(!rule.currentStatuses.map(norm).includes(norm(currentStatus)))return {...base,status:'不在统计范围',details:'当前状态：'+currentStatus};
      const index=sorted.findIndex(e=>norm(e.to)===norm(rule.startStatus));
      if(index<0)return {...base,status:'未发现起始记录',details:'History 中无进入 '+rule.startStatus+' 的记录'};
      const start=sorted[index];
      if(sorted.slice(index+1).some(e=>rule.forbiddenAfterStart.map(norm).includes(norm(e.to))))return {...base,status:'后续流程已发生',details:'首次进入 '+rule.startStatus+' 后存在配置的排除状态'};
      if(!Number.isFinite(start.at)||start.at>now)return {...base,status:'读取失败',details:'起始时间无效或晚于当前系统时间'};
      const elapsed=(now-start.at)/1000;
      return {...base,status:'已统计',seconds:elapsed,inRange:elapsed>=rule.minDays*86400&&elapsed<rule.maxDays*86400,startAt:new Date(start.at).toISOString(),details:'首次 New: '+rule.startStatus+'；当前系统时间减起始时间；来源：'+(start.source||'History REST 精确时间')};
    });
  }
  function makeXlsx(rows){
    const esc=v=>String(v??'').replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g,'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    const enc=new TextEncoder();
    const sheet='<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><cols><col min="1" max="14" width="25" customWidth="1"/></cols><sheetData>'+rows.map((r,i)=>'<row r="'+(i+1)+'">'+r.values.map((v,j)=>{
      const c=String.fromCharCode(65+j)+(i+1),style=i>0&&(j===8||j===9)?({warning:5,overdue:6}[r.level]||4):({header:1,warning:2,overdue:3}[r.level]||0);
      return typeof v==='number'&&Number.isFinite(v)?`<c r="${c}" s="${style}"><v>${v}</v></c>`:`<c r="${c}" s="${style}" t="inlineStr"><is><t xml:space="preserve">${esc(v)}</t></is></c>`;
    }).join('')+'</row>').join('')+'</sheetData><hyperlinks>'+rows.map((row,i)=>row.jiraUrl?`<hyperlink ref="A${i+1}" r:id="jira${i}"/>`:'').join('')+'</hyperlinks></worksheet>';
    const files={
      '[Content_Types].xml':'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>',
      '_rels/.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
      'xl/workbook.xml':'<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Jira KPI" sheetId="1" r:id="rId1"/></sheets></workbook>',
      'xl/_rels/workbook.xml.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>',
      'xl/styles.xml':'<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="3"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/></font><font><b/><color rgb="FF9C0006"/><sz val="11"/></font></fonts><fills count="5"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFD9E1F2"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFFF00"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFC7CE"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="7"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFill="1" applyFont="1"/><xf numFmtId="0" fontId="0" fillId="3" borderId="0" xfId="0" applyFill="1"/><xf numFmtId="0" fontId="2" fillId="4" borderId="0" xfId="0" applyFill="1" applyFont="1"/><xf numFmtId="2" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="2" fontId="0" fillId="3" borderId="0" xfId="0" applyNumberFormat="1" applyFill="1"/><xf numFmtId="2" fontId="2" fillId="4" borderId="0" xfId="0" applyNumberFormat="1" applyFill="1" applyFont="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>',
      'xl/worksheets/sheet1.xml':sheet,
      'xl/worksheets/_rels/sheet1.xml.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+rows.map((row,i)=>row.jiraUrl?`<Relationship Id="jira${i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="${esc(row.jiraUrl)}" TargetMode="External"/>`:'').join('')+'</Relationships>',
    };
    const chunks=[],central=[];let offset=0;
    const header=n=>new Uint8Array(n),u16=(a,p,n)=>new DataView(a.buffer).setUint16(p,n,true),u32=(a,p,n)=>new DataView(a.buffer).setUint32(p,n>>>0,true);
    for(const [name,text] of Object.entries(files)){
      const path=enc.encode(name),data=enc.encode('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'+text);
      let crc=0xffffffff;for(const b of data){crc^=b;for(let k=0;k<8;k++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}crc=(crc^0xffffffff)>>>0;
      const local=header(30);u32(local,0,0x04034b50);u16(local,4,20);u32(local,14,crc);u32(local,18,data.length);u32(local,22,data.length);u16(local,26,path.length);
      chunks.push(local,path,data);
      const c=header(46);u32(c,0,0x02014b50);u16(c,4,20);u16(c,6,20);u32(c,16,crc);u32(c,20,data.length);u32(c,24,data.length);u16(c,28,path.length);u32(c,42,offset);central.push(c,path);offset+=local.length+path.length+data.length;
    }
    const size=central.reduce((n,a)=>n+a.length,0),end=header(22);u32(end,0,0x06054b50);u16(end,8,Object.keys(files).length);u16(end,10,Object.keys(files).length);u32(end,12,size);u32(end,16,offset);
    const all=[...chunks,...central,end],out=new Uint8Array(all.reduce((n,a)=>n+a.length,0));let at=0;for(const a of all){out.set(a,at);at+=a.length;}return out;
  }
  const STORE = 'jira-plus-batch-v5';
  const DETAIL_STORE=detailOnly?'jira-plus-auto-detail-v1':'jira-plus-manual-detail-v1';
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const readState=key=>{try{return JSON.parse(sessionStorage.getItem(key));}catch{return null;}};
  const isDetail=()=>/^\/browse\//i.test(location.pathname);
  const get=()=>{
    const batch=readState(STORE);
    if(!detailOnly&&(batch?.active||batch?.paused))return batch;
    if(detailOnly)return readState(DETAIL_STORE);
    return isDetail()?readState(DETAIL_STORE):batch;
  };
  const save=s=>sessionStorage.setItem(s.mode==='single'?DETAIL_STORE:STORE,JSON.stringify(s));
  const keyOf = href => { try { const u=new URL(href,location.href); return u.searchParams.get('selectedIssue') || u.pathname.match(/\/browse\/([A-Z][A-Z0-9_]*-\d+)/i)?.[1]; } catch { return null; } };
  function readAssignee(doc=document) {
    const clean=node=>node?.textContent?.replace(/\s+/g,' ').trim()||'';
    const value=doc.querySelector('#assignee-val, [data-field-id="assignee"] .value, [data-field="assignee"] .value');
    if(value)return clean(value.querySelector('.user-hover, [rel]')||value)||'未分配';
    const people=doc.querySelector('#peoplemodule, #people-module, .people-details')||doc;
    for(const label of people.querySelectorAll('dt, .name, label')){
      if(!/^(assignee|经办人|指派人|负责人)\s*[:：]?$/i.test(clean(label)))continue;
      const next=label.nextElementSibling;
      const field=next||label.parentElement?.querySelector('dd, .value');
      if(field)return clean(field.querySelector('.user-hover')||field)||'未分配';
    }
    return '';
  }
  const readSummary=()=>document.querySelector('#summary-val, h1[data-field="summary"], #issue-header h1')?.textContent?.trim()||'';
  function summaryLinks() {
    const root = document.querySelector('#issuetable, .issue-table, [data-testid="issue-table"]');
    if (!root) return [];
    const map = new Map();
    for (const row of root.querySelectorAll('tr, [data-issuekey]')) {
      const a = row.querySelector('td.summary a.issue-link, td.summary a, .summary a, a[data-field="summary"]') || [...row.querySelectorAll('a[href*="/browse/"]')].find(a => !/^[A-Z][A-Z0-9_]*-\d+$/i.test(a.textContent.trim()));
      const key = a && (keyOf(a.href) || row.getAttribute('data-issuekey'));
      if (key && a) map.set(key,{key,summary:a.textContent.trim(),href:a.href,anchor:a,
        currentStatus:row.querySelector('td.status .aui-lozenge, td.status .jira-issue-status-lozenge, td.status, [data-field="status"]')?.textContent?.trim()||'',
        assignee:row.querySelector('td.assignee .user-hover, td.assignee, [data-field="assignee"]')?.textContent?.replace(/\s+/g,' ').trim()||''});
    }
    return [...map.values()];
  }
  // Shadow DOM 隔离 Jira 的页面样式；挂在根节点，避免被局部页面刷新移除。
  const host=document.createElement('div');
  host.id=detailOnly?'jira-detail-panel-host':'jira-duration-panel-host';
  host.style.cssText='display:block!important;position:fixed!important;inset:auto 16px 68px auto!important;width: min(430px, 90vw)!important;z-index:2147483647!important;visibility:visible!important;opacity:1!important';
  host.style.cssText='display:block;width:100%;position:relative';
  (detailOnly?hub.detail:hub.timeout).append(host);
  const shadow=host.attachShadow({mode:'open'});
  const css=document.createElement('style');
  css.textContent=`
    *{box-sizing:border-box}
    button,select,textarea{font:12px Arial,sans-serif;color:#172b4d}
    button{height:27px;padding:3px 10px;border:1px solid #c1c7d0;border-radius:5px;background:#f7f8fa;cursor:pointer;white-space:nowrap}
    button:hover:not(:disabled){background:#e9f2ff;border-color:#85b8ff}
    button:disabled{opacity:.45;cursor:default}
    [data-start]{background:#0052cc;color:white;border-color:#0052cc}
    [data-actions]{display:flex;align-items:center;gap:7px;flex:0 0 auto;padding:8px 0}
    [data-actions] button{flex:0 0 auto}
    [data-fold]{height:23px;padding:2px 8px;font-size:11px}
    p{margin:8px 0;line-height:1.45;flex:0 0 auto}
    [data-config]{font-size:12px;color:#5e6c84;white-space:pre-line}
    select,textarea{border:1px solid #dfe1e6;border-radius:5px;padding:5px 7px;background:white}
    select{flex:0 0 auto;margin-bottom:5px}
    [data-progress]{font-size:12px;color:#5e6c84;margin:3px 0 8px}
    [data-totals]{background:#f0f5ff;color:#0747a6;border-radius:5px;padding:8px 9px;margin:0 0 6px;font-weight:600}
    a{color:#0052cc;text-decoration:none} a:hover{text-decoration:underline}
  `;
  shadow.append(css);
  const panel=document.createElement('section');
  shadow.append(panel);
  function mountPanel(){if(!host.isConnected)(detailOnly?hub.detail:hub.timeout).append(host);panel.style.display='block';host.style.visibility='visible';}

  panel.style.cssText='box-sizing:border-box;position:relative;width:100%;height:min(520px,75vh);max-height:75vh;overflow:hidden;z-index:2147483647;background:#fff;color:#172b4d;border:2px solid #0052cc;border-radius:8px;padding:14px;box-shadow:0 4px 24px #0004;font:13px Arial';
  // 使用 DOM 构建，避免站点 Trusted Types 策略拒绝 innerHTML。
  const make=(tag,text,attr,parent)=>{const x=document.createElement(tag);if(text)x.textContent=text;if(attr)x.setAttribute(attr,'');parent.append(x);return x;};
  make('b','COE · 超时预警',null,panel);
  const fold=make('button','收起','data-fold',panel);fold.style.float='right';
  const body=make('div',null,'data-body',panel);
  body.style.cssText='display:flex;flex-direction:column;height:calc(100% - 24px);min-height:0';
  panel.style.height=`min(${CONFIG.panelHeightPx}px,75vh)`;
  make('p','规则加载中…','data-config',body);
  make('p','*本地周五：10:30前不预减；10:30起减1天；17:00起减2天（KPI上下限）。','data-friday-note',body).style.cssText='color:#de350b;font-size:12px;margin:0 0 10px;flex-shrink:0';
  const scope=make('select',null,'data-scope',body);
  const allOption=make('option','全部筛选结果',null,scope);allOption.value='all';
  const pageOption=make('option','仅当前分页',null,scope);pageOption.value='page';scope.value=CONFIG.scanScope;
  const jqlBox=make('textarea',null,'data-jql',body);jqlBox.placeholder='自动读取URL中的JQL；未读取到时请粘贴Advanced里的完整JQL';jqlBox.rows=2;
  jqlBox.style.cssText='width:100%;box-sizing:border-box;flex-shrink:0';
  jqlBox.value=new URL(location.href).searchParams.get('jql')||'';
  const actions=make('div',null,'data-actions',body);
  make('button','开始统计','data-start',actions);
  make('button','暂停','data-pause',actions);
  make('button','停止','data-stop',actions);
  make('button','导出 Excel','data-excel',actions);
  make('button',detailOnly?'发送 Teams':'发送预警列表','data-teams',actions);if(!detailOnly){make('button','预览邮件 / 报告','data-mail-preview',actions);make('button','导出交互报告','data-report-export',actions);}
  if(!detailOnly){const label=make('label',null,'data-empty-summary-setting',body);const check=document.createElement('input');check.type='checkbox';check.checked=GM_getValue('jira-plus-coe-empty-summary-v1',false)===true;check.setAttribute('data-empty-summary','');check.onchange=()=>{GM_setValue('jira-plus-coe-empty-summary-v1',check.checked);render();};label.append(check,document.createTextNode(' 无预警工单时推送扫描摘要（时间、条目数、状态）'));}
  // Teams 设置保留在油猴菜单，面板仅展示发送按钮。
  make('p',null,'data-notice',body).style.cssText='white-space:pre-wrap;overflow-wrap:anywhere;max-height:100px;overflow-y:auto';
  make('p',null,'data-teams-status',body).style.cssText='font-size:12px;color:#5e6c84';
  const errorBox=make('pre',null,'data-teams-errors',body);errorBox.hidden=true;errorBox.style.cssText='white-space:pre-wrap;overflow-wrap:anywhere;flex-shrink:0;max-height:130px;overflow-y:auto;color:#ae2a19;background:#fff1f0;padding:7px;font:12px Arial';
  make('p',null,'data-progress',body);make('p',null,'data-totals',body);const resultsBox=make('div',null,'data-results',body);
  resultsBox.style.cssText='flex:1;min-height:80px;overflow-y:auto;overscroll-behavior:contain';
  const theme=document.createElement('style');theme.textContent=`
    section{height:100%!important;max-height:none!important;border:0!important;border-radius:0!important;box-shadow:none!important;padding:20px!important;font:13px/1.6 -apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif!important}
    section>b{display:block;font-size:19px;margin-bottom:12px;color:#24334d} [data-fold]{display:none} [data-body]{height:calc(100% - 44px)!important;display:flex!important}
    button{height:32px;padding:5px 12px;border-radius:7px;border-color:#dbe3ef;background:white} [data-start]{background:#245de8;border-color:#245de8} [data-actions]{flex-wrap:wrap;gap:6px;padding:12px 0}
    [data-config]{background:#f3f6fc;padding:12px 14px;border-radius:9px;color:#64748b;line-height:1.8;margin:0 0 8px} [data-friday-note]{font-size:11px!important;color:#b67718!important}
    [data-totals]{background:#eaf0ff;border:1px solid #dee7ff;color:#245de8;padding:11px 13px;border-radius:8px} [data-results]>div{padding:12px 4px!important;border-bottom:1px solid #edf1f7!important;line-height:1.8}
    select{padding:8px;border-radius:7px;border-color:#dde5f0} [data-teams-status],[data-progress]{font-size:11px!important;color:#8996ab!important} [data-notice]:empty,[data-notice]:empty~[data-teams-errors][hidden]{display:none}
    :host{height:100%} [data-results]{min-height:80px!important} `;
  if(detailOnly){theme.textContent+='section{height:420px!important;padding:14px!important}section>b{display:none}[data-body]{height:100%!important}[data-friday-note]{display:none}';}
  shadow.append(theme);mountPanel();
  if(!detailOnly&&typeof GM_registerMenuCommand==='function') GM_registerMenuCommand('Jira+：显示统计面板',()=>{hub.show('timeout');mountPanel();fold.textContent='收起';body.hidden=false;body.style.display='flex';panel.style.height=`min(${CONFIG.panelHeightPx}px,75vh)`;});
  const el=s=>panel.querySelector(s);
  let ruleLoadError='';
  try{const saved=typeof GM_getValue==='function'?GM_getValue(RULE_SETTING,null):null;if(saved!==null){validateRules(saved);CONFIG.rules=saved;}}catch(error){ruleLoadError='已保存规则无效，本次使用代码默认规则：'+safeError(error);}
  validateRules(CONFIG.rules);
  el('[data-config]').textContent=CONFIG.rules.map(r=>ruleText(r)).join('\n');
  let busy=false, epoch=0, shownBatch='';
  function render() {
    const s=get();
    hub.syncRoute();
    if(!detailOnly&&!isDetail()&&s?.mode==='batch'&&(s.active||s.paused)&&shownBatch!==s.id){shownBatch=s.id;hub.show('timeout');}
    if(detailOnly)hub.syncDetail();
    el('[data-teams-status]').textContent='按项目通知：已配置 '+projectConfigs().length+' 个项目'+(s?.mode==='single'?' · 详情仅手动发送':' · 自动通知遵循各项目开关');
    el('[data-config]').textContent=(s?.rules||CONFIG.rules).map(r=>ruleText(r)).join('\n');
    el('[data-start]').disabled=!!s?.active||teamsSending;
    el('[data-start]').textContent=s?.paused?'开始统计':keyOf(location.href)&&!onOverview()?'重新分析':'开始统计';
    el('[data-pause]').disabled=!s?.active;
    el('[data-stop]').disabled=!s?.active&&!s?.paused;
    if(!detailOnly)el('[data-report-export]').disabled=el('[data-mail-preview]').disabled=!s?.results?.length||!!s?.active;
    el('[data-teams]').disabled=!!s?.active||teamsSending||(!s?.results?.some(item=>item.rules?.some(r=>Number.isFinite(r.seconds)))&&!(s?.mode==='batch'&&s.phase==='done'&&GM_getValue('jira-plus-coe-empty-summary-v1',false)===true));
    scope.disabled=!!(s?.active||s?.paused);jqlBox.disabled=scope.disabled;
    scope.hidden=isDashboard()||!!keyOf(location.href)&&!onOverview();jqlBox.hidden=true;
    el('[data-progress]').textContent=s ? `${s.paused?'已暂停':s.active?'运行中':'已结束/停止'} · ${s.index}/${s.queue.length} · ${s.message||''}` : (keyOf(location.href)?'点击重新分析当前详情':'点击开始统计当前总览页');
    const box=el('[data-results]'),oldScroll=box.scrollTop;box.replaceChildren();
    if(!s){el('[data-totals]').textContent=CONFIG.rules.map(rule=>`${rule.name} 即将超期：0`).join('；');return;}
    const rules=s.rules||CONFIG.rules;
    const summary=el('[data-totals]');
    summary.textContent=rules.map(rule=>{
      const count=s.results.filter(item=>{
        const r=item.rules?.find(result=>result.name===rule.name);
        return panelDuration(r,rule).level==='warning';
      }).length;
      return `${rule.name} 即将超期：${count}`;
    }).join('；');
    for(const item of s.results){
      const div=document.createElement('div'),a=document.createElement('a');a.href='/browse/'+item.key;a.target='_blank';a.rel='noopener';a.textContent=item.key;
      div.append(a,document.createTextNode(' · '+scanOwnerLabel(item)));
      const target=projectTarget(item.key);div.append(document.createTextNode(' · '+(target?.webhook?'通知分组：'+target.projectKey:'未配置通知目标')));
      if(item.rules){
        for(const result of item.rules){
          const rule=rules.find(r=>r.name===result.name)||{};
          const display=panelDuration(result,rule),span=document.createElement('span');
          span.textContent=result.name+' '+display.text;
          if(display.level==='overdue')span.style.cssText='color:#d1242f;font-weight:700';
          else if(display.level==='normal')span.style.cssText='color:#16803c;font-weight:700';
          else if(display.level==='warning')span.style.cssText='color:#b58100;font-weight:700;background:#fff7bd;padding:1px 3px';
          div.append(document.createTextNode(' · '),span);
        }
      }else div.append(document.createTextNode(' · '+item.status+' · '+(item.details||'—')));
      div.style.cssText='border-top:1px solid #ddd;padding:5px 0';box.append(div);
    }
    box.scrollTop=oldScroll;
  }
  function hasTeamsAlert(item,rulesConfig=CONFIG.rules){
    return item.rules?.some(r=>{
      const rule=rulesConfig.find(x=>x.name===r.name);
      return rule&&['warning','overdue'].includes(panelDuration(r,rule).level);
    })||false;
  }
  function baseTeamsPayload(current,rulesConfig=CONFIG.rules,automatic=true,target=projectTarget(current.key)){
    const jiraUrl=location.origin+'/browse/'+encodeURIComponent(current.key);
    const rules=(current.rules||[]).filter(r=>{
      const rule=rulesConfig.find(x=>x.name===r.name);
      return rule&&Number.isFinite(r.seconds)&&(!automatic||['warning','overdue'].includes(panelDuration(r,rule).level));
    }).map(r=>{
      const rule=rulesConfig.find(x=>x.name===r.name),d=panelDuration(r,rule);
      return {name:r.name,sla:{normal:'符合预期',warning:'即将超期',overdue:'已超期'}[d.level],days:Number(dayText(r.seconds)),startTime:beijingTime(r.startAt),level:d.level};
    });
    const assigneeEmail=current.assigneeEmail||'';
    const mapped=CONFIG.teamsMentionUsers[current.assigneeAccount];
    const mention=CONFIG.mentionAssignee&&(mapped?.id?mapped:assigneeEmail?{id:assigneeEmail,name:current.assignee}:null);
    const mentionName=mention?String(mention.name||current.assignee).replace(/[<>]/g,''):'';
    const mentionText=mention?'<at>'+mentionName+'</at>':'';
    const text=[current.key,current.summary,'负责人：'+current.assignee,...rules.map(r=>r.name+'：'+r.sla+' · '+r.days.toFixed(2)+'天'),jiraUrl,'扫描时间：'+beijingTime(current.checkedAt)].join('\n');
    return {type:'message',text,email:emailPayload(current,rules,text,jiraUrl,target),projectKey:projectKeyOf(current.key),jiraKey:current.key,jiraUrl,summary:current.summary,assignee:current.assignee,assigneeAccount:current.assigneeAccount,assigneeEmail,currentStatus:current.currentStatus,scanTime:beijingTime(current.checkedAt),rules,
      attachments:[{contentType:'application/vnd.microsoft.card.adaptive',contentUrl:null,content:{'$schema':'http://adaptivecards.io/schemas/adaptive-card.json',type:'AdaptiveCard',version:'1.2',msteams:{entities:mention?[{type:'mention',text:mentionText,mentioned:{id:mention.id,name:mentionName}}]:[]},body:[
        {type:'TextBlock',text:current.key,weight:'Bolder',size:'Medium',wrap:true},
        {type:'TextBlock',text:current.summary,wrap:true},
        {type:'TextBlock',text:'负责人：'+(mentionText||current.assignee),wrap:true},
        ...rules.map(r=>({type:'TextBlock',text:r.name+'：'+r.sla+' · '+r.days.toFixed(2)+'天',wrap:true,color:{normal:'Good',warning:'Warning',overdue:'Attention'}[r.level]})),
        {type:'TextBlock',text:'扫描时间：'+beijingTime(current.checkedAt),wrap:true,isSubtle:true}
      ],actions:[{type:'Action.OpenUrl',title:'打开 Jira',url:jiraUrl}]}}]};
  }
  function devOwnerLabel(item){return item.devAssignees?.map(u=>u.name).join('、')||(item.devAssignees?'子任务暂无已分配负责人':'请重新扫描子任务负责人');}
  function scanOwnerLabel(item){const dev=(item.rules||[]).some(r=>norm(r.name)==='DEV'&&Number.isFinite(r.seconds)),other=(item.rules||[]).some(r=>norm(r.name)!=='DEV'&&Number.isFinite(r.seconds));return dev?'DEV 子任务：'+devOwnerLabel(item)+(other?'；DCT：'+(item.assignee||'未分配'):''):(item.assignee||'未分配');}
  const bugIssueType=type=>/^(bug|缺陷|错误)$/i.test(String(type?.name||'').trim());
  const subtaskIssueType=type=>!bugIssueType(type)&&(type?.subtask===true||/^(subtask|子任务)$/i.test(String(type?.name||'').replace(/[\s_-]/g,'')));
  // Only verified Subtasks contribute DEV owners; never related Bugs or the Story owner.
  async function subtaskAssignees(fields,checkpoint){
    const users=new Map(),children=subtaskIssueType(fields.issuetype)?[{fields}]:fields.subtasks||[];
    for(const child of children){
      checkpoint();let data=child.fields||{},type=data.issuetype;
      if(type&&!subtaskIssueType(type))continue;
      if(!type||data.assignee===undefined){
        if(!child.key)throw Error('Sub-task 缺少工单编号，无法读取负责人');
        const issue=await api('/rest/api/2/issue/'+encodeURIComponent(child.key)+'?fields=assignee,issuetype');checkpoint();data=issue.fields||{};type=data.issuetype;
        if(!type)throw Error(child.key+' 未返回工单类型，无法确认 Sub-task');
        if(!subtaskIssueType(type))continue;
      }
      if(!Object.hasOwn(data,'assignee'))throw Error((child.key||'Sub-task')+' 未返回子任务负责人');
      const assignee=data.assignee;if(!assignee)continue;
      const user={name:assignee.displayName||assignee.name||assignee.emailAddress||'未命名用户',account:assignee.accountId||assignee.name||assignee.key||'',email:assignee.emailAddress||''};
      const id=String(user.email||user.account||user.name).toLowerCase();if(!users.has(id))users.set(id,user);
    }
    return [...users.values()];
  }
  function teamsPayload(current,rulesConfig=CONFIG.rules,automatic=true,target=projectTarget(current.key)){
    if(detailOnly||get()?.mode==='single')target={...target,recipients:[]};
    const base=baseTeamsPayload(current,rulesConfig,automatic,target),dev=base.rules.some(r=>norm(r.name)==='DEV'),other=base.rules.some(r=>norm(r.name)!=='DEV');
    if(!dev)return base;
    const users=[...(current.devAssignees||[])];
    if(other)users.push({name:current.assignee||'未分配',account:current.assigneeAccount||'',email:current.assigneeEmail||''});
    const unique=[...new Map(users.map(u=>[String(u.email||u.account||u.name).toLowerCase(),u])).values()];
    const label=unique.map(u=>u.name).join('、')||(current.devAssignees?'子任务暂无已分配负责人':'未读取子任务负责人，请重新扫描');
    const payload=baseTeamsPayload({...current,assignee:label,assigneeEmail:'',assigneeAccount:''},rulesConfig,automatic,target),card=payload.attachments[0].content;
    const entities=[],names=[];
    for(const user of unique){const mapped=CONFIG.teamsMentionUsers[user.account],mention=CONFIG.mentionAssignee&&(mapped?.id?mapped:user.email?{id:user.email,name:user.name}:null);if(mention){const name=String(mention.name||user.name).replace(/[<>]/g,''),text='<at>'+name+'</at>';if(!entities.some(e=>e.mentioned.id.toLowerCase()===String(mention.id).toLowerCase()))entities.push({type:'mention',text,mentioned:{id:String(mention.id),name}});names.push(text);}else names.push(user.name);}
    card.msteams.entities=entities;card.body[2].text='通知负责人：'+(names.join('、')||label);
    payload.devAssignees=current.devAssignees||[];payload.assignee=label;return payload;
  }

  function safeError(error){
    return String(error?.message||error||'未知错误').replace(/https?:\/\/[^\s<>"']+/g,'[已隐藏地址]').replace(/([?&]sig=)[^&\s]+/gi,'$1[隐藏]').slice(0,1200);
  }
  function showTeamsError(text){
    const box=el('[data-teams-errors]');box.textContent=safeError(text);box.hidden=false;
  }
  function postTeams(payload,webhook){
    return new Promise((resolve,reject)=>{
      if(!webhook){reject(new Error('未配置 Webhook：打开油猴菜单「Jira+：配置中心」'));return;}
      if(!supportedWebhook(webhook)){reject(new Error('Webhook 地址不受支持，请重新配置'));return;}
      if(typeof GM_xmlhttpRequest!=='function'){reject(new Error('GM_xmlhttpRequest 不可用，请确认只启用一份 Jira+ 并重新保存脚本权限'));return;}
      try{GM_xmlhttpRequest({method:'POST',url:webhook,headers:{'Content-Type':'application/json'},data:JSON.stringify(payload),timeout:30000,anonymous:true,
        onload:r=>{
          if(r.status>=200&&r.status<300){resolve();return;}
          let detail='';try{const body=JSON.parse(r.responseText||'{}');detail=body.error?.message||body.message||'';}catch{detail=(r.responseText||'').slice(0,600);}
          reject(new Error('Webhook HTTP '+r.status+(detail?'：'+safeError(detail):'')));
        },
        onerror:r=>{
          const details=[r?.status?'HTTP '+r.status:'未收到 HTTP 响应',r?.statusText,r?.error].filter(Boolean).map(safeError).join('；');
          reject(new Error('Webhook 网络请求失败（'+details+'）；目标域名：'+new URL(webhook).hostname+'。请在油猴脚本设置中检查 XHR/跨域域名授权；若工作流已有本次运行记录，请勿重复发送。'));
        },
        onabort:()=>reject(new Error('Webhook 请求被中止')),
        ontimeout:()=>reject(new Error('Webhook 请求超时，发送结果未知，请先检查工作流运行记录再重试'))});}
      catch(error){reject(new Error('油猴请求未发出：'+safeError(error)));}
    });
  }

  let teamsSending=false;
  function notice(text){el('[data-notice]').textContent=text;}
  async function sendOverviewItem(item,rules,automatic){
    const run=async()=>{
      const detail=get()?.mode==='single';
      if(automatic&&detail)return 'skipped';
      const target=projectTarget(item.key);
      const payload=teamsPayload(item,rules,!detail,target);
      if(!payload.rules.length)return 'skipped';
      if(!target?.webhook){if(automatic)return 'unconfigured';throw Error(projectKeyOf(item.key)+' 未配置通知目标，请打开配置中心');}
      if(automatic&&!target.autoNotify)return 'skipped';
      if(automatic){
        if(typeof GM_getValue!=='function'||typeof GM_setValue!=='function')throw new Error('请保存新版脚本并刷新以启用通知去重权限');
        const key='jira-plus-teams-cooldown-v2:'+target.projectKey+':'+item.key+':'+target.webhook+':'+target.recipients.map(x=>x.toLowerCase()).sort().join(';');
        if(GM_getValue(key,null)?.until>Date.now())return 'suppressed';
        const hours=Number(CONFIG.notificationCooldownHours);
        if(!Number.isFinite(hours)||hours<=0)throw new Error('notificationCooldownHours 必须大于0');
        GM_setValue(key,{until:Date.now()+hours*3600000,state:'submitted'});
      }
      await postTeams(payload,target.webhook);return 'submitted';
    };
    if(typeof navigator!=='undefined'&&navigator.locks?.request)return navigator.locks.request('jira-plus-teams-notify',run);
    return run();
  }
  async function autoNotifyOverview(item,rules){
    try{const state=await sendOverviewItem(item,rules,true);if(state==='submitted')notice(item.key+' 自动通知已提交');else if(state==='unconfigured')notice(item.key+' 未配置通知目标，仅统计');}
    catch(error){const text=item.key+' 自动通知失败：'+safeError(error);notice(text);showTeamsError(text+'；自动冷却记录保留，请核对工作流。');}
  }
  function alertSummaryPayload(items,rules,target){
    const reports=items.map(item=>({item,report:teamsPayload(item,rules,true,target)})).filter(x=>x.report.rules.length);
    const keys=reports.map(x=>x.item.key),jiraUrl=location.origin+'/issues/?'+new URLSearchParams({jql:'key in ('+keys.join(',')+')'});
    const warning=reports.filter(x=>x.report.rules.some(r=>r.level==='warning')).length,overdue=reports.filter(x=>x.report.rules.some(r=>r.level==='overdue')).length;
    const title=target.projectKey+' · 超时预警列表',subtitle=reports.length+' 条工单 · 即将超期 '+warning+' 条 · 已超期 '+overdue+' 条（同一工单可命中不同规则）';
    const rows=reports.map(({item,report})=>[item.key,item.summary,report.assignee||'未分配',report.rules.map(r=>r.name+' '+r.sla+' · '+r.days.toFixed(2)+'天').join(' / ')]);
    const text=title+'\n'+subtitle+'\n'+rows.map(row=>row.join(' | ')).join('\n');
    const body=[{type:'TextBlock',text:title,weight:'Bolder',size:'Medium',wrap:true},{type:'TextBlock',text:subtitle,wrap:true}];
    const card={type:'AdaptiveCard',version:'1.2',msteams:{width:'Full',entities:[]},body,actions:[{type:'Action.OpenUrl',title:'在 Jira 查看全部 '+reports.length+' 条',url:jiraUrl}]};
    const attachment={contentType:'application/vnd.microsoft.card.adaptive',contentUrl:null,content:card};
    let displayed=0;
    for(const {item,report} of reports){
      const mentions=report.attachments[0].content.msteams.entities||[],owner=report.attachments[0].content.body[2].text.replace(/^(负责人|通知负责人)：/,'');
      const block={type:'Container',separator:true,items:[{type:'TextBlock',text:'['+item.key+']('+location.origin+'/browse/'+encodeURIComponent(item.key)+') · '+(owner||'未分配'),weight:'Bolder',wrap:true},{type:'TextBlock',text:String(item.summary||'').slice(0,180),wrap:true,spacing:'Small'},...report.rules.map(r=>({type:'TextBlock',text:r.name+' · '+r.sla+' · '+r.days.toFixed(2)+'天',color:r.level==='overdue'?'Attention':'Warning',wrap:true,spacing:'Small'}))]};
      const previousEntities=[...card.msteams.entities];for(const mention of mentions)if(!card.msteams.entities.some(x=>x.mentioned.id.toLowerCase()===mention.mentioned.id.toLowerCase()))card.msteams.entities.push(mention);
      body.push(block);
      if(new TextEncoder().encode(JSON.stringify(attachment)).length>23*1024){body.pop();card.msteams.entities=previousEntities;break;}displayed++;
    }
    if(displayed<reports.length)body.push({type:'TextBlock',text:'卡片显示前 '+displayed+' 条，共 '+reports.length+' 条；完整列表见邮件或下方 Jira 按钮。',wrap:true,isSubtle:true});
    const meta='扫描时间：'+beijingTime(Math.max(...reports.map(x=>x.item.checkedAt||0)));
    const email=target.recipients?.length?{enabled:true,recipients:[...target.recipients],to:target.recipients.join(';'),subject:'[Jira+] '+target.projectKey+' · 超时预警列表（'+reports.length+'条）',bodyText:text,bodyHtml:hub.emailCard({title,subtitle,sections:[{title:'即将超期 / 已超期',headers:['Jira','摘要','负责人','规则与时长'],rows}],meta,url:jiraUrl})}:{enabled:false};
    hub.attachEmailReport(email,hub.coeReportFile(reports,target.projectKey));
    return {type:'message',reportType:'timeout-summary',projectKey:target.projectKey,jiraUrl,summary:subtitle,text,email,scanTime:meta,items:reports.map(({item,report})=>({jiraKey:item.key,summary:item.summary,assignee:report.assignee,devAssignees:item.devAssignees||[],jiraUrl:report.jiraUrl,rules:report.rules})),attachments:[attachment]};
  }
  const EMPTY_COE='jira-plus-coe-empty-summary-v1';
  function scanSummaryPayload(state,target){
    const count=state.projectCounts?.[target.projectKey]??(state.queue||[]).filter(x=>projectKeyOf(x.key)===target.projectKey).length;
    const checked=(state.results||[]).filter(x=>projectKeyOf(x.key)===target.projectKey).length;
    const time=beijingTime(state.finishedAt||Date.now()),status='扫描完成 · 无即将超期或已超期工单';
    const rows=[['扫描时间',time],['扫描条目数',String(count)],['扫描状态',status]];
    const title=target.projectKey+' · COE 扫描摘要',text=title+'\n'+rows.map(x=>x.join('：')).join('\n');
    const url=new URL(state.listUrl||location.href);url.hash='';
    const email=target.recipients?.length?{enabled:true,recipients:[...target.recipients],to:target.recipients.join(';'),subject:'[Jira+] '+title,bodyText:text,bodyHtml:hub.emailCard({title,subtitle:status,sections:[{title:'扫描结果',headers:['项目','结果'],rows}],meta:'今日已完成扫描，没有符合预警条件的工单。',url:url.href})}:{enabled:false};
    return {type:'message',reportType:'coe-scan-summary',projectKey:target.projectKey,jiraUrl:url.href,text,summary:status,scanTime:time,scanCount:count,analyzedCount:checked,scanStatus:'completed',items:[],email:{...email,attachments:[]},attachments:[{contentType:'application/vnd.microsoft.card.adaptive',content:{type:'AdaptiveCard',version:'1.2',body:[{type:'TextBlock',text:title,weight:'Bolder',wrap:true},{type:'FactSet',facts:rows.map(([title,value])=>({title,value}))}]}}]};
  }
  function alertCooldownKey(item,target){return 'jira-plus-teams-cooldown-v2:'+target.projectKey+':'+item.key+':'+target.webhook+':'+(target.recipients||[]).map(x=>x.toLowerCase()).sort().join(';');}
  async function sendBatchAlerts(source,automatic=false){
    if(teamsSending)return;
    teamsSending=true;render();
    const state=JSON.parse(JSON.stringify(source)),rules=state.rules||CONFIG.rules,groups=new Map(),outcomes=[];
    for(const item of state.results||[]){if(!hasTeamsAlert(item,rules)||!hub.jobProjectAllowed(projectKeyOf(item.key)))continue;const key=projectKeyOf(item.key);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(item);}
    if(state.phase==='done'&&(GM_getValue(EMPTY_COE,false)===true||hub.jobDelivery?.combine)){
      for(const key of Object.keys(state.projectCounts||{}))if(hub.jobProjectAllowed(key)&&!groups.has(key))groups.set(key,[]);
    }
    try{
      if(!groups.size){notice('没有即将超期或已超期的工单，无需发送。');return;}
      for(const [key,items] of groups){
        const send=async()=>{
          const configured=projectTarget(key+'-1');if(!configured?.webhook)return key+'：未配置通知目标，跳过';
          const target={...configured,recipients:[...(configured.recipients||[])]};
          if(automatic&&!target.autoNotify)return key+'：批量自动通知未开启，跳过';
          const eligible=automatic?items.filter(item=>!(GM_getValue(alertCooldownKey(item,target),null)?.until>Date.now())):items;
          if(items.length&&!eligible.length)return key+'：全部工单仍在通知冷却期，跳过';
          if(hub.jobDelivery?.email&&!target.recipients.length)throw Error('未配置邮件收件人');
          const payload=hub.deliveryPayload(items.length?alertSummaryPayload(eligible,rules,target):scanSummaryPayload(state,target));
          if(hub.jobDelivery&&!hub.jobDelivery.attach&&payload.email){delete payload.email.attachments;payload.email.bodyHtml=payload.email.bodyHtml?.replace(/<p data-jira-plus-report[\s\S]*?<\/p>/g,'');}
          if(automatic){const hours=Number(CONFIG.notificationCooldownHours);if(!Number.isFinite(hours)||hours<=0)throw Error('通知冷却时间无效');for(const item of eligible)GM_setValue(alertCooldownKey(item,target),{until:Date.now()+hours*3600000,state:'submitted'});}
          await postTeams(payload,target.webhook);return key+(items.length?'：已提交 1 份预警列表（'+eligible.length+' 条工单）':'：已提交扫描摘要（无预警工单）');
        };
        try{notice('正在提交 '+key+' 预警列表…');outcomes.push(typeof navigator!=='undefined'&&navigator.locks?.request?await navigator.locks.request('jira-plus-teams-notify',send):await send());}
        catch(error){outcomes.push(key+'：提交失败或结果未知；'+safeError(error)+'。未自动重试。');showTeamsError(outcomes.join('\n'));}
      }
      notice(outcomes.join('\n')+'\n每个项目分别提交；Webhook 接收不代表 Teams / 邮件已投递。');
      return outcomes;
    }finally{teamsSending=false;render();}
  }

  if(!detailOnly){
  el('[data-report-export]').onclick=()=>{
    const state=get();if(!state?.results?.length||state.active)return;
    const rules=state.rules||CONFIG.rules,reports=state.results.map(item=>({item,report:teamsPayload(item,rules,false,projectTarget(item.key))}));
    hub.downloadFile(hub.coeReportFile(reports,'all'));
  };
  el('[data-mail-preview]').onclick=()=>{
    const state=get();if(!state?.results?.length||state.active)return;
    const rules=state.rules||CONFIG.rules,groups=new Map();
    for(const item of state.results){if(state.mode==='batch'&&!hasTeamsAlert(item,rules))continue;const key=projectKeyOf(item.key);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(item);}
    const entries=[...groups].map(([key,items])=>{const target=projectTarget(items[0].key)||{projectKey:key,recipients:[]},reports=items.map(item=>({item,report:teamsPayload(item,rules,state.mode==='batch',target)})),file=hub.coeReportFile(reports,key);const email=state.mode==='batch'?alertSummaryPayload(items,rules,target).email:reports[0].report.email;hub.attachEmailReport(email,file);return {key,email,file};});
    if(!entries.length){notice('本次没有即将超期或已超期的工单，无需发送预警邮件；仍可导出完整交互报告。');return;}
    hub.previewMailReports(entries);
  };

  }
  el('[data-teams]').onclick=async()=>{
    const s=get();if(teamsSending||s?.active)return;
    if(s?.mode==='batch'){await sendBatchAlerts(s,false);return;}
    const items=(s?.results||[]).filter(item=>item.rules?.some(r=>Number.isFinite(r.seconds)));
    if(!items.length){notice('没有有效计时结果，无需发送');return;}
    el('[data-teams-errors]').hidden=true;el('[data-teams-errors]').textContent='';
    teamsSending=true;render();let success=0,failed=0,skipped=0;const errors=[];
    for(const item of items){
      notice('正在发送 '+item.key+'…');
      try{const state=await sendOverviewItem(item,s.rules||CONFIG.rules,false);if(state==='submitted')success++;else skipped++;}catch(error){failed++;errors.push(item.key+'：'+safeError(error));notice(errors[errors.length-1]);showTeamsError(errors.join('\n'));}
    }
    teamsSending=false;notice('Teams 已提交 '+success+' 条，失败 '+failed+' 条，跳过 '+skipped+' 条（工作流接收不代表投递完成）'+(errors.length?'\n'+errors.join('\n'):''));render();
  };
  function update(message) {const s=get();if(s?.active){s.message=message;save(s);render();}}
  function valid(id, token) { const s=get();if(!s?.active || s.id!==id || token!==epoch)throw new Error('CANCELLED');return s; }
  function tabLink(){return [...document.querySelectorAll('a,button,[role="tab"]')].find(x=>/^history$/i.test(x.textContent.trim()));}
  async function api(path,options={}){
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),25000);
    try{const res=await fetch(path,{...options,credentials:'same-origin',headers:{Accept:'application/json',...(options.headers||{})},signal:controller.signal});if(!res.ok)throw new Error('Jira HTTP '+res.status);return await res.json();}finally{clearTimeout(timer);}
  }
  async function issueHistory(key,checkpoint=()=>{}){
    checkpoint();
    const data=await api('/rest/api/2/issue/'+encodeURIComponent(key)+'?fields=assignee,status,summary,issuetype,subtasks&expand=changelog');
    checkpoint();if(bugIssueType(data.fields?.issuetype))return {excluded:true,issueType:data.fields.issuetype.name};
    let histories=data.changelog?.histories;
    if(!Array.isArray(histories))throw new Error('接口未返回 changelog');
    const total=data.changelog.total;
    if(!Number.isInteger(total)||data.changelog.startAt>0||histories.length<total){
      histories=[];let startAt=0;
      do{
        checkpoint();const page=await api('/rest/api/2/issue/'+encodeURIComponent(key)+'/changelog?startAt='+startAt+'&maxResults=100');
        checkpoint();const batch=page.values||page.histories;
        if(!Array.isArray(batch)||!Number.isInteger(page.total)||!batch.length&&startAt<page.total)throw new Error('历史分页不完整');
        histories.push(...batch);startAt+=batch.length;
        if(startAt>=page.total)break;
      }while(startAt<100000);
    }
    const seen=new Set(),events=[];
    for(const h of histories){
      if(h.id&&seen.has(h.id))continue;if(h.id)seen.add(h.id);
      for(const item of h.items||[]){
        if(norm(item.field)!=='STATUS')continue;
        const at=Date.parse(h.created);
        if(!Number.isFinite(at))throw new Error('History 精确时间解析失败：'+h.created);
        events.push({to:item.toString,from:item.fromString,at,historyId:h.id,source:'History REST fetch 精确时间',order:events.length});
      }
    }
    const fields=data.fields||{};
    if(!fields.status?.name)throw new Error('无法读取当前状态');
    const devRule=CONFIG.rules.find(r=>norm(r.name)==='DEV');const devAssignees=devRule?.currentStatuses.map(norm).includes(norm(fields.status.name))?await subtaskAssignees(fields,checkpoint):[];checkpoint();
    return {devAssignees,events,issueType:fields.issuetype?.name||'',assigneeEmail:fields.assignee?.emailAddress||'',assigneeAccount:fields.assignee?.name||fields.assignee?.key||fields.assignee?.accountId||'',status:fields.status.name,assignee:fields.assignee===null?'未分配':fields.assignee?.displayName||'',summary:fields.summary||'',source:'Jira History REST fetch 精确时间'};
  }
  async function allIssues(id,token){
    const checkpoint=valid(id,token).collection;
    let jql=checkpoint?.jql||jqlBox.value.trim()||new URL(location.href).searchParams.get('jql')||document.querySelector('#jql, textarea[name="jql"]')?.value||'';
    if(!jql){const filter=new URL(location.href).searchParams.get('filter');if(/^\d+$/.test(filter||'')){jql=(await api('/rest/api/2/filter/'+filter)).jql||'';}}
    if(!jql)throw new Error('无法确定完整筛选条件，请在面板粘贴 Advanced 的完整 JQL，再重新开始；没有退回到只扫描当前页');
    let startAt=checkpoint?.startAt||0,total=checkpoint?.total??null;
    const found=new Map((checkpoint?.issues||[]).map(x=>[x.key,x]));
    const initial=valid(id,token);initial.collection={jql,startAt,total,issues:[...found.values()]};save(initial);
    while(total===null||startAt<total){
      valid(id,token);
      const page=await api('/rest/api/2/search',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({jql,startAt,maxResults:100,fields:['summary','status','assignee','issuetype']})});
      valid(id,token);
      if(!Array.isArray(page.issues)||!Number.isInteger(page.total))throw new Error('搜索分页返回格式异常');
      if(total!==null&&total!==page.total)throw new Error('收集时筛选数量变化，请重新扫描');total=page.total;
      if(!page.issues.length&&startAt<total)throw new Error('搜索分页提前结束，未取得全部工单');
      for(const issue of page.issues)found.set(issue.key,issue);
      startAt+=page.issues.length;
      const state=valid(id,token);state.collection={jql,startAt,total,issues:[...found.values()]};save(state);
      update(`收集全部筛选结果：${startAt}/${total}`);
    }
    if(found.size!==total)throw new Error('搜索分页存在重复或遗漏，请重试');
    const rules=valid(id,token).rules;
    const queue=[...found.values()].filter(x=>!bugIssueType(x.fields?.issuetype)).filter(x=>rules.some(r=>r.currentStatuses.map(norm).includes(norm(x.fields?.status?.name)))).map(x=>({key:x.key,summary:x.fields?.summary||'',currentStatus:x.fields?.status?.name||'',assignee:x.fields?.assignee===null?'未分配':x.fields?.assignee?.displayName||'',href:location.origin+'/browse/'+x.key}));
    const projectCounts={};for(const issue of found.values()){const key=projectKeyOf(issue.key);projectCounts[key]=(projectCounts[key]||0)+1;}
    for(const match of jql.matchAll(/\bproject\s*(?:=\s*["']?([A-Z][A-Z0-9_]*)["']?|in\s*\(([^)]+)\))/gi)){for(const raw of (match[1]||match[2]).split(',')){const key=raw.trim().replace(/["']/g,'').toUpperCase();if(/^[A-Z][A-Z0-9_]*$/.test(key)&&!(key in projectCounts))projectCounts[key]=0;}}
    return {queue,total,jql,projectCounts};
  }
  async function continueCollection(){
    const before=get();if(!before?.active||before.phase!=='collecting'||busy)return;
    const id=before.id,token=epoch;busy=true;
    try{
      const {queue,total,jql,projectCounts}=await allIssues(id,token);const state=valid(id,token);
      Object.assign(state,{queue,total,jql,projectCounts,phase:'list',message:`全部${total}条，符合状态范围${queue.length}条`});delete state.collection;save(state);
    }catch(e){if(e.message!=='CANCELLED'){const state=get();if(state?.id===id&&state.active&&token===epoch){state.active=false;state.paused=true;state.message=e.message;save(state);}}}
    finally{if(token===epoch)busy=false;render();}
    if(token===epoch)await pump();
  }
  async function inspect(id,token){
    const state=valid(id,token);
    // 批量扫描保持可见的History定位；独立详情直接使用同一REST读取和计算逻辑。
    if(state.mode!=='single'){
      const end=Date.now()+CONFIG.detailTimeoutSeconds*1000;let tab;
      while(Date.now()<end){valid(id,token);tab=tabLink();if(tab)break;document.querySelector('#activitymodule')?.scrollIntoView({block:'center'});await sleep(500);}
      if(!tab)throw new Error('未找到 History 标签');
      tab.scrollIntoView({block:'center'});tab.click();update('已点击 History，读取状态变化的精确时间…');await sleep(1000);valid(id,token);
    }
    // made changes 的相对时间会舍入；读取同一 History 的 REST created 时间，避免把 Yesterday/17 minutes ago 当成精确日期。
    const data=await issueHistory(keyOf(location.href),()=>valid(id,token));
    const s=valid(id,token),now=Date.now();
    if(data.excluded)return {excluded:true};
    return {checkedAt:now,devAssignees:data.devAssignees,assigneeEmail:data.assigneeEmail,assigneeAccount:data.assigneeAccount,rules:evaluateHistory(data.events,data.status,s.rules,now),assignee:data.assignee||readAssignee()||s.queue[s.index]?.assignee||'',summary:data.summary,currentStatus:data.status,source:data.source};
  }
  let dashboardDiagnostics='';
  function dashboardIssues(){
    const found=new Map(),visited=new Set();let anchors=0,frames=0,blocked=0,roots=0;
    const issueKey=value=>String(value||'').trim().match(/^[A-Z][A-Z0-9_]*-\d+$/i)?.[0]?.toUpperCase();
    const walk=root=>{
      if(!root||visited.has(root))return;visited.add(root);roots++;
      for(const node of root.querySelectorAll('a, [data-issue-key], [data-issuekey]')){
        if(node.closest?.('#jira-duration-panel-host, #jira-plus-hub, #jira-detail-panel-host, #jira-plus-issue-details'))continue;
        const raw=node.getAttribute?.('href')||node.href||'';let key='';
        if(raw&&!/^javascript:/i.test(raw)){try{
          const url=new URL(raw,location.href);if(url.origin!==location.origin)continue;
          key=keyOf(url.href)||issueKey(url.searchParams.get('issueKey'))||issueKey(url.searchParams.get('key'));
        }catch{continue;}}
        anchors++;
        key=issueKey(key)||issueKey(node.getAttribute?.('data-issue-key'))||issueKey(node.getAttribute?.('data-issuekey'))||issueKey(node.textContent);
        if(key&&!found.has(key))found.set(key,{key,href:location.origin+'/browse/'+encodeURIComponent(key),summary:node.textContent?.trim()||key});
      }
      for(const node of root.querySelectorAll('*')){if(node.shadowRoot&&!['jira-duration-panel-host','jira-plus-hub','jira-detail-panel-host','jira-plus-issue-details'].includes(node.id))walk(node.shadowRoot);}
      for(const frame of root.querySelectorAll('iframe, frame')){
        frames++;try{const doc=frame.contentDocument;if(doc)walk(doc);else blocked++;}catch{blocked++;}
      }
    };walk(document);
    dashboardDiagnostics='读取文档/Shadow Root '+roots+' 个，候选链接/字段 '+anchors+' 个，iframe '+frames+' 个，其中不可读取 '+blocked+' 个';
    return [...found.values()];
  }
  async function scanDashboard(previous){
    const queue=previous?.paused?previous.queue:dashboardIssues();
    if(!queue.length){notice('Dashboard 未识别到工单编号。'+dashboardDiagnostics+'。若 iframe 不可读取，请打开小组件对应的筛选列表进行扫描。');return;}
    epoch++;const token=epoch;
    const state=previous?.paused?{...previous,active:true,paused:false,jobDirect:true}:{id:'dashboard-'+Date.now(),mode:'batch',dashboardScan:true,jobDirect:true,active:true,rules:JSON.parse(JSON.stringify(CONFIG.rules)),queue,index:0,results:[],skipped:0,listUrl:location.href};
    state.phase='reading';save(state);render();
    try{
      while(state.index<state.queue.length){
        valid(state.id,token);const item=state.queue[state.index];let data;
        try{data=await issueHistory(item.key);}catch(error){valid(state.id,token);throw Error(item.key+'：'+safeError(error));}
        valid(state.id,token);
        {
          const now=Date.now();state.results.push({...item,summary:data.summary,assignee:data.assignee,devAssignees:data.devAssignees,assigneeEmail:data.assigneeEmail,assigneeAccount:data.assigneeAccount,currentStatus:data.status,checkedAt:now,rules:evaluateHistory(data.events,data.status,state.rules,now)});
          await autoNotifyOverview(state.results.at(-1),state.rules);valid(state.id,token);
        }
        state.index++;state.message='Dashboard：不限 Issue Type，已扫描 '+state.index+'/'+state.queue.length;save(state);render();
      }
      state.active=false;state.jobDirect=false;state.phase='done';state.message='Dashboard 已加载工单扫描完成；不限 Issue Type（不含未加载的小组件分页）';save(state);render();
    }catch(error){if(error.message!=='CANCELLED'){const s=get();if(s?.id===state.id){s.active=false;s.paused=true;s.message='Dashboard 扫描失败：'+safeError(error);save(s);render();}}}
  }
  function onOverview(){
    return /^\/issues(?:\/|$)/.test(location.pathname)&&!!document.querySelector('#issuetable, .issue-table, [data-testid="issue-table"]');
  }
  function pageStamp(){return summaryLinks().map(x=>x.key).join('|');}
  function pageBounds(){
    const match=(document.body.innerText||'').match(/Showing results\s+([\d,]+)\s*[-–]\s*([\d,]+)\s+of\s+([\d,]+)/i);
    return match?{start:Number(match[1].replace(/,/g,'')),end:Number(match[2].replace(/,/g,'')),total:Number(match[3].replace(/,/g,''))}:null;
  }
  function nextPageControl(){
    const links=[...document.querySelectorAll('.pagination a, .pagination button, .aui-nav-pagination a, .aui-nav-pagination button, a[rel="next"], a[aria-label], a[title], a[href*="startIndex="], a[href*="startAt="], a[href*="pager/start="]')];
    const enabled=x=>!x.disabled&&x.getAttribute('aria-disabled')!=='true'&&!x.closest('.disabled, .aui-nav-disabled, [aria-disabled="true"]')&&x.getClientRects().length;
    const explicit=links.find(x=>enabled(x)&&(/^(next|next page|下一页|下页|›|»|>)$/i.test(x.textContent.trim())||/next|下一页/i.test((x.getAttribute('aria-label')||'')+' '+(x.getAttribute('title')||''))||x.getAttribute('rel')==='next'));
    if(explicit)return explicit;
    const bounds=pageBounds();
    if(bounds&&bounds.end<bounds.total){
      const target=Math.floor((bounds.start-1)/(bounds.end-bounds.start+1))+2;
      const numeric=[...document.querySelectorAll('.pagination a, .aui-nav-pagination a, a[href]')].find(x=>enabled(x)&&x.textContent.trim()===String(target)&&new URL(x.href,location.href).pathname.startsWith('/issues'));
      if(numeric)return numeric;
    }
    return null;
  }
  function appendPage(state){
    const stamp=pageStamp();if(!stamp)throw new Error('当前分页列表尚未加载');
    if((state.visitedPages||[]).includes(stamp))throw new Error('翻页后出现已扫描的相同列表，暂停以防重复扫描');
    const rows=summaryLinks(),seen=new Set(state.queue.map(x=>x.key));
    const eligible=rows.filter(x=>!seen.has(x.key)&&(!x.currentStatus||state.rules.some(r=>r.currentStatuses.map(norm).includes(norm(x.currentStatus)))));
    state.queue.push(...eligible.map(({anchor,...x})=>x));
    state.visitedPages=[...(state.visitedPages||[]),stamp];state.listUrl=location.href;state.phase='list';state.pageNumber=(state.pageNumber||0)+1;
    state.total=pageBounds()?.total??state.total;state.message=`第${state.pageNumber}页，新增${eligible.length}条符合范围的工单`;save(state);
  }
  function advancePage(state){
    const next=nextPageControl(),bounds=pageBounds();
    if(!next){
      if(bounds&&bounds.end<bounds.total)throw new Error('列表还有下一页但未识别到翻页按钮，请暂停后检查右下角页码');
      state.active=false;state.phase='done';state.message=`已完成${state.pageNumber}页，已统计${state.index}条符合范围的工单`;save(state);return;
    }
    state.phase='paging';state.pagingFrom=pageStamp();state.pagingSince=Date.now();state.nextPageUrl=next.href||null;state.message='当前页完成，点击右下角下一页…';save(state);render();
    next.scrollIntoView({block:'center'});next.click();
    const id=state.id,from=state.pagingFrom;
    setTimeout(()=>{const x=get();if(x?.active&&x.id===id&&x.phase==='paging'&&x.pagingFrom===from&&pageStamp()===from&&x.nextPageUrl)location.assign(x.nextPageUrl);},2000);
  }
  function listIdentity(href){
    const u=new URL(href);for(const key of ['selectedIssue','focusedCommentId','focusedId'])u.searchParams.delete(key);u.hash='';u.searchParams.sort();return u.origin+u.pathname.replace(/\/$/,'')+'?'+u.searchParams;
  }
  function back(s) {
    // History 标签自身可能增加历史项。先浏览器返回，再确保恢复保存的总览。
    if(s.backAt&&Date.now()-s.backAt<2500)return;
    s.backAt=Date.now();save(s);update('本条已保存，返回总览后自动继续…');
    const id=s.id;history.back();
    setTimeout(()=>{
      const x=get();if(!x?.active||x.id!==id||x.phase!=='returning')return;
      if(!onOverview())location.replace(x.listUrl);else pump();
    },1800);
  }
  // Read Jira REST data in the current tab; never click issue links or navigate.
  async function scanDirect(){
    if(busy)return;
    const initial=get();if(!initial?.active||initial.mode!=='batch')return;
    const id=initial.id,token=epoch;busy=true;
    try{
      while(true){
        const state=valid(id,token);
        if(state.index>=state.queue.length){state.active=false;state.paused=false;state.phase='done';state.finishedAt=Date.now();state.message=state.dashboardScan?'Dashboard 已加载工单接口扫描完成（不含未加载的小组件分页）':`接口扫描完成：${state.index}/${state.queue.length} 条（查询共 ${state.total??state.queue.length} 条）`;save(state);if(!state.autoSummaryAttempted){state.autoSummaryAttempted=true;save(state);if(!hub.jobDelivery)await sendBatchAlerts(state,true);}break;}
        const item=state.queue[state.index];update(`接口读取 ${item.key}（${state.index+1}/${state.queue.length}）…`);
        const data=await issueHistory(item.key,()=>valid(id,token));
        const current=valid(id,token),now=Date.now();
        if(data.excluded){current.index++;current.skippedBugs=(current.skippedBugs||0)+1;current.message=item.key+' 为 Bug，已跳过';save(current);render();continue;}
        const result={...item,issueType:data.issueType,summary:data.summary,assignee:data.assignee,devAssignees:data.devAssignees,assigneeEmail:data.assigneeEmail,assigneeAccount:data.assigneeAccount,currentStatus:data.status,checkedAt:now,source:data.source,rules:evaluateHistory(data.events,data.status,current.rules,now)};
        current.results.push(result);current.index++;current.phase='reading';current.message=`接口扫描 ${current.index}/${current.queue.length} · ${item.key}`;
        // Persist the completed item before notification, so pause/reload cannot count it twice.
        save(current);render();
        valid(id,token);
      }
    }catch(error){
      if(error.message!=='CANCELLED'){
        const state=get();if(state?.id===id&&token===epoch){state.active=false;state.paused=true;state.message='接口扫描暂停：'+safeError(error)+'；已保留进度，点击开始统计重试当前工单。';save(state);}
      }
    }finally{if(token===epoch)busy=false;render();}
  }
  async function startApiBatch(){
    const previous=get();if(previous?.active||teamsSending)return;
    if(previous?.paused&&previous.mode==='batch'){
      if(!previous.apiScan){notice('这是旧版逐页扫描任务。请先停止，再重新开始接口扫描；旧结果仍可导出。');return;}
      epoch++;busy=false;previous.active=true;previous.paused=false;previous.jobDirect=false;previous.message='继续接口扫描，保留已完成结果';save(previous);render();
      if(previous.phase==='collecting')await continueCollection();else await scanDirect();return;
    }
    epoch++;busy=false;
    const state={id:'api-'+Date.now()+'-'+epoch,mode:'batch',apiScan:true,active:true,paused:false,rules:JSON.parse(JSON.stringify(CONFIG.rules)),scope:scope.value,listUrl:location.href,queue:[],index:0,results:[],phase:'reading'};
    if(isDashboard()){
      state.dashboardScan=true;state.queue=dashboardIssues();state.total=state.queue.length;
      if(!state.queue.length){notice('Dashboard 未识别到工单编号。'+dashboardDiagnostics);return;}
    }else if(scope.value==='all'){
      state.phase='collecting';state.message='通过接口收集当前查询的全部分页…';save(state);render();await continueCollection();return;
    }else{
      state.queue=summaryLinks().filter(item=>!item.currentStatus||state.rules.some(rule=>rule.currentStatuses.map(norm).includes(norm(item.currentStatus)))).map(({anchor,...item})=>item);state.total=state.queue.length;
      if(!state.queue.length){notice('当前页未找到符合状态范围的工单，请等待 Jira 列表加载后重试。');return;}
    }
    save(state);render();await scanDirect();
  }

  async function pump() {
    if(busy)return;
    let s=get();if(!s?.active){render();return;}
    if(s.mode==='batch'){
      if(!s.apiScan){s.active=false;s.paused=true;s.message='旧版逐页任务已暂停，请停止后重新开始接口扫描；原结果可导出。';save(s);render();return;}
      if(s.phase==='collecting')await continueCollection();else await scanDirect();return;
    }
    if(s.jobDirect)return;
    if(s.phase==='collecting'){continueCollection();return;}
    busy=true;const token=epoch;
    try {
      if(s.domPaging&&s.phase==='paging'){
        const stamp=pageStamp();
        if(onOverview()&&stamp&&stamp!==s.pagingFrom){appendPage(s);return;}
        if(Date.now()-s.pagingSince>30000){s.active=false;s.paused=true;s.message='翻页30秒未完成；请手动翻到下一页后点击开始统计继续';save(s);}
        return;
      }
      const current=s.phase==='returning'&&onOverview()?null:keyOf(location.href);
      if(current){
        if(s.phase==='returning'){back(s);return;}
        const item=s.queue[s.index];
        if(!item || current!==item.key){s.active=false;s.message='当前打开的 Jira 与待扫描条目不符，已停止';save(s);return;}
        s.phase='reading';save(s);update(`正在读取 ${item.key} 的 History…`);
        let result;
        try{result=await inspect(s.id,token);}catch(e){if(e.message==='CANCELLED')return;result={status:'读取失败',max:null,details:e.message};}
        s=valid(s.id,token);
        if(result.excluded){s.index++;s.active=false;s.phase='done';s.message=item.key+' 为 Bug，已跳过，不参与 COE 统计和通知';save(s);render();return;}
        s.results.push({...item,summary:readSummary()||item.summary,assignee:readAssignee()||item.assignee||'',...result});s.index++;
        save(s);await autoNotifyOverview(s.results[s.results.length-1],s.rules);s=valid(s.id,token);
        if(s.mode==='single'){
          s.active=false;s.phase='done';s.message=`${item.key} 本条统计完成`;save(s);render();return;
        }
        s.phase='returning';save(s);render();await sleep(800);valid(s.id,token);back(s);return;
      }
      if(!/^\/issues(?:\/|$)/.test(location.pathname))return;
      if(listIdentity(location.href)!==listIdentity(s.listUrl)){
        if(s.phase==='returning'){location.replace(s.listUrl);return;}
        s.active=false;s.message='总览筛选改变，已停止以防扫描错误列表';save(s);return;
      }
      if(s.phase==='reading'){s.active=false;s.message='读取中离开了详情页，已停止；可重新开始';save(s);return;}
      if(s.domPaging&&s.index>=s.queue.length){advancePage(s);return;}
      if(s.index>=s.queue.length){s.active=false;s.phase='done';s.message=s.scope==='all'?`全部筛选${s.total}条，符合范围${s.queue.length}条，已全部完成`:'当前分页范围内统计完成（未扫描其它分页）';save(s);return;}
      const item=s.queue[s.index];
      // 返回后等待 Jira 恢复表格，再重新定位 Summary，避免使用旧 DOM。
      let link;
      for(let n=0;n<(s.scope==='all'?1:40);n++){valid(s.id,token);link=summaryLinks().find(x=>x.key===item.key);if(link)break;await sleep(500);}
      if(!link&&s.scope==='all'){
        const anchor=document.createElement('a');anchor.href=item.href;anchor.textContent=item.summary||item.key;
        anchor.style.cssText='display:block;padding:4px';el('[data-progress]').append(anchor);
        link={...item,anchor};
      }
      if(!link){s=valid(s.id,token);s.active=false;s.message=`未找到 ${item.key} 的 Summary，已停止；请确认总览列表未改变`;save(s);return;}
      s=valid(s.id,token);s.phase='opening';s.backAt=0;s.message=`点击 ${item.key} 的 Summary（${s.index+1}/${s.queue.length}）`;save(s);render();
      link.anchor.scrollIntoView({block:'center'});await sleep(500);valid(s.id,token);
      // 强制同一标签打开，让 history.back() 能返回原总览。
      link.anchor.removeAttribute('target');
      // 保留真正的 Summary 点击，但阻止 Jira 的 SPA 点击拦截，使用同标签原生链接跳转。
      const nativeClick=event=>event.stopImmediatePropagation();
      link.anchor.addEventListener('click',nativeClick,{capture:true,once:true});
      link.anchor.click();
      await sleep(2000);valid(s.id,token);
      if(!keyOf(location.href))location.assign(link.href);
    }catch(e){if(e.message!=='CANCELLED'){const x=get();if(x){x.active=false;if(x.domPaging)x.paused=true;x.message=e.message;save(x);}}}
    finally{if(token===epoch)busy=false;render();}
  }
  scope.onchange=render;
  el('[data-start]').onclick=async()=>{
    const previous=get();if(previous?.active||teamsSending)return;
    if(isDashboard()){await scanDashboard(previous?.dashboardScan?previous:null);return;}
    if(previous?.paused){
      epoch++;busy=false;
      previous.active=true;previous.paused=false;previous.jobDirect=false;previous.backAt=0;previous.pagingSince=Date.now();previous.message='继续扫描，保留已完成进度';
      scope.value=previous.scope||scope.value;jqlBox.value=previous.jql||previous.collection?.jql||jqlBox.value;
      if(onOverview()&&previous.phase==='reading')previous.phase='list';
      if(previous.domPaging&&previous.phase==='paging'&&onOverview()&&pageStamp()===previous.pagingFrom)previous.phase='list';
      save(previous);render();
      if(previous.phase==='collecting'){continueCollection();return;}
      const pending=previous.queue[previous.index],current=onOverview()?null:keyOf(location.href);
      if(previous.mode==='single'&&pending&&current!==pending.key){location.assign(pending.href);return;}
      if(previous.mode==='batch'&&previous.phase!=='returning'&&current&&current!==pending?.key){previous.phase='list';save(previous);location.replace(previous.listUrl);return;}
      pump();return;
    }
    const current=onOverview()?null:keyOf(location.href);
    if(current){
      save({id:String(Date.now()),mode:'single',active:true,rules:JSON.parse(JSON.stringify(CONFIG.rules)),queue:[{key:current,summary:readSummary(),href:location.href}],index:0,results:[],phase:'reading',message:`开始统计 ${current}`});
      render();pump();return;
    }
    if(scope.value==='all'){
      const state={id:String(Date.now()),active:true,mode:'batch',scope:'all',domPaging:true,rules:JSON.parse(JSON.stringify(CONFIG.rules)),listUrl:location.href,queue:[],index:0,results:[],phase:'list',visitedPages:[],pageNumber:0};
      try{appendPage(state);}catch(error){alert(error.message);return;}render();pump();return;
    }
    const links=summaryLinks().filter(item=>!item.currentStatus||CONFIG.rules.some(r=>r.currentStatuses.map(norm).includes(norm(item.currentStatus))));
    if(!links.length){alert('未找到 Summary 链接，请切换到截图中的列表视图并等待加载完成。');return;}
    save({id:String(Date.now()),active:true,mode:'batch',scope:'page',rules:JSON.parse(JSON.stringify(CONFIG.rules)),listUrl:location.href,queue:links.map(({anchor,...item})=>item),index:0,results:[],phase:'list',message:`已记录当前页 ${links.length} 条 Jira`});render();pump();
  };
  const startSingle=el('[data-start]').onclick;
  el('[data-start]').onclick=()=>detailOnly||isDetail()?startSingle():startApiBatch();
  el('[data-pause]').onclick=()=>{
    const s=get();if(!s?.active)return;
    s.active=false;s.paused=true;s.message='已保留进度，点击开始统计继续';save(s);
    epoch++;busy=false;render();
  };
  el('[data-stop]').onclick=()=>{
    const s=get();if(s){s.active=false;s.paused=false;s.phase='stopped';s.message='本轮已结束，结果可导出；再次开始将新建扫描';save(s);}
    epoch++;busy=false;render();
  };
  el('[data-fold]').onclick=()=>{const folded=body.style.display==='none';fold.textContent=folded?'收起':'展开';body.style.display=folded?'flex':'none';panel.style.height=folded?`min(${CONFIG.panelHeightPx}px,75vh)`:'auto';};
  function exportRows(){
    const s=get(),rules=s?.rules||CONFIG.rules;
    const rows=[{values:['Jira','Summary','Assignee','当前状态','规则','KPI下限天','KPI上限天','计时结果','Duration秒','Duration天','开始时间(北京时间 UTC+08:00)','扫描时间(北京时间 UTC+08:00)','时间来源','明细/错误'],level:'header'}];
    for(const item of s?.results||[])for(const rule of rules){
      const r=item.rules?.find(x=>x.name===rule.name),d=panelDuration(r,rule),effective=resultRule(r,rule);
      rows.push({level:d.level,jiraUrl:'https://jira.xpaas.lenovo.com/browse/'+encodeURIComponent(item.key),values:[item.key,item.summary,norm(rule.name)==='DEV'?devOwnerLabel(item):(item.assignee||''),item.currentStatus||r?.currentStatus||'',rule.name,effective.minDays,effective.maxDays,r&&Number.isFinite(r.seconds)?d.text:r?.status||item.status,Number.isFinite(r?.seconds)?Number(r.seconds.toFixed(2)):'',r&&Number.isFinite(r.seconds)?Number(dayText(r.seconds)):'',beijingTime(r?.startAt),beijingTime(r?.checkedAt),r?.startAt?'History REST fetch 精确时间':'',(r?.details||item.details||'')+(r?.fridayShiftDays?'；周五KPI上下限提前'+r.fridayShiftDays+'天':'')]});
    }return rows;
  }
  function download(blob,name){const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),5000);}
  el('[data-excel]').onclick=()=>download(new Blob([makeXlsx(exportRows())],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}),'Jira+.xlsx');
  let detailRoute='';
  function autoDetail(){
    if(!detailOnly)return;
    hub.syncDetail();
    if(!hub.autoDetail)return;
    const batch=readState(STORE);
    if(batch?.active||batch?.paused||teamsSending)return;
    if(!isDetail()){
      if(detailRoute){epoch++;busy=false;detailRoute='';const previous=readState(DETAIL_STORE);if(previous?.active){previous.active=false;previous.phase='stopped';previous.message='离开详情，分析已取消';save(previous);}}
      return;
    }
    const key=keyOf(location.href);if(!key||detailRoute===key)return;
    try{const latest=GM_getValue(RULE_SETTING,CONFIG.rules);validateRules(latest);CONFIG.rules=latest;}catch(error){notice(safeError(error));return;}
    epoch++;busy=false;detailRoute=key;
    save({id:String(Date.now())+'-'+epoch,mode:'single',active:true,rules:JSON.parse(JSON.stringify(CONFIG.rules)),queue:[{key,summary:readSummary(),href:location.href}],index:0,results:[],phase:'reading',message:'正在自动分析 '+key});
    hub.openDetail();render();void pump();
  }
  addEventListener('pagehide',()=>{epoch++;busy=false;});
  addEventListener('pageshow',()=>{autoDetail();render();setTimeout(pump,800);});
  addEventListener('popstate',()=>{autoDetail();render();});
  setInterval(()=>{autoDetail();if(!host.isConnected)mountPanel();if(!badge.isConnected)document.documentElement.append(badge);pump();},1500);
  if(!detailOnly){hub.configure=configureCenter;hub.projects=projectConfigs;hub.target=projectTarget;hub.safeError=safeError;}else{hub.startDetail=autoDetail;hub.stopDetail=()=>{epoch++;busy=false;detailRoute='';const state=get();if(state?.active){state.active=false;state.phase='stopped';save(state);}};}
  badge.remove();badge.style.display='none';
  if(!detailOnly)hub.jobRunners.coe=async job=>{
    const before=get();if(busy||teamsSending||before?.active||before?.paused)throw Error('COE 存在正在运行或暂停的任务，请先完成或停止。');
    scope.value='all';await startApiBatch();const state=get();
    if(!state||state.phase!=='done'||state.paused)throw Error(state?.message||'COE 未完成，请检查登录及接口。');
    if(job.teams||job.email){const outcomes=await sendBatchAlerts(state,false);if(outcomes?.some(x=>/失败|未知|跳过/.test(x)))throw Error(outcomes.join('；'));}
  };

  render();if(ruleLoadError)notice(ruleLoadError);badge.textContent='Jira+ v6.10.4 已启动 · 点击显示面板';badge.onclick=()=>{mountPanel();fold.textContent='收起';body.hidden=false;body.style.display='flex';panel.style.height=`min(${CONFIG.panelHeightPx}px,75vh)`;};autoDetail();setTimeout(pump,800);
  } catch(error) { report(error); }
}
initTimeout();initTimeout(true);

(function () {
  'use strict';
  const NONE = '∅';
  const STATUS_NAMES=["New", "Grooming", "Open", "In Progress", "Ready For Test", "Testing", "Completed", "SIT", "Ready For UAT", "UAT", "Ready For Deploy", "DEPLOYED", "Done", "Cancelled"];
  const normalized=name=>String(name||'').trim().replace(/\s+/g,' ').toLowerCase();
  function comparisonPeriod(now,mode='day'){
    const day=86400000,offset=8*3600000;
    const date=t=>new Date(t+offset).toISOString().slice(0,10);
    const midnight=Date.parse(date(now)+'T00:00:00+08:00');
    if(mode==='week'){
      const weekday=new Date(midnight+offset).getUTCDay();
      const monday=midnight-((weekday+6)%7)*day;
      return {cutoff:monday,before:'上周日终',after:'本周截至当前',rate:'周环比',created:'本周创建',
        description:`By week｜上周 ${date(monday-7*day)}～${date(monday-day)}（周日结束时） → 本周 ${date(monday)}～${date(monday+6*day)}（截至当前，未满周）`};
    }
    return {cutoff:midnight,before:'昨日日终',after:'今日截至当前',rate:'日环比',created:'今日创建',
      description:`By day｜昨日 ${date(midnight-day)}（日终） → 今日 ${date(now)}（截至当前）`};
  }
  function selectStatusGroups(source,selection){
    const names=selection===null?STATUS_NAMES:STATUS_NAMES.filter(n=>selection.includes(normalized(n)));
    const allowed=new Map(names.map(n=>[normalized(n),n]));
    return source.map(g=>{
      const rows=new Map();
      for(const row of g.rows.values()){
        const key=normalized(row.name);if(!allowed.has(key))continue;
        if(!rows.has(key))rows.set(key,{id:key,name:allowed.get(key),before:[],after:[]});
        rows.get(key).before.push(...row.before);rows.get(key).after.push(...row.after);
      }
      if(selection!==null)for(const [id,name] of allowed)if(!rows.has(id))rows.set(id,{id,name,before:[],after:[]});
      return {...g,rows,issues:g.issues.filter(x=>allowed.has(normalized(x.before?.name))||allowed.has(normalized(x.after?.name)))};
    });
  }
  function sprints(value) {
    return (Array.isArray(value) ? value : value ? [value] : []).map(v => {
      if (typeof v === 'object' && v !== null) {
        if (!/^\d+$/.test(String(v.id))) throw new Error('Sprint ID 无效');
        return { id: String(v.id), name: v.name || String(v.id), state: v.state || '' };
      }
      const id = /\bid=(\d+)/.exec(v), name = /\bname=(.*?)(?=,\w+=|\]$)/.exec(v), state = /\bstate=([^,\]]+)/.exec(v);
      if (!id) throw new Error('无法识别 Sprint 字段格式，请反馈版本和字段格式。');
      return { id: id[1], name: name ? name[1] : id[1], state: state ? state[1] : '' };
    });
  }
  function statusAt(issue, cutoff, inclusive = true) {
    const created = Date.parse(issue.fields.created);
    if (!Number.isFinite(created)) throw new Error(`${issue.key}: 创建时间无效`);
    if (inclusive ? created > cutoff : created >= cutoff) return null;
    let status = { id: String(issue.fields.status.id), name: issue.fields.status.name };
    const histories = [...issue.changelog.histories].sort((a,b) => Date.parse(b.created)-Date.parse(a.created) || Number(b.id)-Number(a.id));
    for (const h of histories) {
      const time = Date.parse(h.created);
      if (!Number.isFinite(time)) throw new Error(`${issue.key}: 变更时间无效`);
      if (inclusive ? time <= cutoff : time < cutoff) continue;
      for (const item of [...h.items].reverse()) {
        if (item.field === 'status' || item.fieldId === 'status') {
          if (item.from == null || !item.fromString) throw new Error(`${issue.key}: 状态历史不完整`);
          status = { id: String(item.from), name: item.fromString };
        }
      }
    }
    return status;
  }
  function rate(a,b) { return a === 0 ? (b === 0 ? '—' : '新增') : `${((b-a)/a*100).toFixed(1)}%`; }
  function aggregate(issues, field, selected, cutoff, now) {
    const groups = new Map();
    for (const issue of issues) {
      const memberships = sprints(issue.fields[field]);
      const ids = memberships.length ? [...new Set(memberships.map(s=>s.id))] : [NONE];
      const before = statusAt(issue, cutoff, false), after = statusAt(issue, now);
      for (const id of ids.filter(id=>selected.includes(id))) {
        if (!groups.has(id)) groups.set(id, {id, name: memberships.find(s=>s.id===id)?.name || '未分配 Sprint', rows:new Map(), issues:[]});
        const g=groups.get(id);
        for (const [side,status] of [['before',before],['after',after]]) {
          if (!status) continue;
          if (!g.rows.has(status.id)) g.rows.set(status.id,{id:status.id,name:status.name,before:[],after:[]});
          g.rows.get(status.id)[side].push(issue);
        }
        g.issues.push({issue,before,after,changed:before?.id!==after?.id});
      }
    }
    return [...groups.values()];
  }
  function matchesSprint(issue,field,ids){
    const list=sprints(issue.fields[field]);
    return list.length ? list.some(x=>ids.includes(x.id)) : ids.includes(NONE);
  }
  function filterGroups(source,statusIds){
    if(statusIds===null)return source;
    const allowed=new Set(statusIds);
    return source.map(g=>({...g,rows:new Map([...g.rows].filter(([id])=>allowed.has(id))),
      issues:g.issues.filter(x=>allowed.has(x.before?.id)||allowed.has(x.after?.id))}));
  }
  function rowsWithTotal(g){
    const rows=[...g.rows.values()].sort((a,b)=>(STATUS_NAMES.findIndex(n=>normalized(n)===normalized(a.name))+1||STATUS_NAMES.length+1)-(STATUS_NAMES.findIndex(n=>normalized(n)===normalized(b.name))+1||STATUS_NAMES.length+1)||a.name.localeCompare(b.name));
    return [...rows,{name:'所选状态合计',before:rows.flatMap(r=>r.before),after:rows.flatMap(r=>r.after)}];
  }
  function csvCell(v) { let s=String(v ?? ''); if (/^[\s]*[=+\-@]/.test(s)) s="'"+s; return '"'+s.replaceAll('"','""')+'"'; }
  function pageQuery(doc, href) {
    const url = new URL(href);
    // The visible advanced search editor takes precedence over an old saved-filter ID.
    for (const selector of ['#jqltextarea', 'textarea[name="jqlQuery"]', 'input[name="jql"]']) {
      const el = doc.querySelector(selector);
      let visible=!!el;
      for(let node=el;node && visible;node=node.parentElement){
        const style=doc.defaultView?.getComputedStyle(node);
        if(node.hidden || node.getAttribute('aria-hidden')==='true' || style?.display==='none' || style?.visibility==='hidden')visible=false;
      }
      if (visible && el.value?.trim() && !el.disabled) {
        return {jql:el.value.trim(), source:'当前页面 JQL'};
      }
    }
    const jql=url.searchParams.get('jql');
    if(jql?.trim()) return {jql:jql.trim(),source:'当前页面 URL JQL'};
    const key=/\/browse\/([A-Z][A-Z0-9_]*-\d+)/i.exec(url.pathname)?.[1];
    if(key) return {jql:'key = "'+key+'"',source:'当前任务页面'};
    const filter=url.searchParams.get('filter');
    if(filter && /^\d+$/.test(filter)) return {filter,source:'当前页面查询（从页面筛选器解析）'};
    throw new Error('无法识别当前页面的查询条件。请在 Jira 问题列表点击 Search，或切换 Advanced 后重新载入。');
  }
  function validateTeamsUrl(value){
    let u;try{u=new URL(String(value).trim().replace(/\\&/g,'&').replace(/&amp;/g,'&'));}catch{throw new Error('请输入有效的 Teams Workflows HTTPS Webhook 地址。');}
    const allowed=['logic.azure.com','api.powerplatform.com','api.powerautomate.com'];
    if(u.protocol!=='https:'||u.username||u.password||u.hash||u.port||!allowed.some(h=>u.hostname.endsWith('.'+h))||!u.pathname.includes('/workflows/'))throw new Error('仅支持微软 Teams Workflows 的 HTTPS 地址（logic.azure.com / api.powerplatform.com / api.powerautomate.com），不支持旧版 Connector。');
    return u.href;
  }
  function teamsResponseInfo(response={}){
    const parts=[];
    if(Number.isFinite(response.status))parts.push('HTTP '+response.status);
    if(Number.isFinite(response.readyState))parts.push('readyState '+response.readyState);
    let code='';try{code=JSON.parse(response.responseText||'{}').error?.code||'';}catch{}
    if(/^[A-Za-z0-9_.-]{1,100}$/.test(code))parts.push(code);
    const raw=String(response.error||response.message||'');
    const network=/\b(?:net::)?ERR_[A-Z0-9_]+\b/.exec(raw)?.[0];if(network)parts.push(network);
    if(/not permitted|not allowed|refused to connect|whitelist|blocked by.*user/i.test(raw))parts.push('油猴连接授权被拒绝，请检查脚本设置中的用户域名白名单');
    // Do not include raw error strings, response bodies or URLs: they may contain the webhook signature.
    return parts.join('；')||'浏览器/扩展未提供 HTTP 响应';
  }
  function buildTeamsReport(groups,meta,period,jiraUrl){
    const block=(value,extra={})=>({type:'TextBlock',text:String(value),wrap:true,...extra});
    const columns=(values,header=false)=>({type:'ColumnSet',spacing:'Medium',separator:!header,columns:values.map((value,i)=>({
      type:'Column',width:['stretch','42px','42px','50px','64px'][i],spacing:'Small',items:[{type:'TextBlock',text:String(value),...(i?{horizontalAlignment:'Center'}:{wrap:true,horizontalAlignment:'Left'}),...(header?{weight:'Bolder'}:{})}]
    }))});
    const heading=['状态',period.before==='上周日终'?'上周末':'昨日',period.after==='本周截至当前'?'本周':'今日','增减',period.rate];
    const generated=meta.split('｜')[0].trim();
    const body=[block('Sprint Analysis',{size:'Large',weight:'Bolder',color:'Accent'}),
      block(period.description,{size:'Small'}),block(generated,{size:'Small',isSubtle:true,spacing:'Small'})];
    const sections=[];
    for(const g of groups){
      const rows=rowsWithTotal(g),total=rows.at(-1),changes=g.issues.filter(x=>x.changed).length,created=g.issues.filter(x=>!x.before&&x.after).length;
      const model={name:g.name,id:g.id,changes,created,rows:rows.map(r=>{const a=r.before.length,b=r.after.length,d=b-a;return [r.name,String(a),String(b),(d>0?'+':'')+d,rate(a,b)];})};sections.push(model);
      const metrics=[['当前数量',total.after.length],['净状态变化',changes],[period.created,created]];
      const items=[block(g.name,{size:'Medium',weight:'Bolder'}),block('Sprint #'+g.id,{size:'Small',isSubtle:true,spacing:'None'}),
        {type:'ColumnSet',columns:metrics.map(([label,value])=>({type:'Column',width:1,items:[block(value,{size:'Large',weight:'Bolder',color:'Accent',horizontalAlignment:'Center'}),block(label,{size:'Small',isSubtle:true,spacing:'None',horizontalAlignment:'Center'})]}))},
        columns(heading,true)];
      for(let i=0;i<model.rows.length;i++){
        const values=model.rows[i],isTotal=i===model.rows.length-1,row=columns(values,isTotal);row.separator=true;
        if(values[3]!=='0')row.columns[3].items[0].color=Number(values[3])>0?'Attention':'Accent';
        items.push(row);
      }
      body.push({type:'Container',separator:true,spacing:'Large',items});
    }
    body.push(block('当前成员回溯 · 仅统计所选状态 · 数量增减不代表好坏',{size:'Small',isSubtle:true,separator:true}),
      {type:'Container',id:'analysis-details',isVisible:false,items:[block(meta,{size:'Small',isSubtle:true})]});
    const payload={type:'message',attachments:[{contentType:'application/vnd.microsoft.card.adaptive',contentUrl:null,content:{$schema:'http://adaptivecards.io/schemas/adaptive-card.json',type:'AdaptiveCard',version:'1.2',msteams:{width:'Full'},body,actions:[
      {type:'Action.OpenUrl',title:'打开 Jira 查询',url:jiraUrl},{type:'Action.ToggleVisibility',title:'统计口径与查询条件',targetElements:['analysis-details']}
    ]}}]};
    return {payload,sections,heading,generated,meta,description:period.description,jiraUrl,period};
  }
  const core = {sprints,statusAt,rate,aggregate,csvCell,pageQuery,matchesSprint,filterGroups,rowsWithTotal,STATUS_NAMES,normalized,comparisonPeriod,selectStatusGroups,validateTeamsUrl,buildTeamsReport,teamsResponseInfo};
  if (typeof window === 'undefined' && typeof module === 'object' && module.exports) { module.exports = core; return; }
  // An older duplicate userscript may run first. Replace its panel rather than silently exiting.
  const existing=document.getElementById('jsa-host');
  if(existing){
    const previous=existing.dataset.jsaVersion||existing.shadowRoot?.querySelector('h1 small')?.textContent?.replace(/^v/,'')||'0.0.0';
    const parts=v=>v.split('.').map(Number),a=parts(previous),b=parts('0.1.9');
    const comparison=a.reduce((r,n,i)=>r||n-(b[i]||0),0);
    if(comparison>=0)return;
    existing.remove();
  }
  const host=document.createElement('div'); host.id='jsa-host';host.dataset.jsaVersion='0.1.9'; hub.sprint.append(host);
  const root=host.attachShadow({mode:'open'});
  root.innerHTML=`<style>
  :host{all:initial;font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#172b4d}*{box-sizing:border-box}button,input,select{font:inherit}button{cursor:pointer;border:1px solid #c9d3e0;border-radius:6px;background:white;color:#172b4d;padding:7px 12px}button:hover{background:#edf3ff}.primary:hover,#launch:hover{background:#0747a6}#close{white-space:nowrap}button:disabled{opacity:.5;cursor:wait}.primary,#launch{background:#0052cc;color:white;border-color:#0052cc}#launch{position:fixed;right:24px;bottom:24px;z-index:2147483646;box-shadow:0 5px 20px #091e4240}#overlay{position:fixed;inset:0;background:#091e4260;z-index:2147483647;padding:3vh 3vw;display:none}#panel{background:#f7f9fc;border-radius:14px;max-width:1280px;margin:auto;height:94vh;overflow:auto;box-shadow:0 20px 80px #091e4255;padding:24px}header{display:flex;align-items:center;justify-content:space-between}h1{font-size:24px;margin:0}h2{font-size:17px;margin:0 0 12px}.muted{color:#5e6c84}p{margin:8px 0}.controls{display:flex;gap:16px;align-items:end;flex-wrap:wrap;margin:18px 0}label{display:flex;flex-direction:column;gap:5px}input,select{border:1px solid #b3bfd0;border-radius:5px;padding:7px;background:white;color:#172b4d}fieldset{margin:0;border:1px solid #b3bfd0;border-radius:6px;padding:8px;background:white;min-width:280px;max-width:100%}.choices{height:140px;overflow:auto;max-width:430px}.choices label{display:flex;flex-direction:row;align-items:center;gap:8px;padding:3px;cursor:pointer}.choices input{margin:0}.tools{display:flex;gap:8px;margin-bottom:5px}.tools button{padding:2px 8px}legend{padding:0 5px}.card{overflow-x:auto;background:white;border:1px solid #dfe5ed;border-radius:9px;margin:16px 0;padding:18px}.notice{padding:10px 14px;background:#eaf1ff;border-radius:6px}#message{white-space:pre-wrap}#message.error{background:#fff0ed;color:#ae2a19;padding:12px}table{width:100%;border-collapse:collapse;margin-top:10px}th,td{text-align:left;border-bottom:1px solid #e8ecf2;padding:9px 10px}th{background:#f4f6fa;color:#5e6c84}td button{border:0;padding:0;color:#0052cc;background:none;text-decoration:underline}.delta{font-variant-numeric:tabular-nums;font-weight:600}a{color:#0052cc}#detail{overflow:auto}small{font-size:12px}@media(max-width:650px){#panel{padding:14px}.controls{display:block}label{margin:10px 0}#sprints{min-width:0;width:100%}th,td{padding:6px}h1{font-size:20px}}
  </style><button id="launch">◷ Sprint Analysis v0.1.9</button><div id="overlay"><section id="panel" role="dialog" aria-modal="true" aria-label="Sprint Analysis"><header><div><h1>Sprint <small class="muted">v0.1.9</small></h1><p class="muted"><span id="period-description"></span> · Asia/Shanghai（UTC+08:00）</p></div><button id="close" aria-label="关闭">关闭</button></header>
  <div class="notice">口径：以本次查询匹配的成员回溯对比时点的状态；不还原历史 Sprint 成员或历史筛选条件。已关闭 Sprint 也可能保留在任务 Sprint 字段中；同一任务可出现在多个 Sprint，各 Sprint 不可直接相加。</div>
  <div class="controls"><label>对比维度<select id="period"><option value="day">By day · 昨天 / 今天</option><option value="week">By week · 上周 / 本周（周一至周日）</option></select></label><button id="load">载入当前页面（全部分页）</button><fieldset id="sprint-box"><legend>Sprint（勾选，可多选）</legend><div class="tools"><button id="sprint-all" type="button">全选</button><button id="sprint-none" type="button">清空</button></div><div id="sprints" class="choices"></div></fieldset><fieldset id="status-box"><legend>状态（默认全部，可多选）</legend><label><input type="checkbox" id="status-all" checked>全部指定状态（以下 14 个）</label><div class="tools"><button id="status-select-all" type="button">全选</button><button id="status-clear" type="button">清空</button></div><div id="statuses" class="choices"></div></fieldset><button id="run" class="primary">开始分析</button><button id="export" disabled>导出 CSV</button><button id="report-export" disabled>导出交互报告</button><label class="report-option"><input id="attach-report" type="checkbox" checked>邮件附交互报告（含 Jira 明细）</label><fieldset id="notify-box"><legend>通知项目（工单所属项目，可多选）</legend><div id="notify-project" role="group" aria-label="推送项目（可多选）"></div></fieldset><button id="teams-preview" class="primary" disabled>预览并推送到 Teams</button></div>
  <p class="muted">统计当前页面查询的全部分页，不扩大到整个 Sprint。修改 Jira 搜索条件后请先点击 Search，再重新载入。若页面排除了已解决任务，完成数量也会受限。</p><p id="message" role="status">点击“载入当前页面”读取全部结果；本工具只读取 Jira，不修改任务。</p><div id="results"></div><div id="detail"></div></section></div>`;
  const teamsDialog=document.createElement('div');teamsDialog.id='teams-dialog';teamsDialog.setAttribute('role','dialog');teamsDialog.setAttribute('aria-modal','true');teamsDialog.style.cssText='display:none;position:fixed;inset:0;background:#091e4280;z-index:2147483647;padding:4vh 4vw;overflow:auto';
  const teamsBox=document.createElement('section');teamsBox.className='card';teamsBox.style.cssText='max-width:900px;margin:0 auto;padding:24px;max-height:90vh;overflow:auto';teamsDialog.append(teamsBox);root.append(teamsDialog);
  const $=id=>root.getElementById(id); let reportIssues=[], reportIds=[], reportStatuses=null, reportNow=0; let field, groups=[], busy=false, reportMeta='', loadedQuery='', reportJiraUrl='', activePeriod=comparisonPeriod(Date.now());
  $('period-description').textContent=activePeriod.description;
  const message=(s,error=false)=>{ $('message').textContent=s; $('message').className=error?'error':''; };
  function text(tag,content,parent){const e=document.createElement(tag); e.textContent=content; parent.append(e); return e;}
  async function api(path) {
    const controller=new AbortController(), timeout=setTimeout(()=>controller.abort(),30000);
    try {
      const res=await fetch(path,{credentials:'same-origin',headers:{Accept:'application/json'},signal:controller.signal});
      if (!res.ok) throw new Error(`Jira HTTP ${res.status}：${res.status===401||res.status===403?'请先登录并确认筛选器/任务访问权限。':'请求失败，请稍后重试或检查接口权限。'}`);
      if (!res.headers.get('content-type')?.includes('application/json')) throw new Error('Jira 返回了登录页或非 JSON 内容，请先登录 Jira 后重试。');
      return await res.json();
    } finally {clearTimeout(timeout);}
  }
  async function currentQuery(){
    const query=pageQuery(document,location.href);
    if(query.jql)return query.jql;
    const data=await api('/rest/api/2/filter/'+query.filter);
    if(!data.jql?.trim())throw new Error('当前页面未返回有效的 JQL，请切换 Advanced 后重新载入。');
    return data.jql.trim();
  }
  async function detectField(){
    if(field)return field;
    const fields=await api('/rest/api/2/field');
    const candidates=fields.filter(f=>f.schema?.custom==='com.pyxis.greenhopper.jira:gh-sprint');
    if(candidates.length!==1)throw new Error('无法唯一识别 Sprint 自定义字段，请向维护者反馈 /rest/api/2/field 中的 Sprint 字段定义。');
    return field=candidates[0].id;
  }
  async function search(jql){
    let start=0,total,all=[]; const seen=new Set();
    do {
      const params=new URLSearchParams({jql,fields:`summary,status,created,updated,assignee,${field}`,startAt:String(start),maxResults:'100'});
      const page=await api('/rest/api/2/search?'+params);
      if(!Array.isArray(page.issues)||!Number.isFinite(page.total))throw new Error('搜索接口响应格式不支持');
      if(total!==undefined&&total!==page.total)throw new Error('查询过程中任务数量发生变化，请重试以免分页遗漏。');
      total=page.total;
      if(!page.issues.length && start<total)throw new Error('分页提前结束，已停止统计以避免遗漏。');
      for(const issue of page.issues){if(seen.has(issue.key))throw new Error('分页出现重复任务，请重试。');seen.add(issue.key);all.push(issue);}
      start+=page.issues.length;message(`读取任务 ${start} / ${total}…`);
    }while(start<total);
    return all;
  }
  async function history(issue){
    const params=new URLSearchParams({fields:`summary,status,created,updated,assignee,${field}`,expand:'changelog'});
    const full=await api('/rest/api/2/issue/'+encodeURIComponent(issue.key)+'?'+params);
    // The issue detail is authoritative. Search-index timestamps can differ or lag.
    // Never infer an actual user edit from a raw updated-string mismatch.
    let c=full.changelog;
    if(!c||!Array.isArray(c.histories)||!Number.isFinite(c.total))throw new Error(`${issue.key} 未返回可验证完整性的变更历史。`);
    if((c.startAt||0)!==0||c.histories.length!==c.total){
      let histories=[],start=0,total;
      do {
        let p;try{p=await api('/rest/api/2/issue/'+encodeURIComponent(issue.key)+'/changelog?startAt='+start+'&maxResults=100');}catch{throw new Error(`${issue.key} 历史被截断，且服务器不支持完整历史分页；本次结果不生成。`);}
        const values=p.values||p.histories;
        if(!Array.isArray(values)||!Number.isFinite(p.total)||(total!==undefined&&p.total!==total)||(!values.length&&start<p.total))throw new Error(`${issue.key} 历史分页不完整，请重试。`);
        total=p.total;histories.push(...values);start+=values.length;
      }while(start<total);
      if(new Set(histories.map(h=>h.id)).size!==total)throw new Error(`${issue.key} 历史分页重复或缺失。`);
      c=full.changelog={histories,total};
    }
    return full;
  }
  async function guard(job){
    if(busy)return;busy=true;const controls=['load','run','sprint-box','status-box','period'];controls.forEach(id=>$(id).disabled=true);$('report-export').disabled=$('export').disabled=true;$('teams-preview').disabled=true;
    groups=[];$('notify-project').replaceChildren();$('results').replaceChildren();$('detail').replaceChildren();
    try{await job();}catch(e){message(e.name==='AbortError'?'请求超过 30 秒，请检查网络或 VPN 后重试。':e.message,true);}finally{busy=false;controls.forEach(id=>$(id).disabled=false);$('report-export').disabled=$('export').disabled=!groups.length;$('teams-preview').disabled=!groups.length;}
  }
  function renderNotifyProjects(preserve=false){
    const picker=$('notify-project'),previous=new Map([...picker.querySelectorAll('input')].map(x=>[x.value,x.checked]));picker.replaceChildren();
    const configured=new Map(hub.projects().map(p=>[p.projectKey,p]));
    const keys=[...new Set(groups.flatMap(g=>g.issues.map(x=>x.issue.key.split('-')[0].toUpperCase())))].filter(key=>configured.has(key)).sort();
    for(const key of keys){
      const config=configured.get(key),label=text('label','',picker),input=document.createElement('input');input.type='checkbox';input.value=key;input.checked=preserve&&previous.has(key)?previous.get(key):config.enabled!==false;
      const state=config.enabled===false?'（通知已停用）':!config.webhook?'（未配置 Webhook）':'';
      label.append(input,document.createTextNode(key+state));label.title='Story / 工单所属项目：'+key+(config.projectGroup?'；共享配置：'+config.projectGroup:'')+(state?'；请在配置中心启用并保存':'');
      if(config.enabled===false)input.onchange=()=>{if(input.checked)message(key+' 通知已停用。请在配置中心勾选“启用通知”并保存后推送。',true);};
    }
    if(!keys.length)text('span',groups.length?'本次结果没有已配置的通知项目。':'分析后显示本次结果的通知项目。',picker);
    const note=text('small','仅显示本次结果中已配置的工单所属项目，不是 Epic 名称。',picker);note.style.cssText='flex-basis:100%;color:#718098;font-size:11px';
    const settings=text('button','通知设置',picker);settings.type='button';settings.onclick=()=>hub.configure();
  }
  addEventListener('jira-plus-project-config',()=>renderNotifyProjects(true));

  function selected(){return [...$('sprints').querySelectorAll('input:checked')].map(o=>o.value);}
  function selectedStatuses(){return $('status-all').checked?null:[...$('statuses').querySelectorAll('input:checked')].map(o=>o.value);}
  function choice(parent,id,name,checked){
    const label=document.createElement('label'), input=document.createElement('input');input.type='checkbox';input.value=id;input.checked=checked;label.append(input,document.createTextNode(name));parent.append(label);
  }
  function invalidate(){if(busy)return;groups=[];$('notify-project').replaceChildren();$('results').replaceChildren();$('detail').replaceChildren();$('report-export').disabled=$('export').disabled=true;$('teams-preview').disabled=true;message(`已选择 ${selected().length} 个 Sprint；状态：${$('status-all').checked?'全部':selectedStatuses().length+' 项'}。请点击“开始分析”。`);}
  $('period').onchange=()=>{$('period-description').textContent=comparisonPeriod(Date.now(),$('period').value).description;invalidate();};
  $('sprints').onchange=invalidate;
  $('statuses').onchange=()=>{const inputs=[...$('statuses').querySelectorAll('input')];$('status-all').checked=inputs.length>0&&inputs.every(x=>x.checked);invalidate();};
  $('status-all').onchange=()=>{for(const x of $('statuses').querySelectorAll('input'))x.checked=$('status-all').checked;invalidate();};
  $('status-select-all').onclick=()=>{$('status-all').checked=true;$('status-all').onchange();};
  $('status-clear').onclick=()=>{$('status-all').checked=false;$('status-all').onchange();};
  for(const [id,checked] of [['sprint-all',true],['sprint-none',false]])$(id).onclick=()=>{for(const x of $('sprints').querySelectorAll('input'))x.checked=checked&&!hub.closedSprint(x.parentElement.textContent)&&x.value!==NONE;invalidate();};
  async function load(){
    loadedQuery='';$('notify-project').replaceChildren();$('sprints').replaceChildren();
    await detectField();const query=await currentQuery(), issues=await search(query), map=new Map();
    for(const i of issues){const list=sprints(i.fields[field]);if(!list.length)map.set(NONE,{id:NONE,name:'未分配 Sprint',state:''});for(const s of list)map.set(s.id,s);}
    $('sprints').replaceChildren();
    const options=[...map.values()].sort((a,b)=>(/active/i.test(b.state)?1:0)-(/active/i.test(a.state)?1:0)||b.name.localeCompare(a.name));
    for(const s of options)choice($('sprints'),s.id,`${s.name}${s.state?' · '+s.state:''} [${s.id}]`,!hub.closedSprint(s.name+' '+s.state)&&s.id!==NONE);

    $('statuses').replaceChildren();$('status-all').checked=true;
    for(const name of STATUS_NAMES)choice($('statuses'),normalized(name),name,true);
    loadedQuery=query;
    message(`已读取当前页面全部 ${issues.length} 条任务、${options.length} 个 Sprint 分组。可多选后分析。\nJQL：${loadedQuery}${issues.length?'':'（当前页面没有可见任务）'}`);
  }
  function details(title,items){hub.showIssueDetails(title,items,activePeriod); }
  function render(){
    const result=$('results');result.replaceChildren();text('p',reportMeta,result);
    for(const g of groups){
      const card=document.createElement('section');card.className='card';result.append(card);text('h2',g.name+' · '+g.id,card);
      const changes=g.issues.filter(x=>x.changed), created=g.issues.filter(x=>!x.before&&x.after);
      const detail=text('button',`查看变化 ${changes.length} 条（${activePeriod.created} ${created.length} 条）`,card);detail.onclick=()=>details(g.name+' · 净状态变化 / 新建任务',changes);
      const table=document.createElement('table');card.append(table);const head=document.createElement('tr');table.append(head);['状态',activePeriod.before,activePeriod.after,'增减',activePeriod.rate].forEach(h=>text('th',h,head));
      const rows=rowsWithTotal(g);
      for(const r of rows){const tr=document.createElement('tr');table.append(tr);text('td',r.name,tr);for(const side of ['before','after']){const td=document.createElement('td');tr.append(td);const b=text('button',String(r[side].length),td);b.onclick=()=>{const keys=new Set(r[side].map(i=>i.key));details(`${g.name} · ${r.name} · ${side==='before'?activePeriod.before:activePeriod.after}`,g.issues.filter(x=>keys.has(x.issue.key)));};}const delta=r.after.length-r.before.length;text('td',(delta>0?'+':'')+delta,tr).className='delta';text('td',rate(r.before.length,r.after.length),tr);}
    }
  }
  async function run(){
    const ids=selected();if(!ids.length)throw new Error('请先载入并选择 Sprint。');await detectField();
    const statusIds=selectedStatuses();if(statusIds!==null&&!statusIds.length)throw new Error('请至少选择一个状态，或勾选全部状态。');
    const jql=await currentQuery();
    if(jql!==loadedQuery)throw new Error('当前页面查询已改变，请重新“载入当前页面”后再分析。');
    const now=Date.now();activePeriod=comparisonPeriod(now,$('period').value);const cutoff=activePeriod.cutoff;
    $('period-description').textContent=activePeriod.description;
    const pageIssues=await search(jql), issues=pageIssues.filter(i=>matchesSprint(i,field,ids)), full=new Array(issues.length);let cursor=0,done=0,failed;
    await Promise.all(Array.from({length:Math.min(3,issues.length)},async()=>{while(cursor<issues.length&&!failed){const i=cursor++;try{full[i]=await history(issues[i]);message(`读取完整历史 ${++done} / ${issues.length}…`);}catch(e){failed=e;}}}));
    if(failed)throw failed;
    const scoped=full.filter(i=>matchesSprint(i,field,ids));
    const allGroups=aggregate(scoped,field,ids,cutoff,now);
    const calculated=selectStatusGroups(allGroups,statusIds);
    const stateNames=statusIds===null?'全部指定的 14 个状态':[...$('statuses').querySelectorAll('input:checked')].map(x=>x.parentElement.textContent).join('、');
    reportMeta=`查询开始 ${new Date(now).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false})}（上海）｜${activePeriod.description}｜当前页面全部分页｜JQL：${jql}｜所选 Sprint：${ids.join("、")}｜状态：${stateNames}｜当前成员回溯`;
    reportJiraUrl=location.origin+'/issues/?'+new URLSearchParams({jql});
    reportIssues=scoped;reportIds=ids;reportStatuses=statusIds;reportNow=now;
    groups=calculated;renderNotifyProjects();render();message(`分析完成：页面共 ${pageIssues.length} 条；所选 Sprint 匹配 ${scoped.length} 条；所选状态涉及 ${new Set(groups.flatMap(g=>g.issues.map(x=>x.issue.key))).size} 条，${groups.length} 个 Sprint 分组。合计仅包含所选状态。`);
  }
// Self-contained snapshot: no Jira API, authentication tokens, or external assets.
function buildInteractiveReport(model){
  const data=JSON.stringify(model).replace(/[<>&\u2028\u2029]/g,c=>'\\u'+c.charCodeAt(0).toString(16).padStart(4,'0'));
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Jira+ · Sprint 报告</title><style>
*{box-sizing:border-box}body{margin:0;background:#f3f6fc;color:#24334d;font:14px/1.6 -apple-system,BlinkMacSystemFont,'Segoe UI','Microsoft YaHei',sans-serif}header{background:white;border-bottom:1px solid #e0e7f1;padding:20px max(24px,calc((100vw - 1120px)/2))}h1{font-size:24px;margin:0}h2{font-size:18px;margin:0 0 10px}small,.muted{color:#7b899e;font-size:12px}main{max-width:1168px;padding:24px;margin:auto}.toolbar{display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin:16px 0}.card{background:white;border:1px solid #e0e7f1;border-radius:12px;padding:20px;margin:16px 0;overflow-x:auto}button,select,input,a.action{font:inherit;border:1px solid #d9e2f1;border-radius:7px;padding:7px 12px;background:white;color:#245de8;cursor:pointer}input{color:#24334d;min-width:230px}.action{text-decoration:none}table{width:100%;border-collapse:collapse}th,td{padding:11px 12px;border-bottom:1px solid #edf1f7;text-align:left;vertical-align:top}th{background:#f3f6fc;color:#738198;font-size:12px}td.number,th.number{text-align:center}td.number button{border:0;padding:0;background:none;text-decoration:underline;font-variant-numeric:tabular-nums}tr.total{background:#edf3ff;font-weight:700}.positive{color:#d13438}.changed{background:#fff9eb}a{color:#245de8}#detail{position:fixed;z-index:10;inset:8vh max(16px,calc((100vw - 1050px)/2));margin:0;box-shadow:0 0 0 100vmax #14284666,0 20px 80px #14284655;overflow:auto;resize:both}#detail[hidden]{display:none}#detail-close{float:right;color:#d13438;background:#fff1f2;border:0}.tag{display:inline-block;background:#eaf0ff;color:#245de8;font-size:11px;padding:3px 8px;border-radius:5px;margin-left:8px}#meta{white-space:pre-wrap;overflow-wrap:anywhere}#empty{color:#7b899e}@media(max-width:640px){main{padding:12px}.card{padding:12px}th,td{padding:8px}h1{font-size:20px}}@media print{body{background:white}.toolbar,button{display:none}.card{break-inside:avoid}}
</style></head><body><header><h1>Jira+ <span class="tag">Sprint Analysis</span></h1><small>独立交互报告 · 分析快照</small></header><main><p id="period"></p><div class="toolbar"><label>项目 <select id="project"></select></label><button id="all-changes">查看全部变化</button><a id="jira-query" class="action" target="_blank" rel="noopener noreferrer">打开 Jira 查询</a></div><p class="muted">点击昨日 / 今日数字，在独立弹窗查看对应工单及状态前后变化；报告保持生成时的数据，不会自动更新。</p><div id="groups"></div><section id="detail" class="card" role="dialog" aria-modal="true" aria-label="工单明细" hidden><button id="detail-close" aria-label="关闭工单明细">❌</button><h2 id="detail-title"></h2><div class="toolbar"><input id="search" placeholder="筛选 Jira 编号、摘要或 Assignee" aria-label="筛选明细"><span id="detail-count" class="muted"></span></div><table><thead><tr><th>Issue</th><th>摘要</th><th>Assignee</th><th id="before-heading"></th><th id="after-heading"></th><th>变化</th></tr></thead><tbody id="detail-rows"></tbody></table><p id="empty" hidden>没有对应任务。</p></section><details class="card"><summary>统计口径与查询条件</summary><p id="meta" class="muted"></p></details></main><script id="report-data" type="application/json">${data}</script><script>
(${reportRuntime.toString()})();
</script></body></html>`;
}
function reportRuntime(){
 'use strict';
 const model=JSON.parse(document.getElementById('report-data').textContent),$=id=>document.getElementById(id);
 function el(tag,value,parent){const n=document.createElement(tag);if(value!==null)n.textContent=String(value);parent.append(n);return n;}
 function safeUrl(value){try{const u=new URL(value);return u.protocol==='https:'||u.protocol==='http:'?u.href:'';}catch{return '';}}
 const jira=safeUrl(model.jiraUrl);$('jira-query').href=jira||'#';$('period').textContent=model.period.description;$('meta').textContent=model.meta;
 $('before-heading').textContent=model.period.before;$('after-heading').textContent=model.period.after;
 const projectOf=key=>key.split('-')[0];let selection=[],detailTitle='';
 const keys=[...new Set(model.groups.flatMap(g=>g.issues.map(i=>projectOf(i.key))))].sort();el('option','全部项目',$('project')).value='';for(const key of keys)el('option',key,$('project')).value=key;
 function filtered(issues){return issues.filter(i=>!$('project').value||projectOf(i.key)===$('project').value);}
 function renderDetails(){
   const term=$('search').value.trim().toLowerCase(),items=selection.filter(i=>(i.key+' '+i.summary+' '+(i.assignee||'未分配')).toLowerCase().includes(term));$('detail-rows').replaceChildren();$('detail-title').textContent=detailTitle;$('detail-count').textContent=items.length+' / '+selection.length+' 条';$('empty').hidden=items.length>0;
   for(const item of items){const tr=el('tr',null,$('detail-rows'));if(item.before!==item.after)tr.className='changed';const td=el('td',null,tr),link=el('a',item.key,td);if(jira){link.href=new URL('/browse/'+encodeURIComponent(item.key),jira).href;link.target='_blank';link.rel='noopener noreferrer';}el('td',item.summary,tr);el('td',item.assignee||'未分配',tr);el('td',item.before||'尚未创建',tr);el('td',item.after||'尚未创建',tr);el('td',!item.before?'新建':item.before!==item.after?'状态变化':'未变化',tr);}
 }
 function show(title,items){selection=items;detailTitle=title;$('search').value='';$('detail').hidden=false;renderDetails();$('detail-close').focus();}
 function render(){
  $('groups').replaceChildren();$('detail').hidden=true;
  for(const group of model.groups){const issues=filtered(group.issues);if(!issues.length&&$('project').value)continue;const byKey=new Map(issues.map(i=>[i.key,i]));const card=el('section',null,$('groups'));card.className='card';el('h2',group.name+' · '+group.id,card);const changed=issues.filter(i=>i.changed),created=issues.filter(i=>!i.before&&i.after);el('button','查看变化 '+changed.length+' 条（新建 '+created.length+' 条）',card).onclick=()=>show(group.name+' · 净状态变化 / 新建任务',changed);
   const table=el('table',null,card),head=el('tr',null,el('thead',null,table));['状态',model.period.before,model.period.after,'增减',model.period.rate].forEach((h,i)=>{const th=el('th',h,head);if(i)th.className='number';});const body=el('tbody',null,table);
   for(const row of group.rows){if(model.analysisType==='epic-analysis'&&!row.before.some(k=>byKey.has(k))&&!row.after.some(k=>byKey.has(k)))continue;const tr=el('tr',null,body);if(row.total)tr.className='total';el('td',row.name,tr);const sets={};for(const side of ['before','after']){sets[side]=row[side].filter(k=>byKey.has(k));const td=el('td',null,tr);td.className='number';const button=el('button',sets[side].length,td);button.setAttribute('aria-label',group.name+' '+row.name+' '+model.period[side]+'明细');button.onclick=()=>show(group.name+' · '+row.name+' · '+model.period[side],sets[side].map(k=>byKey.get(k)));}const a=sets.before.length,b=sets.after.length,delta=b-a;el('td',(delta>0?'+':'')+delta,tr).className='number'+(delta>0?' positive':'');el('td',a===0?(b===0?'—':'新增'):((b-a)/a*100).toFixed(1)+'%',tr).className='number';}
  }
 }
 $('detail-close').onclick=()=>{$('detail').hidden=true;};document.addEventListener('keydown',e=>{if(e.key==='Escape')$('detail').hidden=true;});
 $('project').onchange=render;$('search').oninput=renderDetails;$('all-changes').onclick=()=>{const map=new Map();for(const g of model.groups)for(const i of filtered(g.issues))if(i.changed)map.set(i.key,i);show('全部 Sprint · 净状态变化 / 新建任务',[...map.values()]);};render();
}
if(typeof module==='object'&&module.exports)module.exports={buildInteractiveReport};

  function reportModel(source=groups){
    return {version:1,analysisType:'sprint-analysis',meta:reportMeta,jiraUrl:reportJiraUrl,period:activePeriod,generatedAt:new Date(reportNow).toISOString(),groups:source.map(group=>{const rows=rowsWithTotal(group);return {id:group.id,name:group.name,issues:group.issues.map(x=>({key:x.issue.key,summary:x.issue.fields.summary||'',assignee:x.issue.fields.assignee?.displayName||'未分配',before:x.before?.name||'',after:x.after?.name||'',changed:x.changed})),rows:rows.map((row,i)=>({name:row.name,total:i===rows.length-1,before:row.before.map(x=>x.key),after:row.after.map(x=>x.key)}))};})};
  }
  function reportFile(source=groups,project='all'){
    return {name:'Jira-Monitor-'+project+'-'+new Date(reportNow).toISOString().replace(/[:.]/g,'-')+'.html',html:buildInteractiveReport(reportModel(source))};
  }
  function downloadReport(file){const url=URL.createObjectURL(new Blob([file.html],{type:'text/html;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download=file.name;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);}
  function reportBase64(html){const bytes=new TextEncoder().encode(html);let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(binary);}
  $('report-export').onclick=()=>{if(!busy&&groups.length)downloadReport(reportFile());};

  let teamsSending=false,teamsFocus;
  function openTeams(title){
    teamsFocus=root.activeElement||document.activeElement;teamsBox.replaceChildren();text('h2',title,teamsBox);teamsDialog.style.display='block';teamsDialog.setAttribute('aria-label',title);
  }
  function closeTeams(){if(teamsSending)return;teamsDialog.style.display='none';teamsBox.replaceChildren();teamsFocus?.focus();}
  function teamsButton(id,label,action){const b=text('button',label,teamsBox);b.id=id;b.style.margin='8px 8px 0 0';b.onclick=action;return b;}
  function teamsConfig(){hub.configure();}
  async function teamsPreview(automated=false){
    automated=automated===true;
    if(busy||teamsSending||!groups.length)return;
    const keys=[...$('notify-project').querySelectorAll('input:checked')].map(input=>input.value);
    if(!keys.length){if(automated)throw Error('请至少勾选一个推送项目。');message('请至少勾选一个推送项目。',true);return;}
    try{
      // Freeze each project's report and destination before displaying the confirmation.
      const deliveries=keys.map(projectKey=>{
        const configured=hub.target(projectKey+'-1');
        if(!configured?.webhook)throw Error(projectKey+' 通知未启用或未配置 Webhook，请先在配置中心保存。未发送任何消息。');
        const target={...configured,recipients:[...(configured.recipients||[])]},destination=validateTeamsUrl(target.webhook);
        const projectIssues=reportIssues.filter(i=>i.key.split('-')[0].toUpperCase()===projectKey);
        if(!projectIssues.length)throw Error(projectKey+' 在本次报告中没有任务，请重新分析。');
        const projectGroups=selectStatusGroups(aggregate(projectIssues,field,reportIds,activePeriod.cutoff,reportNow),reportStatuses);
        const report=buildTeamsReport(projectGroups,reportMeta+'｜仅项目 '+projectKey,activePeriod,reportJiraUrl);
        const bodyText=projectKey+' · '+report.description+'\n'+report.sections.map(section=>section.name+'\n'+[report.heading,...section.rows].map(row=>row.join(' | ')).join('\n')).join('\n\n');
        report.payload.projectKey=projectKey;report.payload.reportType='sprint-analysis';
        report.payload.email=target.recipients.length?{enabled:true,recipients:target.recipients,to:target.recipients.join(';'),subject:'[Jira+] '+projectKey+' · Sprint Analysis',bodyText,bodyHtml:hub.emailCard({title:projectKey+' · Sprint Analysis',subtitle:report.description,sections:report.sections.map(section=>({title:section.name,headers:report.heading,rows:section.rows,total:true,deltaColumn:3})),meta:reportMeta,url:reportJiraUrl})}:{enabled:false};
        const file=reportFile(projectGroups,projectKey);
        if(report.payload.email.enabled&&(hub.jobDelivery?hub.jobDelivery.attach:$('attach-report').checked)){report.payload.email.attachments=[{name:file.name,contentType:'text/html',contentBytes:reportBase64(file.html)}];report.payload.email.bodyHtml+='<p style="font:12px Arial;color:#718098">附交互报告：'+hub.escapeHtml(file.name)+'。请下载附件并使用浏览器打开，点击数字查看工单明细和状态变化。</p>';}
        if(hub.jobDelivery?.email&&!report.payload.email.enabled)throw Error(projectKey+' 未配置邮件收件人');
        hub.deliveryPayload(report.payload);
        const oversized=new TextEncoder().encode(JSON.stringify(report.payload.attachments)).length>26*1024;
        const emailOnly=oversized&&report.payload.reportType==='epic-analysis'&&!hub.jobDelivery?.combine;
        if(oversized&&!emailOnly&&!hub.jobDelivery?.combine)throw Error(projectKey+' 卡片超过 Teams 大小限制，请减少所选 Sprint 后重试。');
        if(emailOnly&&!report.payload.email.enabled)throw Error(projectKey+' 所选数量超过 Teams 大小限制，但未配置邮件收件人，请先在配置中心保存。未发送任何消息。');
        report.payload.teams={enabled:!emailOnly&&hub.jobDelivery?.teams!==false};
        if(emailOnly){report.payload.attachments=[];report.payload.deliveryMode='email-only';}
        return {projectKey,target,destination,report,file,emailOnly,data:JSON.stringify(report.payload)};
      });
      openTeams('项目推送预览 · '+deliveries.length+' 个项目');
      if(deliveries.some(item=>item.emailOnly))message('所选数量超过 Teams 大小限制，所选数据只通过邮件发送');
      text('p','每个项目分别发送到对应 Teams 和邮件收件人。勾选邮件附报告时，载荷另含该项目的 Jira 编号、摘要及状态变化，需工作流配置附件步骤；下方可先下载检查。',teamsBox);
      const preview=document.createElement('div');preview.id='teams-preview-content';teamsBox.append(preview);
      for(const item of deliveries){
        const card=text('section','',preview);card.className='card';
        text('h2',item.projectKey+' · Sprint Analysis',card);
        if(item.emailOnly)text('p','所选数量超过 Teams 大小限制，所选数据只通过邮件发送',card).setAttribute('role','status');
        const download=text('button','下载该项目交互报告',card);download.onclick=()=>downloadReport(item.file);
        text('p',item.report.payload.email.attachments?.length?'邮件包含交互报告附件载荷（需要工作流映射附件字段）':'邮件未附交互报告',card).className='muted';
        const mailPreview=text('button','预览邮件正文',card);mailPreview.onclick=()=>hub.previewEmail(item.report.payload.email);
        text('p','邮件：'+(item.target.recipients.join(';')||'未配置'),card);
        text('p','Webhook 主机：'+new URL(item.destination).hostname+'（密钥已隐藏）',card).className='muted';
        text('p',item.report.description,card);
        for(const section of item.report.sections){
          text('h3',section.name,card);const table=document.createElement('table');card.append(table);
          const head=document.createElement('tr');table.append(head);item.report.heading.forEach(h=>text('th',h,head));
          section.rows.forEach((values,index)=>{const tr=document.createElement('tr');table.append(tr);if(index===section.rows.length-1)tr.style.cssText='font-weight:700;background:#edf3ff';values.forEach((v,i)=>{const td=text('td',v,tr);if(i===3&&Number(v)>0)td.style.color='#d13438';});});
        }
      }
      const status=text('p','尚未发送。确认后按项目分别提交；不会自动重试。',teamsBox);status.id='teams-send-status';status.setAttribute('role','status');
      const cancel=teamsButton('teams-preview-cancel','取消',closeTeams);
      let deliveryPromise;
      const deliver=async()=>{
        if(teamsSending||send.disabled)return;
        if(typeof GM_xmlhttpRequest!=='function'){status.textContent='缺少扩展跨域请求权限，请更新脚本。';return;}
        teamsSending=true;send.disabled=true;cancel.disabled=true;
        const outcomes=[];
        for(const item of deliveries){
          if(!hub.target(item.projectKey+'-1')){outcomes.push(item.projectKey+'：通知已停用，跳过');continue;}
          status.textContent=[...outcomes,item.projectKey+'：正在提交…'].join('\n');
          const outcome=await new Promise(resolve=>{
            let settled=false,request;
            const finish=value=>{if(settled)return;settled=true;clearTimeout(timer);resolve(value);};
            const timer=setTimeout(()=>{finish('超时，结果未知，请检查工作流；未重试');request?.abort?.();},30000);
            try{request=GM_xmlhttpRequest({method:'POST',url:item.destination,headers:{'Content-Type':'application/json'},data:item.data,timeout:30000,anonymous:true,redirect:'error',
              onload:r=>finish(r.status>=200&&r.status<300?'已提交（HTTP '+r.status+'），最终投递请查工作流':'失败：'+teamsResponseInfo(r)),
              onerror:r=>finish('网络失败，结果可能未知：'+teamsResponseInfo(r)+'；未重试'),
              ontimeout:()=>finish('超时，结果未知，请检查工作流；未重试'),onabort:()=>finish('已中止，结果未知；未重试')});}
            catch(error){finish('请求未发出：'+teamsResponseInfo(error));}
          });
          outcomes.push(item.projectKey+'：'+(item.emailOnly?'仅邮件 · ':'')+outcome);
        }
        teamsSending=false;cancel.disabled=false;cancel.textContent='关闭';status.style.whiteSpace='pre-wrap';status.textContent=outcomes.join('\n');
        return outcomes;
      };
      const send=teamsButton('teams-send','确认推送 '+deliveries.length+' 个项目',()=>{deliveryPromise=deliver();});send.className='primary';cancel.focus();
      if(automated){send.click();const outcomes=await deliveryPromise;if(!outcomes||outcomes.some(x=>/失败|未知|超时|未发出|跳过/.test(x)))throw Error(outcomes?.join('；')||'通知未提交');}
    }catch(error){message(error.message,true);if(automated)throw error;}
  }
  hub.jobRunners['sprint']=async job=>{
    if(busy||teamsSending)throw Error('Sprint 正在运行，请先完成当前操作。');
    let failure,skipped=false;
    await guard(async()=>{try{
      $('period').value=job.period;await load();for(const x of $('sprints').querySelectorAll('input'))x.checked=!hub.closedSprint(x.parentElement.textContent)&&x.value!==NONE;
      $('status-all').checked=true;for(const x of $('statuses').querySelectorAll('input'))x.checked=true;
      if(!selected().length){skipped=true;message('没有有效 Sprint（已排除 CLOSED 和未分配项），本次跳过。');return;}$('attach-report').checked=job.attach;await run();
    }catch(error){failure=error;throw error;}});
    if(failure)throw failure;if(skipped)return;
    if(!(job.teams||job.email)||!groups.length)return;
    let count=0;for(const x of $('notify-project').querySelectorAll('input')){x.checked=hub.jobProjectAllowed(x.value)&&!!hub.target(x.value+'-1');if(x.checked)count++;}
    if(!count)throw Error('没有可用的已启用通知项目，请检查配置中心。');
    await teamsPreview(true);
  };

  $('teams-preview').onclick=teamsPreview;

  $('load').onclick=()=>guard(load);$('run').onclick=()=>guard(run);
  let lastFocus;
  const toolbar=document.createElement('div');toolbar.className='query-toolbar';const controls=root.querySelector('.controls');controls.before(toolbar);toolbar.append($('period').parentElement,$('load'));
  const compact=document.createElement('style');compact.textContent='.query-toolbar{display:flex;align-items:end;gap:10px;flex-wrap:wrap;margin:16px 0}.query-toolbar label{width:240px;max-width:100%}.query-toolbar #load{width:auto;min-width:0;padding:8px 14px}.controls{align-items:start}#notify-box{grid-column:1/-1;padding:8px 12px}#notify-project{display:flex;gap:8px;flex-wrap:wrap;padding:4px 0}#notify-project label{display:inline-flex;flex-direction:row;align-items:center;gap:6px;background:#fff;border:1px solid #dce4f1;border-radius:7px;padding:7px 12px;cursor:pointer}#notify-project input{margin:0}.controls>#run,.controls>#export,.controls>#teams-preview{width:max-content;max-width:100%}.query-toolbar select{width:100%}';root.append(compact);
  $('launch').style.display='none';$('close').style.display='none';
  const embeddedStyle=document.createElement('style');embeddedStyle.textContent='#overlay{display:block!important;position:relative;inset:auto;padding:0;background:none;z-index:auto}#panel{height:auto;min-height:0;max-width:none;margin:0;padding:2px;background:transparent;box-shadow:none;border-radius:0}header{margin-bottom:12px}h1{font-size:21px}h1 small{display:none}.controls{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;align-items:stretch}fieldset{min-width:0;max-width:none;width:100%;background:#fff;border-color:#dce4f1;padding:12px}.choices{max-width:none;height:150px}.choices label{font-size:12px}label{font-size:12px;color:#718098}button{border-color:#dbe3f0;border-radius:7px;font-size:12px;padding:8px 10px}.primary{background:#245de8;border-color:#245de8;color:#fff}.primary:not(:disabled):hover{background:#174bd0}.notice{font-size:11px;line-height:1.7;color:#718098;background:#edf3ff;padding:10px 12px}#load{align-self:end}#message{font-size:12px}.card{border-color:#e1e7f1;padding:14px;border-radius:10px}p.muted{font-size:11px}#status-all{align-self:start}';root.append(embeddedStyle);
  $('launch').onclick=()=>{lastFocus=document.activeElement;$('overlay').style.display='block';$('close').focus();};
  const close=()=>{hub.hide();lastFocus?.focus();};$('close').onclick=close;
  root.addEventListener('keydown',e=>{if(teamsDialog.style.display!=='none'){
    if(e.key==='Escape'){e.preventDefault();closeTeams();}
    if(e.key==='Tab'){const nodes=[...teamsBox.querySelectorAll('button,input')].filter(x=>!x.disabled),first=nodes[0],last=nodes.at(-1);if(e.shiftKey&&root.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&root.activeElement===last){e.preventDefault();first?.focus();}}return;
  }if(e.key==='Escape')close();if(e.key==='Tab'&&$('overlay').style.display==='block'){const nodes=[...$('panel').querySelectorAll('button,input,select,a')].filter(x=>!x.disabled);const first=nodes[0],last=nodes.at(-1);if(e.shiftKey&&root.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&root.activeElement===last){e.preventDefault();first.focus();}}});
  $('export').onclick=()=>{
    const rows=[['统计说明',reportMeta],['Sprint ID','Sprint','状态',activePeriod.before,activePeriod.after,'增减',activePeriod.rate]];
    for(const g of groups){const stats=rowsWithTotal(g);for(const r of stats)rows.push([g.id,g.name,r.name,r.before.length,r.after.length,r.after.length-r.before.length,rate(r.before.length,r.after.length)]);}
    const blob=new Blob(['\ufeff'+rows.map(r=>r.map(csvCell).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='jira-sprint-analysis-'+new Date().toISOString().slice(0,10)+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  };
})();

(function () {
  'use strict';
  const NONE = '∅';
  const STATUS_NAMES=["New", "Grooming", "Open", "In Progress", "Ready For Test", "Testing", "Completed", "SIT", "Ready For UAT", "UAT", "Ready For Deploy", "DEPLOYED", "Done", "Cancelled"];
  const normalized=name=>String(name||'').trim().replace(/\s+/g,' ').toLowerCase();
  function comparisonPeriod(now,mode='day'){
    const day=86400000,offset=8*3600000;
    const date=t=>new Date(t+offset).toISOString().slice(0,10);
    const midnight=Date.parse(date(now)+'T00:00:00+08:00');
    if(mode==='week'){
      const weekday=new Date(midnight+offset).getUTCDay();
      const monday=midnight-((weekday+6)%7)*day;
      return {cutoff:monday,before:'上周日终',after:'本周截至当前',rate:'周环比',created:'本周创建',
        description:`By week｜上周 ${date(monday-7*day)}～${date(monday-day)}（周日结束时） → 本周 ${date(monday)}～${date(monday+6*day)}（截至当前，未满周）`};
    }
    return {cutoff:midnight,before:'昨日日终',after:'今日截至当前',rate:'日环比',created:'今日创建',
      description:`By day｜昨日 ${date(midnight-day)}（日终） → 今日 ${date(now)}（截至当前）`};
  }
  function selectStatusGroups(source,selection){
    const names=selection===null?STATUS_NAMES:STATUS_NAMES.filter(n=>selection.includes(normalized(n)));
    const allowed=new Map(names.map(n=>[normalized(n),n]));
    return source.map(g=>{
      const rows=new Map();
      for(const row of g.rows.values()){
        const key=normalized(row.name);if(!allowed.has(key))continue;
        if(!rows.has(key))rows.set(key,{id:key,name:allowed.get(key),before:[],after:[]});
        rows.get(key).before.push(...row.before);rows.get(key).after.push(...row.after);
      }
      if(selection!==null)for(const [id,name] of allowed)if(!rows.has(id))rows.set(id,{id,name,before:[],after:[]});
      return {...g,rows,issues:g.issues.filter(x=>allowed.has(normalized(x.before?.name))||allowed.has(normalized(x.after?.name)))};
    }).filter(g=>[...g.rows.values()].some(r=>r.before.length||r.after.length));
  }
  // Epic membership uses the current Epic Link (or parent on newer Jira instances).
  const epicNames=new Map();
  function isEpic(issue){const type=issue.fields?.issuetype;return type?.subtask!==true&&(/^epic$|^史诗$/i.test(type?.name||'')||type?.hierarchyLevel===1);}
  function isStory(issue){return /^(story|用户故事|故事)$/i.test(String(issue.fields?.issuetype?.name||'').trim())&&issue.fields?.issuetype?.subtask!==true;}
  function sprints(value){
    if(value==null||value==='')return [];
    const values=Array.isArray(value)?value:[value];
    return values.map(v=>{
      const key=String(typeof v==='object'?v?.key||'':v).trim().toUpperCase();
      if(!/^[A-Z][A-Z0-9_]*-\d+$/.test(key))throw Error('无法识别 Epic 关联编号，请检查 Epic Link / parent 字段。');
      return {id:key,name:epicNames.get(key)||key,state:''};
    });
  }
  async function loadEpicNames(issues){
    epicNames.clear();
    const keys=[...new Set(issues.filter(isStory).flatMap(i=>sprints(i.fields[field]).map(x=>x.id)))];
    // Fetch labels only: these responses never contribute members or counts.
    for(let offset=0;offset<keys.length;offset+=50){
      try{
        const params=new URLSearchParams({jql:'key in ('+keys.slice(offset,offset+50).join(',')+')',fields:'summary,issuetype',maxResults:'50'});
        const data=await api('/rest/api/2/search?'+params);
        for(const issue of data.issues||[])if(isEpic(issue)&&keys.includes(issue.key))epicNames.set(issue.key,issue.key+' · '+(issue.fields.summary||''));
      }catch{ /* A missing label must not block grouping the current Stories by key. */ }
    }
  }
  function statusAt(issue, cutoff, inclusive = true) {
    const created = Date.parse(issue.fields.created);
    if (!Number.isFinite(created)) throw new Error(`${issue.key}: 创建时间无效`);
    if (inclusive ? created > cutoff : created >= cutoff) return null;
    let status = { id: String(issue.fields.status.id), name: issue.fields.status.name };
    const histories = [...issue.changelog.histories].sort((a,b) => Date.parse(b.created)-Date.parse(a.created) || Number(b.id)-Number(a.id));
    for (const h of histories) {
      const time = Date.parse(h.created);
      if (!Number.isFinite(time)) throw new Error(`${issue.key}: 变更时间无效`);
      if (inclusive ? time <= cutoff : time < cutoff) continue;
      for (const item of [...h.items].reverse()) {
        if (item.field === 'status' || item.fieldId === 'status') {
          if (item.from == null || !item.fromString) throw new Error(`${issue.key}: 状态历史不完整`);
          status = { id: String(item.from), name: item.fromString };
        }
      }
    }
    return status;
  }
  function rate(a,b) { return a === 0 ? (b === 0 ? '—' : '新增') : `${((b-a)/a*100).toFixed(1)}%`; }
  function aggregate(issues, field, selected, cutoff, now) {
    const groups = new Map();
    for (const issue of issues) {
      const memberships = sprints(issue.fields[field]);
      const ids = memberships.length ? [...new Set(memberships.map(s=>s.id))] : [NONE];
      const before = statusAt(issue, cutoff, false), after = statusAt(issue, now);
      for (const id of ids.filter(id=>selected.includes(id))) {
        if (!groups.has(id)) groups.set(id, {id, name: memberships.find(s=>s.id===id)?.name || '未分配 Epic', rows:new Map(), issues:[]});
        const g=groups.get(id);
        for (const [side,status] of [['before',before],['after',after]]) {
          if (!status) continue;
          if (!g.rows.has(status.id)) g.rows.set(status.id,{id:status.id,name:status.name,before:[],after:[]});
          g.rows.get(status.id)[side].push(issue);
        }
        g.issues.push({issue,before,after,changed:before?.id!==after?.id});
      }
    }
    return [...groups.values()];
  }
  function matchesEpic(issue,field,ids){
    const list=sprints(issue.fields[field]);
    return list.length ? list.some(x=>ids.includes(x.id)) : ids.includes(NONE);
  }
  function filterGroups(source,statusIds){
    if(statusIds===null)return source;
    const allowed=new Set(statusIds);
    return source.map(g=>({...g,rows:new Map([...g.rows].filter(([id])=>allowed.has(id))),
      issues:g.issues.filter(x=>allowed.has(x.before?.id)||allowed.has(x.after?.id))}));
  }
  function rowsWithTotal(g){
    const rows=[...g.rows.values()].filter(r=>r.before.length||r.after.length).sort((a,b)=>(STATUS_NAMES.findIndex(n=>normalized(n)===normalized(a.name))+1||STATUS_NAMES.length+1)-(STATUS_NAMES.findIndex(n=>normalized(n)===normalized(b.name))+1||STATUS_NAMES.length+1)||a.name.localeCompare(b.name));
    return [...rows,{name:'所选状态合计',before:rows.flatMap(r=>r.before),after:rows.flatMap(r=>r.after)}];
  }
  function csvCell(v) { let s=String(v ?? ''); if (/^[\s]*[=+\-@]/.test(s)) s="'"+s; return '"'+s.replaceAll('"','""')+'"'; }
  function pageQuery(doc, href) {
    const url = new URL(href);
    // The visible advanced search editor takes precedence over an old saved-filter ID.
    for (const selector of ['#jqltextarea', 'textarea[name="jqlQuery"]', 'input[name="jql"]']) {
      const el = doc.querySelector(selector);
      let visible=!!el;
      for(let node=el;node && visible;node=node.parentElement){
        const style=doc.defaultView?.getComputedStyle(node);
        if(node.hidden || node.getAttribute('aria-hidden')==='true' || style?.display==='none' || style?.visibility==='hidden')visible=false;
      }
      if (visible && el.value?.trim() && !el.disabled) {
        return {jql:el.value.trim(), source:'当前页面 JQL'};
      }
    }
    const jql=url.searchParams.get('jql');
    if(jql?.trim()) return {jql:jql.trim(),source:'当前页面 URL JQL'};
    const key=/\/browse\/([A-Z][A-Z0-9_]*-\d+)/i.exec(url.pathname)?.[1];
    if(key) return {jql:'key = "'+key+'"',source:'当前任务页面'};
    const filter=url.searchParams.get('filter');
    if(filter && /^\d+$/.test(filter)) return {filter,source:'当前页面查询（从页面筛选器解析）'};
    throw new Error('无法识别当前页面的查询条件。请在 Jira 问题列表点击 Search，或切换 Advanced 后重新载入。');
  }
  function validateTeamsUrl(value){
    let u;try{u=new URL(String(value).trim().replace(/\\&/g,'&').replace(/&amp;/g,'&'));}catch{throw new Error('请输入有效的 Teams Workflows HTTPS Webhook 地址。');}
    const allowed=['logic.azure.com','api.powerplatform.com','api.powerautomate.com'];
    if(u.protocol!=='https:'||u.username||u.password||u.hash||u.port||!allowed.some(h=>u.hostname.endsWith('.'+h))||!u.pathname.includes('/workflows/'))throw new Error('仅支持微软 Teams Workflows 的 HTTPS 地址（logic.azure.com / api.powerplatform.com / api.powerautomate.com），不支持旧版 Connector。');
    return u.href;
  }
  function teamsResponseInfo(response={}){
    const parts=[];
    if(Number.isFinite(response.status))parts.push('HTTP '+response.status);
    if(Number.isFinite(response.readyState))parts.push('readyState '+response.readyState);
    let code='';try{code=JSON.parse(response.responseText||'{}').error?.code||'';}catch{}
    if(/^[A-Za-z0-9_.-]{1,100}$/.test(code))parts.push(code);
    const raw=String(response.error||response.message||'');
    const network=/\b(?:net::)?ERR_[A-Z0-9_]+\b/.exec(raw)?.[0];if(network)parts.push(network);
    if(/not permitted|not allowed|refused to connect|whitelist|blocked by.*user/i.test(raw))parts.push('油猴连接授权被拒绝，请检查脚本设置中的用户域名白名单');
    // Do not include raw error strings, response bodies or URLs: they may contain the webhook signature.
    return parts.join('；')||'浏览器/扩展未提供 HTTP 响应';
  }
  function buildTeamsReport(groups,meta,period,jiraUrl){
    const block=(value,extra={})=>({type:'TextBlock',text:String(value),wrap:true,...extra});
    const columns=(values,header=false)=>({type:'ColumnSet',spacing:'Medium',separator:!header,columns:values.map((value,i)=>({
      type:'Column',width:['stretch','42px','42px','50px','64px'][i],spacing:'Small',items:[{type:'TextBlock',text:String(value),...(i?{horizontalAlignment:'Center'}:{wrap:true,horizontalAlignment:'Left'}),...(header?{weight:'Bolder'}:{})}]
    }))});
    const heading=['状态',period.before==='上周日终'?'上周末':'昨日',period.after==='本周截至当前'?'本周':'今日','增减',period.rate];
    const generated=meta.split('｜')[0].trim();
    const body=[block('Epic Analysis',{size:'Large',weight:'Bolder',color:'Accent'}),
      block(period.description,{size:'Small'}),block(generated,{size:'Small',isSubtle:true,spacing:'Small'})];
    const sections=[];
    for(const g of groups){
      const rows=rowsWithTotal(g),total=rows.at(-1),changes=g.issues.filter(x=>x.changed).length,created=g.issues.filter(x=>!x.before&&x.after).length;
      const model={name:g.name,id:g.id,changes,created,rows:rows.map(r=>{const a=r.before.length,b=r.after.length,d=b-a;return [r.name,String(a),String(b),(d>0?'+':'')+d,rate(a,b)];})};sections.push(model);
      const metrics=[['当前数量',total.after.length],['净状态变化',changes],[period.created,created]];
      const items=[block(g.name,{size:'Medium',weight:'Bolder'}),block('Epic #'+g.id,{size:'Small',isSubtle:true,spacing:'None'}),
        {type:'ColumnSet',columns:metrics.map(([label,value])=>({type:'Column',width:1,items:[block(value,{size:'Large',weight:'Bolder',color:'Accent',horizontalAlignment:'Center'}),block(label,{size:'Small',isSubtle:true,spacing:'None',horizontalAlignment:'Center'})]}))},
        columns(heading,true)];
      for(let i=0;i<model.rows.length;i++){
        const values=model.rows[i],isTotal=i===model.rows.length-1,row=columns(values,isTotal);row.separator=true;
        if(values[3]!=='0')row.columns[3].items[0].color=Number(values[3])>0?'Attention':'Accent';
        items.push(row);
      }
      body.push({type:'Container',separator:true,spacing:'Large',items});
    }
    body.push(block('当前成员回溯 · 仅统计所选状态 · 数量增减不代表好坏',{size:'Small',isSubtle:true,separator:true}),
      {type:'Container',id:'analysis-details',isVisible:false,items:[block(meta,{size:'Small',isSubtle:true})]});
    const payload={type:'message',attachments:[{contentType:'application/vnd.microsoft.card.adaptive',contentUrl:null,content:{$schema:'http://adaptivecards.io/schemas/adaptive-card.json',type:'AdaptiveCard',version:'1.2',msteams:{width:'Full'},body,actions:[
      {type:'Action.OpenUrl',title:'打开 Jira 查询',url:jiraUrl},{type:'Action.ToggleVisibility',title:'统计口径与查询条件',targetElements:['analysis-details']}
    ]}}]};
    return {payload,sections,heading,generated,meta,description:period.description,jiraUrl,period};
  }
  const core = {sprints,statusAt,rate,aggregate,csvCell,pageQuery,matchesEpic,filterGroups,rowsWithTotal,STATUS_NAMES,normalized,comparisonPeriod,selectStatusGroups,validateTeamsUrl,buildTeamsReport,teamsResponseInfo};
  if (typeof window === 'undefined' && typeof module === 'object' && module.exports) { module.exports = core; return; }
  // An older duplicate userscript may run first. Replace its panel rather than silently exiting.
  const existing=document.getElementById('jea-host');
  if(existing){
    const previous=existing.dataset.jsaVersion||existing.shadowRoot?.querySelector('h1 small')?.textContent?.replace(/^v/,'')||'0.0.0';
    const parts=v=>v.split('.').map(Number),a=parts(previous),b=parts('0.1.9');
    const comparison=a.reduce((r,n,i)=>r||n-(b[i]||0),0);
    if(comparison>=0)return;
    existing.remove();
  }
  const host=document.createElement('div'); host.id='jea-host';host.dataset.jsaVersion='0.1.9'; hub.epic.append(host);
  const root=host.attachShadow({mode:'open'});
  root.innerHTML=`<style>
  :host{all:initial;font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#172b4d}*{box-sizing:border-box}button,input,select{font:inherit}button{cursor:pointer;border:1px solid #c9d3e0;border-radius:6px;background:white;color:#172b4d;padding:7px 12px}button:hover{background:#edf3ff}.primary:hover,#launch:hover{background:#0747a6}#close{white-space:nowrap}button:disabled{opacity:.5;cursor:wait}.primary,#launch{background:#0052cc;color:white;border-color:#0052cc}#launch{position:fixed;right:24px;bottom:24px;z-index:2147483646;box-shadow:0 5px 20px #091e4240}#overlay{position:fixed;inset:0;background:#091e4260;z-index:2147483647;padding:3vh 3vw;display:none}#panel{background:#f7f9fc;border-radius:14px;max-width:1280px;margin:auto;height:94vh;overflow:auto;box-shadow:0 20px 80px #091e4255;padding:24px}header{display:flex;align-items:center;justify-content:space-between}h1{font-size:24px;margin:0}h2{font-size:17px;margin:0 0 12px}.muted{color:#5e6c84}p{margin:8px 0}.controls{display:flex;gap:16px;align-items:end;flex-wrap:wrap;margin:18px 0}label{display:flex;flex-direction:column;gap:5px}input,select{border:1px solid #b3bfd0;border-radius:5px;padding:7px;background:white;color:#172b4d}fieldset{margin:0;border:1px solid #b3bfd0;border-radius:6px;padding:8px;background:white;min-width:280px;max-width:100%}.choices{height:140px;overflow:auto;max-width:430px}.choices label{display:flex;flex-direction:row;align-items:center;gap:8px;padding:3px;cursor:pointer}.choices input{margin:0}.tools{display:flex;gap:8px;margin-bottom:5px}.tools button{padding:2px 8px}legend{padding:0 5px}.card{overflow-x:auto;background:white;border:1px solid #dfe5ed;border-radius:9px;margin:16px 0;padding:18px}.notice{padding:10px 14px;background:#eaf1ff;border-radius:6px}#message{white-space:pre-wrap}#message.error{background:#fff0ed;color:#ae2a19;padding:12px}table{width:100%;border-collapse:collapse;margin-top:10px}th,td{text-align:left;border-bottom:1px solid #e8ecf2;padding:9px 10px}th{background:#f4f6fa;color:#5e6c84}td button{border:0;padding:0;color:#0052cc;background:none;text-decoration:underline}.delta{font-variant-numeric:tabular-nums;font-weight:600}a{color:#0052cc}#detail{overflow:auto}small{font-size:12px}@media(max-width:650px){#panel{padding:14px}.controls{display:block}label{margin:10px 0}#sprints{min-width:0;width:100%}th,td{padding:6px}h1{font-size:20px}}
  </style><button id="launch">◷ Epic Analysis v0.1.9</button><div id="overlay"><section id="panel" role="dialog" aria-modal="true" aria-label="Epic Analysis"><header><div><h1>Epic <small class="muted">v0.1.9</small></h1><p class="muted"><span id="period-description"></span> · Asia/Shanghai（UTC+08:00）</p></div><button id="close" aria-label="关闭">关闭</button></header>
  <div class="notice">口径：仅统计当前查询全部分页中的 Story，按当前 Epic 归属分组；不会查询 Epic 下的其他 Story。不包含 Bug、Task、Subtask，不还原历史 Epic 归属。对比两侧均为 0 的状态行及空 Epic 自动隐藏。</div>
  <div class="controls"><label>对比维度<select id="period"><option value="day">By day · 昨天 / 今天</option><option value="week">By week · 上周 / 本周（周一至周日）</option></select></label><button id="load">载入当前页面（全部分页）</button><fieldset id="sprint-box"><legend>Epic（勾选，可多选）</legend><div class="tools"><button id="sprint-all" type="button">全选</button><button id="sprint-none" type="button">清空</button></div><div id="sprints" class="choices"></div></fieldset><fieldset id="status-box"><legend>状态（默认全部，可多选）</legend><label><input type="checkbox" id="status-all" checked>全部指定状态（以下 14 个）</label><div class="tools"><button id="status-select-all" type="button">全选</button><button id="status-clear" type="button">清空</button></div><div id="statuses" class="choices"></div></fieldset><button id="run" class="primary">开始分析</button><button id="export" disabled>导出 CSV</button><button id="report-export" disabled>导出交互报告</button><label class="report-option"><input id="attach-report" type="checkbox" checked>邮件附交互报告（含 Jira 明细）</label><fieldset id="notify-box"><legend>通知项目（工单所属项目，可多选）</legend><div id="notify-project" role="group" aria-label="推送项目（可多选）"></div></fieldset><button id="teams-preview" class="primary" disabled>预览并推送到 Teams</button></div>
  <p class="muted">仅统计当前查询全部分页中的 Story，按 Epic 分组，不追溯其他 Story。修改 Jira 搜索条件后请重新载入。</p><p id="message" role="status">点击“载入当前页面”读取全部结果；仅统计当前查询中的 Story，按 Epic 分组；按当前归属回溯状态，不还原历史归属。本工具只读取 Jira，不修改任务。</p><div id="results"></div><div id="detail"></div></section></div>`;
  const teamsDialog=document.createElement('div');teamsDialog.id='teams-dialog';teamsDialog.setAttribute('role','dialog');teamsDialog.setAttribute('aria-modal','true');teamsDialog.style.cssText='display:none;position:fixed;inset:0;background:#091e4280;z-index:2147483647;padding:4vh 4vw;overflow:auto';
  const teamsBox=document.createElement('section');teamsBox.className='card';teamsBox.style.cssText='max-width:900px;margin:0 auto;padding:24px;max-height:90vh;overflow:auto';teamsDialog.append(teamsBox);root.append(teamsDialog);
  const $=id=>root.getElementById(id); let reportIssues=[], reportIds=[], reportStatuses=null, reportNow=0; let field, groups=[], busy=false, reportMeta='', loadedQuery='', reportJiraUrl='', activePeriod=comparisonPeriod(Date.now());
  $('period-description').textContent=activePeriod.description;
  const message=(s,error=false)=>{ $('message').textContent=s; $('message').className=error?'error':''; };
  function text(tag,content,parent){const e=document.createElement(tag); e.textContent=content; parent.append(e); return e;}
  async function api(path,options={}){
    const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),30000);
    try{
      const res=await fetch(path,{...options,credentials:'same-origin',headers:{Accept:'application/json',...(options.headers||{})},signal:controller.signal});
      if(!res.ok){
        let detail='';try{const data=await res.json();detail=[...(Array.isArray(data.errorMessages)?data.errorMessages:[]),...Object.values(data.errors||{})].map(String).join('；').replace(/https?:\/\/\S+/g,'[接口地址]').slice(0,500);}catch{}
        const error=new Error('Jira HTTP '+res.status+'：'+(detail||(res.status===401||res.status===403?'请先登录并确认 Epic / 工单访问权限。':'Epic 接口请求失败。')));error.status=res.status;throw error;
      }
      if(!res.headers.get('content-type')?.includes('application/json'))throw Error('Jira 返回登录页或非 JSON 内容，请先登录后重试。');
      return await res.json();
    }finally{clearTimeout(timeout);}
  }
  async function currentQuery(){
    const query=pageQuery(document,location.href);
    if(query.jql)return query.jql;
    const data=await api('/rest/api/2/filter/'+query.filter);
    if(!data.jql?.trim())throw new Error('当前页面未返回有效的 JQL，请切换 Advanced 后重新载入。');
    return data.jql.trim();
  }
  let epicClause='Epic Link';
  async function detectField(){
    if(field)return field;
    const fields=await api('/rest/api/2/field');
    const candidates=fields.filter(f=>f.schema?.custom==='com.pyxis.greenhopper.jira:gh-epic-link');
    if(candidates.length>1)throw Error('无法唯一识别 Epic Link 字段，请联系维护者检查字段定义。');
    if(candidates.length===1){const definition=candidates[0];epicClause=definition.clauseNames?.find(n=>!/^cf\[|^customfield_/i.test(n))||definition.name||'Epic Link';return field=definition.id;}
    if(fields.some(f=>f.id==='parent'))return field='parent';
    throw Error('当前 Jira 未提供 Epic Link 或 parent 字段，无法按 Epic 分析。');
  }
  async function search(jql){
    let start=0,total,all=[]; const seen=new Set();
    do {
      const params=new URLSearchParams({jql,fields:`summary,status,created,updated,assignee,issuetype,parent,${field}`,startAt:String(start),maxResults:'100'});
      const page=await api('/rest/api/2/search?'+params);
      if(!Array.isArray(page.issues)||!Number.isFinite(page.total))throw new Error('搜索接口响应格式不支持');
      if(total!==undefined&&total!==page.total)throw new Error('查询过程中任务数量发生变化，请重试以免分页遗漏。');
      total=page.total;
      if(!page.issues.length && start<total)throw new Error('分页提前结束，已停止统计以避免遗漏。');
      for(const issue of page.issues){if(seen.has(issue.key))throw new Error('分页出现重复任务，请重试。');seen.add(issue.key);all.push(issue);}
      start+=page.issues.length;message(`读取任务 ${start} / ${total}…`);
    }while(start<total);
    return all;
  }
  async function history(issue){
    const params=new URLSearchParams({fields:`summary,status,created,updated,assignee,issuetype,parent,${field}`,expand:'changelog'});
    const full=await api('/rest/api/2/issue/'+encodeURIComponent(issue.key)+'?'+params);
    // The issue detail is authoritative. Search-index timestamps can differ or lag.
    // Never infer an actual user edit from a raw updated-string mismatch.
    let c=full.changelog;
    if(!c||!Array.isArray(c.histories)||!Number.isFinite(c.total))throw new Error(`${issue.key} 未返回可验证完整性的变更历史。`);
    if((c.startAt||0)!==0||c.histories.length!==c.total){
      let histories=[],start=0,total;
      do {
        let p;try{p=await api('/rest/api/2/issue/'+encodeURIComponent(issue.key)+'/changelog?startAt='+start+'&maxResults=100');}catch{throw new Error(`${issue.key} 历史被截断，且服务器不支持完整历史分页；本次结果不生成。`);}
        const values=p.values||p.histories;
        if(!Array.isArray(values)||!Number.isFinite(p.total)||(total!==undefined&&p.total!==total)||(!values.length&&start<p.total))throw new Error(`${issue.key} 历史分页不完整，请重试。`);
        total=p.total;histories.push(...values);start+=values.length;
      }while(start<total);
      if(new Set(histories.map(h=>h.id)).size!==total)throw new Error(`${issue.key} 历史分页重复或缺失。`);
      c=full.changelog={histories,total};
    }
    return full;
  }
  async function guard(job){
    if(busy)return;busy=true;const controls=['load','run','sprint-box','status-box','period'];controls.forEach(id=>$(id).disabled=true);$('report-export').disabled=$('export').disabled=true;$('teams-preview').disabled=true;
    groups=[];$('notify-project').replaceChildren();$('results').replaceChildren();$('detail').replaceChildren();
    try{await job();}catch(e){message(e.name==='AbortError'?'请求超过 30 秒，请检查网络或 VPN 后重试。':e.message,true);}finally{busy=false;controls.forEach(id=>$(id).disabled=false);$('report-export').disabled=$('export').disabled=!groups.length;$('teams-preview').disabled=!groups.length;}
  }
  function renderNotifyProjects(preserve=false){
    const picker=$('notify-project'),previous=new Map([...picker.querySelectorAll('input')].map(x=>[x.value,x.checked]));picker.replaceChildren();
    const configured=new Map(hub.projects().map(p=>[p.projectKey,p]));
    const keys=[...new Set(groups.flatMap(g=>g.issues.map(x=>x.issue.key.split('-')[0].toUpperCase())))].filter(key=>configured.has(key)).sort();
    for(const key of keys){
      const config=configured.get(key),label=text('label','',picker),input=document.createElement('input');input.type='checkbox';input.value=key;input.checked=preserve&&previous.has(key)?previous.get(key):config.enabled!==false;
      const state=config.enabled===false?'（通知已停用）':!config.webhook?'（未配置 Webhook）':'';
      label.append(input,document.createTextNode(key+state));label.title='Story / 工单所属项目：'+key+(config.projectGroup?'；共享配置：'+config.projectGroup:'')+(state?'；请在配置中心启用并保存':'');
      if(config.enabled===false)input.onchange=()=>{if(input.checked)message(key+' 通知已停用。请在配置中心勾选“启用通知”并保存后推送。',true);};
    }
    if(!keys.length)text('span',groups.length?'本次结果没有已配置的通知项目。':'分析后显示本次结果的通知项目。',picker);
    const note=text('small','仅显示本次结果中已配置的工单所属项目，不是 Epic 名称。',picker);note.style.cssText='flex-basis:100%;color:#718098;font-size:11px';
    const settings=text('button','通知设置',picker);settings.type='button';settings.onclick=()=>hub.configure();
  }
  addEventListener('jira-plus-project-config',()=>renderNotifyProjects(true));

  function selected(){return [...$('sprints').querySelectorAll('input:checked')].map(o=>o.value);}
  function selectedStatuses(){return $('status-all').checked?null:[...$('statuses').querySelectorAll('input:checked')].map(o=>o.value);}
  function choice(parent,id,name,checked){
    const label=document.createElement('label'), input=document.createElement('input');input.type='checkbox';input.value=id;input.checked=checked;label.append(input,document.createTextNode(name));parent.append(label);
  }
  function invalidate(){if(busy)return;groups=[];$('notify-project').replaceChildren();$('results').replaceChildren();$('detail').replaceChildren();$('report-export').disabled=$('export').disabled=true;$('teams-preview').disabled=true;message(`已选择 ${selected().length} 个 Epic；状态：${$('status-all').checked?'全部':selectedStatuses().length+' 项'}。请点击“开始分析”。`);}
  $('period').onchange=()=>{$('period-description').textContent=comparisonPeriod(Date.now(),$('period').value).description;invalidate();};
  $('sprints').onchange=invalidate;
  $('statuses').onchange=()=>{const inputs=[...$('statuses').querySelectorAll('input')];$('status-all').checked=inputs.length>0&&inputs.every(x=>x.checked);invalidate();};
  $('status-all').onchange=()=>{for(const x of $('statuses').querySelectorAll('input'))x.checked=$('status-all').checked;invalidate();};
  $('status-select-all').onclick=()=>{$('status-all').checked=true;$('status-all').onchange();};
  $('status-clear').onclick=()=>{$('status-all').checked=false;$('status-all').onchange();};
  for(const [id,checked] of [['sprint-all',true],['sprint-none',false]])$(id).onclick=()=>{for(const x of $('sprints').querySelectorAll('input'))x.checked=checked;invalidate();};
  async function load(){
    loadedQuery='';$('notify-project').replaceChildren();$('sprints').replaceChildren();
    await detectField();const query=await currentQuery(), issues=(await search(query)).filter(isStory), map=new Map();
    await loadEpicNames(issues);
    for(const i of issues){const list=sprints(i.fields[field]);if(!list.length)map.set(NONE,{id:NONE,name:'未分配 Epic',state:''});for(const s of list)map.set(s.id,s);}
    $('sprints').replaceChildren();
    const options=[...map.values()].sort((a,b)=>(/active/i.test(b.state)?1:0)-(/active/i.test(a.state)?1:0)||b.name.localeCompare(a.name));
    for(const s of options)choice($('sprints'),s.id,`${s.name}${s.state?' · '+s.state:''} [${s.id}]`,true);
    if(!selected().length&&$('sprints').querySelector('input'))$('sprints').querySelector('input').checked=true;
    $('statuses').replaceChildren();$('status-all').checked=true;
    for(const name of STATUS_NAMES)choice($('statuses'),normalized(name),name,true);
    loadedQuery=query;
    message(`已读取当前页面全部 ${issues.length} 条 Story、${options.length} 个 Epic 分组。可多选后分析。\nJQL：${loadedQuery}${issues.length?'':'（当前页面没有可见任务）'}`);
  }
  function details(title,items){hub.showIssueDetails(title,items,activePeriod); }
  function render(){
    const result=$('results');result.replaceChildren();text('p',reportMeta,result);
    for(const g of groups){
      const card=document.createElement('section');card.className='card';result.append(card);text('h2',g.name,card);
      const changes=g.issues.filter(x=>x.changed), created=g.issues.filter(x=>!x.before&&x.after);
      const detail=text('button',`查看变化 ${changes.length} 条（${activePeriod.created} ${created.length} 条）`,card);detail.onclick=()=>details(g.name+' · 净状态变化 / 新建任务',changes);
      const table=document.createElement('table');card.append(table);const head=document.createElement('tr');table.append(head);['状态',activePeriod.before,activePeriod.after,'增减',activePeriod.rate].forEach(h=>text('th',h,head));
      const rows=rowsWithTotal(g);
      for(const r of rows){const tr=document.createElement('tr');table.append(tr);text('td',r.name,tr);for(const side of ['before','after']){const td=document.createElement('td');tr.append(td);const b=text('button',String(r[side].length),td);b.onclick=()=>{const keys=new Set(r[side].map(i=>i.key));details(`${g.name} · ${r.name} · ${side==='before'?activePeriod.before:activePeriod.after}`,g.issues.filter(x=>keys.has(x.issue.key)));};}const delta=r.after.length-r.before.length;text('td',(delta>0?'+':'')+delta,tr).className='delta';text('td',rate(r.before.length,r.after.length),tr);}
    }
  }
  async function run(){
    const ids=selected();if(!ids.length)throw new Error('请先载入并选择 Epic。');await detectField();
    const statusIds=selectedStatuses();if(statusIds!==null&&!statusIds.length)throw new Error('请至少选择一个状态，或勾选全部状态。');
    const jql=await currentQuery();
    if(jql!==loadedQuery)throw new Error('当前页面查询已改变，请重新“载入当前页面”后再分析。');
    const now=Date.now();activePeriod=comparisonPeriod(now,$('period').value);const cutoff=activePeriod.cutoff;
    $('period-description').textContent=activePeriod.description;
    const pageIssues=await search(jql), issues=pageIssues.filter(i=>isStory(i)&&matchesEpic(i,field,ids)), full=new Array(issues.length);let cursor=0,done=0,failed;
    await Promise.all(Array.from({length:Math.min(3,issues.length)},async()=>{while(cursor<issues.length&&!failed){const i=cursor++;try{full[i]=await history(issues[i]);message(`读取完整历史 ${++done} / ${issues.length}…`);}catch(e){failed=e;}}}));
    if(failed)throw failed;
    const scoped=full.filter(i=>isStory(i)&&matchesEpic(i,field,ids));
    const allGroups=aggregate(scoped,field,ids,cutoff,now);
    const calculated=selectStatusGroups(allGroups,statusIds);
    const stateNames=statusIds===null?'全部指定的 14 个状态':[...$('statuses').querySelectorAll('input:checked')].map(x=>x.parentElement.textContent).join('、');
    reportMeta=`查询开始 ${new Date(now).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false})}（上海）｜${activePeriod.description}｜当前页面全部分页｜JQL：${jql}｜所选 Epic：${ids.join("、")}｜状态：${stateNames}｜当前成员回溯`;
    reportJiraUrl=location.origin+'/issues/?'+new URLSearchParams({jql});
    reportIssues=scoped;reportIds=ids;reportStatuses=statusIds;reportNow=now;
    groups=calculated;renderNotifyProjects();render();message(`分析完成：页面共 ${pageIssues.length} 条；所选 Epic 匹配 ${scoped.length} 条；所选状态涉及 ${new Set(groups.flatMap(g=>g.issues.map(x=>x.issue.key))).size} 条，${groups.length} 个 Epic 分组。合计仅包含所选状态。`);
  }
// Self-contained snapshot: no Jira API, authentication tokens, or external assets.
function buildInteractiveReport(model){
  const data=JSON.stringify(model).replace(/[<>&\u2028\u2029]/g,c=>'\\u'+c.charCodeAt(0).toString(16).padStart(4,'0'));
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Jira+ · Epic 报告</title><style>
*{box-sizing:border-box}body{margin:0;background:#f3f6fc;color:#24334d;font:14px/1.6 -apple-system,BlinkMacSystemFont,'Segoe UI','Microsoft YaHei',sans-serif}header{background:white;border-bottom:1px solid #e0e7f1;padding:20px max(24px,calc((100vw - 1120px)/2))}h1{font-size:24px;margin:0}h2{font-size:18px;margin:0 0 10px}small,.muted{color:#7b899e;font-size:12px}main{max-width:1168px;padding:24px;margin:auto}.toolbar{display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin:16px 0}.card{background:white;border:1px solid #e0e7f1;border-radius:12px;padding:20px;margin:16px 0;overflow-x:auto}button,select,input,a.action{font:inherit;border:1px solid #d9e2f1;border-radius:7px;padding:7px 12px;background:white;color:#245de8;cursor:pointer}input{color:#24334d;min-width:230px}.action{text-decoration:none}table{width:100%;border-collapse:collapse}th,td{padding:11px 12px;border-bottom:1px solid #edf1f7;text-align:left;vertical-align:top}th{background:#f3f6fc;color:#738198;font-size:12px}td.number,th.number{text-align:center}td.number button{border:0;padding:0;background:none;text-decoration:underline;font-variant-numeric:tabular-nums}tr.total{background:#edf3ff;font-weight:700}.positive{color:#d13438}.changed{background:#fff9eb}a{color:#245de8}#detail{position:fixed;z-index:10;inset:8vh max(16px,calc((100vw - 1050px)/2));margin:0;box-shadow:0 0 0 100vmax #14284666,0 20px 80px #14284655;overflow:auto;resize:both}#detail[hidden]{display:none}#detail-close{float:right;color:#d13438;background:#fff1f2;border:0}.tag{display:inline-block;background:#eaf0ff;color:#245de8;font-size:11px;padding:3px 8px;border-radius:5px;margin-left:8px}#meta{white-space:pre-wrap;overflow-wrap:anywhere}#empty{color:#7b899e}@media(max-width:640px){main{padding:12px}.card{padding:12px}th,td{padding:8px}h1{font-size:20px}}@media print{body{background:white}.toolbar,button{display:none}.card{break-inside:avoid}}
</style></head><body><header><h1>Jira+ <span class="tag">Epic Analysis</span></h1><small>独立交互报告 · 分析快照</small></header><main><p id="period"></p><div class="toolbar"><label>项目 <select id="project"></select></label><button id="all-changes">查看全部变化</button><a id="jira-query" class="action" target="_blank" rel="noopener noreferrer">打开 Jira 查询</a></div><p class="muted">点击昨日 / 今日数字，在独立弹窗查看对应工单及状态前后变化；报告保持生成时的数据，不会自动更新。</p><div id="groups"></div><section id="detail" class="card" role="dialog" aria-modal="true" aria-label="工单明细" hidden><button id="detail-close" aria-label="关闭工单明细">❌</button><h2 id="detail-title"></h2><div class="toolbar"><input id="search" placeholder="筛选 Jira 编号、摘要或 Assignee" aria-label="筛选明细"><span id="detail-count" class="muted"></span></div><table><thead><tr><th>Issue</th><th>摘要</th><th>Assignee</th><th id="before-heading"></th><th id="after-heading"></th><th>变化</th></tr></thead><tbody id="detail-rows"></tbody></table><p id="empty" hidden>没有对应任务。</p></section><details class="card"><summary>统计口径与查询条件</summary><p id="meta" class="muted"></p></details></main><script id="report-data" type="application/json">${data}</script><script>
(${reportRuntime.toString()})();
</script></body></html>`;
}
function reportRuntime(){
 'use strict';
 const model=JSON.parse(document.getElementById('report-data').textContent),$=id=>document.getElementById(id);
 function el(tag,value,parent){const n=document.createElement(tag);if(value!==null)n.textContent=String(value);parent.append(n);return n;}
 function safeUrl(value){try{const u=new URL(value);return u.protocol==='https:'||u.protocol==='http:'?u.href:'';}catch{return '';}}
 const jira=safeUrl(model.jiraUrl);$('jira-query').href=jira||'#';$('period').textContent=model.period.description;$('meta').textContent=model.meta;
 $('before-heading').textContent=model.period.before;$('after-heading').textContent=model.period.after;
 const projectOf=key=>key.split('-')[0];let selection=[],detailTitle='';
 const keys=[...new Set(model.groups.flatMap(g=>g.issues.map(i=>projectOf(i.key))))].sort();el('option','全部项目',$('project')).value='';for(const key of keys)el('option',key,$('project')).value=key;
 function filtered(issues){return issues.filter(i=>!$('project').value||projectOf(i.key)===$('project').value);}
 function renderDetails(){
   const term=$('search').value.trim().toLowerCase(),items=selection.filter(i=>(i.key+' '+i.summary+' '+(i.assignee||'未分配')).toLowerCase().includes(term));$('detail-rows').replaceChildren();$('detail-title').textContent=detailTitle;$('detail-count').textContent=items.length+' / '+selection.length+' 条';$('empty').hidden=items.length>0;
   for(const item of items){const tr=el('tr',null,$('detail-rows'));if(item.before!==item.after)tr.className='changed';const td=el('td',null,tr),link=el('a',item.key,td);if(jira){link.href=new URL('/browse/'+encodeURIComponent(item.key),jira).href;link.target='_blank';link.rel='noopener noreferrer';}el('td',item.summary,tr);el('td',item.assignee||'未分配',tr);el('td',item.before||'尚未创建',tr);el('td',item.after||'尚未创建',tr);el('td',!item.before?'新建':item.before!==item.after?'状态变化':'未变化',tr);}
 }
 function show(title,items){selection=items;detailTitle=title;$('search').value='';$('detail').hidden=false;renderDetails();$('detail-close').focus();}
 function render(){
  $('groups').replaceChildren();$('detail').hidden=true;
  for(const group of model.groups){const issues=filtered(group.issues);if(!issues.length&&$('project').value)continue;const byKey=new Map(issues.map(i=>[i.key,i]));const card=el('section',null,$('groups'));card.className='card';el('h2',group.name+' · '+group.id,card);const changed=issues.filter(i=>i.changed),created=issues.filter(i=>!i.before&&i.after);el('button','查看变化 '+changed.length+' 条（新建 '+created.length+' 条）',card).onclick=()=>show(group.name+' · 净状态变化 / 新建任务',changed);
   const table=el('table',null,card),head=el('tr',null,el('thead',null,table));['状态',model.period.before,model.period.after,'增减',model.period.rate].forEach((h,i)=>{const th=el('th',h,head);if(i)th.className='number';});const body=el('tbody',null,table);
   for(const row of group.rows){if(model.analysisType==='epic-analysis'&&!row.before.some(k=>byKey.has(k))&&!row.after.some(k=>byKey.has(k)))continue;const tr=el('tr',null,body);if(row.total)tr.className='total';el('td',row.name,tr);const sets={};for(const side of ['before','after']){sets[side]=row[side].filter(k=>byKey.has(k));const td=el('td',null,tr);td.className='number';const button=el('button',sets[side].length,td);button.setAttribute('aria-label',group.name+' '+row.name+' '+model.period[side]+'明细');button.onclick=()=>show(group.name+' · '+row.name+' · '+model.period[side],sets[side].map(k=>byKey.get(k)));}const a=sets.before.length,b=sets.after.length,delta=b-a;el('td',(delta>0?'+':'')+delta,tr).className='number'+(delta>0?' positive':'');el('td',a===0?(b===0?'—':'新增'):((b-a)/a*100).toFixed(1)+'%',tr).className='number';}
  }
 }
 $('detail-close').onclick=()=>{$('detail').hidden=true;};document.addEventListener('keydown',e=>{if(e.key==='Escape')$('detail').hidden=true;});
 $('project').onchange=render;$('search').oninput=renderDetails;$('all-changes').onclick=()=>{const map=new Map();for(const g of model.groups)for(const i of filtered(g.issues))if(i.changed)map.set(i.key,i);show('全部 Epic · 净状态变化 / 新建任务',[...map.values()]);};render();
}
if(typeof module==='object'&&module.exports)module.exports={buildInteractiveReport};

  function reportModel(source=groups){
    return {version:1,analysisType:'epic-analysis',meta:reportMeta,jiraUrl:reportJiraUrl,period:activePeriod,generatedAt:new Date(reportNow).toISOString(),groups:source.map(group=>{const rows=rowsWithTotal(group);return {id:group.id,name:group.name,issues:group.issues.map(x=>({key:x.issue.key,summary:x.issue.fields.summary||'',assignee:x.issue.fields.assignee?.displayName||'未分配',before:x.before?.name||'',after:x.after?.name||'',changed:x.changed})),rows:rows.map((row,i)=>({name:row.name,total:i===rows.length-1,before:row.before.map(x=>x.key),after:row.after.map(x=>x.key)}))};})};
  }
  function reportFile(source=groups,project='all'){
    return {name:'Jira-Monitor-'+project+'-'+new Date(reportNow).toISOString().replace(/[:.]/g,'-')+'.html',html:buildInteractiveReport(reportModel(source))};
  }
  function downloadReport(file){const url=URL.createObjectURL(new Blob([file.html],{type:'text/html;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download=file.name;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);}
  function reportBase64(html){const bytes=new TextEncoder().encode(html);let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(binary);}
  $('report-export').onclick=()=>{if(!busy&&groups.length)downloadReport(reportFile());};

  let teamsSending=false,teamsFocus;
  function openTeams(title){
    teamsFocus=root.activeElement||document.activeElement;teamsBox.replaceChildren();text('h2',title,teamsBox);teamsDialog.style.display='block';teamsDialog.setAttribute('aria-label',title);
  }
  function closeTeams(){if(teamsSending)return;teamsDialog.style.display='none';teamsBox.replaceChildren();teamsFocus?.focus();}
  function teamsButton(id,label,action){const b=text('button',label,teamsBox);b.id=id;b.style.margin='8px 8px 0 0';b.onclick=action;return b;}
  function teamsConfig(){hub.configure();}
  async function teamsPreview(automated=false){
    automated=automated===true;
    if(busy||teamsSending||!groups.length)return;
    const keys=[...$('notify-project').querySelectorAll('input:checked')].map(input=>input.value);
    if(!keys.length){if(automated)throw Error('请至少勾选一个推送项目。');message('请至少勾选一个推送项目。',true);return;}
    try{
      // Freeze each project's report and destination before displaying the confirmation.
      const deliveries=keys.map(projectKey=>{
        const configured=hub.target(projectKey+'-1');
        if(!configured?.webhook)throw Error(projectKey+' 通知未启用或未配置 Webhook，请先在配置中心保存。未发送任何消息。');
        const target={...configured,recipients:[...(configured.recipients||[])]},destination=validateTeamsUrl(target.webhook);
        const projectIssues=reportIssues.filter(i=>i.key.split('-')[0].toUpperCase()===projectKey);
        if(!projectIssues.length)throw Error(projectKey+' 在本次报告中没有任务，请重新分析。');
        const projectGroups=selectStatusGroups(aggregate(projectIssues,field,reportIds,activePeriod.cutoff,reportNow),reportStatuses);
        const report=buildTeamsReport(projectGroups,reportMeta+'｜仅项目 '+projectKey,activePeriod,reportJiraUrl);
        const bodyText=projectKey+' · '+report.description+'\n'+report.sections.map(section=>section.name+'\n'+[report.heading,...section.rows].map(row=>row.join(' | ')).join('\n')).join('\n\n');
        report.payload.projectKey=projectKey;report.payload.reportType='epic-analysis';
        report.payload.email=target.recipients.length?{enabled:true,recipients:target.recipients,to:target.recipients.join(';'),subject:'[Jira+] '+projectKey+' · Epic Analysis',bodyText,bodyHtml:hub.emailCard({title:projectKey+' · Epic Analysis',subtitle:report.description,sections:report.sections.map(section=>({title:section.name,headers:report.heading,rows:section.rows,total:true,deltaColumn:3})),meta:reportMeta,url:reportJiraUrl})}:{enabled:false};
        const file=reportFile(projectGroups,projectKey);
        if(report.payload.email.enabled&&(hub.jobDelivery?hub.jobDelivery.attach:$('attach-report').checked)){report.payload.email.attachments=[{name:file.name,contentType:'text/html',contentBytes:reportBase64(file.html)}];report.payload.email.bodyHtml+='<p style="font:12px Arial;color:#718098">附交互报告：'+hub.escapeHtml(file.name)+'。请下载附件并使用浏览器打开，点击数字查看工单明细和状态变化。</p>';}
        if(hub.jobDelivery?.email&&!report.payload.email.enabled)throw Error(projectKey+' 未配置邮件收件人');
        hub.deliveryPayload(report.payload);
        const oversized=new TextEncoder().encode(JSON.stringify(report.payload.attachments)).length>26*1024;
        const emailOnly=oversized&&report.payload.reportType==='epic-analysis'&&!hub.jobDelivery?.combine;
        if(oversized&&!emailOnly&&!hub.jobDelivery?.combine)throw Error(projectKey+' 卡片超过 Teams 大小限制，请减少所选 Epic 后重试。');
        if(emailOnly&&!report.payload.email.enabled)throw Error(projectKey+' 所选数量超过 Teams 大小限制，但未配置邮件收件人，请先在配置中心保存。未发送任何消息。');
        report.payload.teams={enabled:!emailOnly&&hub.jobDelivery?.teams!==false};
        if(emailOnly){report.payload.attachments=[];report.payload.deliveryMode='email-only';}
        return {projectKey,target,destination,report,file,emailOnly,data:JSON.stringify(report.payload)};
      });
      openTeams('项目推送预览 · '+deliveries.length+' 个项目');
      if(deliveries.some(item=>item.emailOnly))message('所选数量超过 Teams 大小限制，所选数据只通过邮件发送');
      text('p','每个项目分别发送到对应 Teams 和邮件收件人。勾选邮件附报告时，载荷另含该项目的 Jira 编号、摘要及状态变化，需工作流配置附件步骤；下方可先下载检查。',teamsBox);
      const preview=document.createElement('div');preview.id='teams-preview-content';teamsBox.append(preview);
      for(const item of deliveries){
        const card=text('section','',preview);card.className='card';
        text('h2',item.projectKey+' · Epic Analysis',card);
        if(item.emailOnly)text('p','所选数量超过 Teams 大小限制，所选数据只通过邮件发送',card).setAttribute('role','status');
        const download=text('button','下载该项目交互报告',card);download.onclick=()=>downloadReport(item.file);
        text('p',item.report.payload.email.attachments?.length?'邮件包含交互报告附件载荷（需要工作流映射附件字段）':'邮件未附交互报告',card).className='muted';
        const mailPreview=text('button','预览邮件正文',card);mailPreview.onclick=()=>hub.previewEmail(item.report.payload.email);
        text('p','邮件：'+(item.target.recipients.join(';')||'未配置'),card);
        text('p','Webhook 主机：'+new URL(item.destination).hostname+'（密钥已隐藏）',card).className='muted';
        text('p',item.report.description,card);
        for(const section of item.report.sections){
          text('h3',section.name,card);const table=document.createElement('table');card.append(table);
          const head=document.createElement('tr');table.append(head);item.report.heading.forEach(h=>text('th',h,head));
          section.rows.forEach((values,index)=>{const tr=document.createElement('tr');table.append(tr);if(index===section.rows.length-1)tr.style.cssText='font-weight:700;background:#edf3ff';values.forEach((v,i)=>{const td=text('td',v,tr);if(i===3&&Number(v)>0)td.style.color='#d13438';});});
        }
      }
      const status=text('p','尚未发送。确认后按项目分别提交；不会自动重试。',teamsBox);status.id='teams-send-status';status.setAttribute('role','status');
      const cancel=teamsButton('teams-preview-cancel','取消',closeTeams);
      let deliveryPromise;
      const deliver=async()=>{
        if(teamsSending||send.disabled)return;
        if(typeof GM_xmlhttpRequest!=='function'){status.textContent='缺少扩展跨域请求权限，请更新脚本。';return;}
        teamsSending=true;send.disabled=true;cancel.disabled=true;
        const outcomes=[];
        for(const item of deliveries){
          if(!hub.target(item.projectKey+'-1')){outcomes.push(item.projectKey+'：通知已停用，跳过');continue;}
          status.textContent=[...outcomes,item.projectKey+'：正在提交…'].join('\n');
          const outcome=await new Promise(resolve=>{
            let settled=false,request;
            const finish=value=>{if(settled)return;settled=true;clearTimeout(timer);resolve(value);};
            const timer=setTimeout(()=>{finish('超时，结果未知，请检查工作流；未重试');request?.abort?.();},30000);
            try{request=GM_xmlhttpRequest({method:'POST',url:item.destination,headers:{'Content-Type':'application/json'},data:item.data,timeout:30000,anonymous:true,redirect:'error',
              onload:r=>finish(r.status>=200&&r.status<300?'已提交（HTTP '+r.status+'），最终投递请查工作流':'失败：'+teamsResponseInfo(r)),
              onerror:r=>finish('网络失败，结果可能未知：'+teamsResponseInfo(r)+'；未重试'),
              ontimeout:()=>finish('超时，结果未知，请检查工作流；未重试'),onabort:()=>finish('已中止，结果未知；未重试')});}
            catch(error){finish('请求未发出：'+teamsResponseInfo(error));}
          });
          outcomes.push(item.projectKey+'：'+(item.emailOnly?'仅邮件 · ':'')+outcome);
        }
        teamsSending=false;cancel.disabled=false;cancel.textContent='关闭';status.style.whiteSpace='pre-wrap';status.textContent=outcomes.join('\n');
        return outcomes;
      };
      const send=teamsButton('teams-send','确认推送 '+deliveries.length+' 个项目',()=>{deliveryPromise=deliver();});send.className='primary';cancel.focus();
      if(automated){send.click();const outcomes=await deliveryPromise;if(!outcomes||outcomes.some(x=>/失败|未知|超时|未发出|跳过/.test(x)))throw Error(outcomes?.join('；')||'通知未提交');}
    }catch(error){message(error.message,true);if(automated)throw error;}
  }
  hub.jobRunners['epic']=async job=>{
    if(busy||teamsSending)throw Error('Epic 正在运行，请先完成当前操作。');
    let failure;
    await guard(async()=>{try{
      $('period').value=job.period;await load();for(const x of $('sprints').querySelectorAll('input'))x.checked=true;
      $('status-all').checked=true;for(const x of $('statuses').querySelectorAll('input'))x.checked=true;
      $('attach-report').checked=job.attach;await run();
    }catch(error){failure=error;throw error;}});
    if(failure)throw failure;
    if(!(job.teams||job.email)||!groups.length)return;
    let count=0;for(const x of $('notify-project').querySelectorAll('input')){x.checked=hub.jobProjectAllowed(x.value)&&!!hub.target(x.value+'-1');if(x.checked)count++;}
    if(!count)throw Error('没有可用的已启用通知项目，请检查配置中心。');
    await teamsPreview(true);
  };

  $('teams-preview').onclick=teamsPreview;

  $('load').onclick=()=>guard(load);$('run').onclick=()=>guard(run);
  let lastFocus;
  const toolbar=document.createElement('div');toolbar.className='query-toolbar';const controls=root.querySelector('.controls');controls.before(toolbar);toolbar.append($('period').parentElement,$('load'));
  const compact=document.createElement('style');compact.textContent='.query-toolbar{display:flex;align-items:end;gap:10px;flex-wrap:wrap;margin:16px 0}.query-toolbar label{width:240px;max-width:100%}.query-toolbar #load{width:auto;min-width:0;padding:8px 14px}.controls{align-items:start}#notify-box{grid-column:1/-1;padding:8px 12px}#notify-project{display:flex;gap:8px;flex-wrap:wrap;padding:4px 0}#notify-project label{display:inline-flex;flex-direction:row;align-items:center;gap:6px;background:#fff;border:1px solid #dce4f1;border-radius:7px;padding:7px 12px;cursor:pointer}#notify-project input{margin:0}.controls>#run,.controls>#export,.controls>#teams-preview{width:max-content;max-width:100%}.query-toolbar select{width:100%}';root.append(compact);
  $('launch').style.display='none';$('close').style.display='none';
  const embeddedStyle=document.createElement('style');embeddedStyle.textContent='#overlay{display:block!important;position:relative;inset:auto;padding:0;background:none;z-index:auto}#panel{height:auto;min-height:0;max-width:none;margin:0;padding:2px;background:transparent;box-shadow:none;border-radius:0}header{margin-bottom:12px}h1{font-size:21px}h1 small{display:none}.controls{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;align-items:stretch}fieldset{min-width:0;max-width:none;width:100%;background:#fff;border-color:#dce4f1;padding:12px}.choices{max-width:none;height:150px}.choices label{font-size:12px}label{font-size:12px;color:#718098}button{border-color:#dbe3f0;border-radius:7px;font-size:12px;padding:8px 10px}.primary{background:#245de8;border-color:#245de8;color:#fff}.primary:not(:disabled):hover{background:#174bd0}.notice{font-size:11px;line-height:1.7;color:#718098;background:#edf3ff;padding:10px 12px}#load{align-self:end}#message{font-size:12px}.card{border-color:#e1e7f1;padding:14px;border-radius:10px}p.muted{font-size:11px}#status-all{align-self:start}';root.append(embeddedStyle);
  $('launch').onclick=()=>{lastFocus=document.activeElement;$('overlay').style.display='block';$('close').focus();};
  const close=()=>{hub.hide();lastFocus?.focus();};$('close').onclick=close;
  root.addEventListener('keydown',e=>{if(teamsDialog.style.display!=='none'){
    if(e.key==='Escape'){e.preventDefault();closeTeams();}
    if(e.key==='Tab'){const nodes=[...teamsBox.querySelectorAll('button,input')].filter(x=>!x.disabled),first=nodes[0],last=nodes.at(-1);if(e.shiftKey&&root.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&root.activeElement===last){e.preventDefault();first?.focus();}}return;
  }if(e.key==='Escape')close();if(e.key==='Tab'&&$('overlay').style.display==='block'){const nodes=[...$('panel').querySelectorAll('button,input,select,a')].filter(x=>!x.disabled);const first=nodes[0],last=nodes.at(-1);if(e.shiftKey&&root.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&root.activeElement===last){e.preventDefault();first.focus();}}});
  $('export').onclick=()=>{
    const rows=[['统计说明',reportMeta],['Epic ID','Epic','状态',activePeriod.before,activePeriod.after,'增减',activePeriod.rate]];
    for(const g of groups){const stats=rowsWithTotal(g);for(const r of stats)rows.push([g.id,g.name,r.name,r.before.length,r.after.length,r.after.length-r.before.length,rate(r.before.length,r.after.length)]);}
    const blob=new Blob(['\ufeff'+rows.map(r=>r.map(csvCell).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='jira-epic-analysis-'+new Date().toISOString().slice(0,10)+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  };
})();

hub.startScheduled();hub.startBrowserScheduler();
})();

})().catch(error=>console.error("Jira+ 初始化失败",error));
